from setuptools import setup, find_packages

setup(
    name="nttracker",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        'flask==3.0.2',
        'flask-cors==4.0.0',
        'python-dotenv==1.0.0',
        'mysql-connector-python==8.2.0',
    ],
) 