from flask import Blueprint, request, session, jsonify
from utils.db import get_db_connection
import bcrypt

# Create a Blueprint for auth routes
auth_bp = Blueprint('auth', __name__)

# Helper: get user by username
def get_user_by_username(username):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return user

# Helper: get user by id
def get_user_by_id(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return user

# Login endpoint
@auth_bp.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    user = get_user_by_username(username)
    if not user:
        return jsonify({'error': 'Invalid username or password'}), 401
    if not bcrypt.checkpw(password.encode(), user['password_hash'].encode()):
        return jsonify({'error': 'Invalid username or password'}), 401
    # Set session
    session['user_id'] = user['id']
    session['username'] = user['username']
    session['role'] = user['role']
    # Update last_login
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET last_login = NOW() WHERE id = %s", (user['id'],))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({'success': True, 'username': user['username'], 'role': user['role']})

# Logout endpoint
@auth_bp.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

# Get current user info
@auth_bp.route('/api/me', methods=['GET'])
def get_me():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'logged_in': False}), 200
    user = get_user_by_id(user_id)
    if not user:
        session.clear()
        return jsonify({'logged_in': False}), 200
    return jsonify({'logged_in': True, 'username': user['username'], 'role': user['role']})

# Decorator to protect admin routes
from functools import wraps

def require_role(*roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if 'user_id' not in session or 'role' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            if session['role'] not in roles:
                return jsonify({'error': 'Insufficient permissions'}), 403
            return f(*args, **kwargs)
        return wrapper
    return decorator

@auth_bp.route('/api/users', methods=['GET'])
@require_role('admin')
def list_users():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id, username, role, userID, created_at, last_login FROM users ORDER BY id")
    users = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(users)

@auth_bp.route('/api/users', methods=['POST'])
@require_role('admin')
def add_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    role = data.get('role', 'teamadmin')
    userID = data.get('userID')
    if not username or not password or role not in ('admin', 'teamadmin'):
        return jsonify({'error': 'Username, password, and valid role required'}), 400
    password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (username, password_hash, role, userID) VALUES (%s, %s, %s, %s)", (username, password_hash, role, userID))
        conn.commit()
        user_id = cursor.lastrowid
    except Exception as e:
        conn.rollback()
        cursor.close()
        conn.close()
        return jsonify({'error': str(e)}), 400
    cursor.close()
    conn.close()
    return jsonify({'success': True, 'id': user_id})

@auth_bp.route('/api/users/<int:user_id>', methods=['PUT'])
@require_role('admin')
def update_user(user_id):
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    role = data.get('role')
    userID = data.get('userID')
    conn = get_db_connection()
    cursor = conn.cursor()
    updates = []
    values = []
    if username:
        updates.append('username = %s')
        values.append(username)
    if password:
        password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        updates.append('password_hash = %s')
        values.append(password_hash)
    if role:
        if role not in ('admin', 'teamadmin'):
            cursor.close()
            conn.close()
            return jsonify({'error': 'Invalid role'}), 400
        updates.append('role = %s')
        values.append(role)
    if userID is not None:
        updates.append('userID = %s')
        values.append(userID)
    if not updates:
        cursor.close()
        conn.close()
        return jsonify({'error': 'No fields to update'}), 400
    values.append(user_id)
    try:
        cursor.execute(f"UPDATE users SET {', '.join(updates)} WHERE id = %s", tuple(values))
        conn.commit()
    except Exception as e:
        conn.rollback()
        cursor.close()
        conn.close()
        return jsonify({'error': str(e)}), 400
    cursor.close()
    conn.close()
    return jsonify({'success': True})

@auth_bp.route('/api/users/<int:user_id>', methods=['DELETE'])
@require_role('admin')
def delete_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
        conn.commit()
    except Exception as e:
        conn.rollback()
        cursor.close()
        conn.close()
        return jsonify({'error': str(e)}), 400
    cursor.close()
    conn.close()
    return jsonify({'success': True})

@auth_bp.route('/api/member-data-latest', methods=['GET'])
@require_role('admin')
def get_member_data_latest():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT userID, username FROM member_data_latest ORDER BY username")
    members = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(members)

@auth_bp.route('/api/my-team-tag', methods=['GET'])
@require_role('admin', 'teamadmin')
def get_my_team_tag():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'Not logged in'}), 401
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT userID FROM users WHERE id = %s', (user_id,))
    user = cursor.fetchone()
    if not user or not user['userID']:
        cursor.close()
        conn.close()
        return jsonify({'error': 'No userID set for this user'}), 404
    cursor.execute('SELECT teamID FROM member_data_latest WHERE userID = %s', (user['userID'],))
    member = cursor.fetchone()
    if not member or not member['teamID']:
        cursor.close()
        conn.close()
        return jsonify({'error': 'No teamID found for this user'}), 404
    cursor.execute('SELECT Tag FROM team_data_latest WHERE teamID = %s', (member['teamID'],))
    team = cursor.fetchone()
    cursor.close()
    conn.close()
    if not team or not team['Tag']:
        return jsonify({'error': 'No team tag found for this user'}), 404
    return jsonify({'teamTag': team['Tag']}) 