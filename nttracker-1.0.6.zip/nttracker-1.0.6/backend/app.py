from flask import Flask, jsonify, request, send_from_directory, make_response
from flask_cors import CORS
import os
from dotenv import load_dotenv
from utils.db import get_db_connection, test_connection
from datetime import datetime
import sqlite3
import urllib.parse
import traceback
import logging
import sys
import re
import unicodedata
from auth import auth_bp, require_role
#from openpyxl import Workbook
#from openpyxl.styles import Font, PatternFill, Alignment
#from openpyxl.utils.exceptions import IllegalCharacterError
import io

# Load environment variables
load_dotenv()

# Configure logging to always go to stdout
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
handler.setFormatter(formatter)
root = logging.getLogger()
root.setLevel(logging.INFO)
if not root.handlers:
    root.addHandler(handler)
else:
    root.handlers = []
    root.addHandler(handler)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Allow all origins in development
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'dev_secret_key')
app.register_blueprint(auth_bp)

# Test DB connection at startup
logger.info("Testing database connection...")
if test_connection():
    logger.info("Database connection successful")
else:
    logger.error("Database connection failed")

def sanitize_excel_value(value):
    """
    Sanitize a value to be written to an Excel cell.
    Removes control characters that are illegal in XML.
    """
    if isinstance(value, str):
        # Regex to remove control characters, except for tab, newline, and carriage return
        return re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F]', '', value)
    return value

@app.route('/api/team-tags', methods=['GET'])
def get_team_tags():
    try:
        print("Attempting to connect to database...")  # Debug log
        conn = get_db_connection()
        if conn is None:
            print("Database connection failed")  # Debug log
            return jsonify({"error": "Could not connect to database"}), 500
            
        print("Database connection successful")  # Debug log
        cursor = conn.cursor(dictionary=True)
        print("Executing query...")  # Debug log
        cursor.execute("SELECT DISTINCT Tag FROM team_data_latest ORDER BY Tag")
        tags = [row['Tag'] for row in cursor.fetchall()]
        print(f"Found {len(tags)} tags")  # Debug log
        cursor.close()
        conn.close()
        return jsonify(tags)
    except Exception as e:
        print(f"Error in get_team_tags: {str(e)}")  # Debug log
        return jsonify({"error": str(e)}), 500

@app.route('/api/current-display-names', methods=['GET'])
def get_current_display_names():
    try:
        tag = request.args.get('tag', '')
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        if tag:
            cursor.execute("""
                SELECT 
                    CASE 
                        WHEN m.displayname IS NULL OR m.displayname = '' 
                        THEN m.username 
                        ELSE m.displayname 
                    END as CurrentDisplayName,
                    m.username as Username,
                    t.Tag as Tag,
                    m.squad as squad,
                    CASE
                        WHEN cs.CustomSquadName IS NULL OR cs.CustomSquadName = ''
                        THEN m.squad
                        ELSE cs.CustomSquadName
                    END as SquadName,
                    DATE_FORMAT(m.joinStamp, '%m/%d/%y') as Joined,
                    m.played as TeamRaces,
                    m.racesPlayed as LifetimeRaces,
                    ROUND(m.avgSpeed, 1) as AvgWPM,
                    m.highestSpeed as TopWPM,
                    m.bot as bot,
                    CASE
                        WHEN m.avgSpeed >= t.thresholdA THEN 'A'
                        WHEN m.avgSpeed >= t.thresholdB THEN 'B'
                        ELSE 'C'
                    END as Tier
                FROM team_data_latest t
                JOIN member_data_latest m ON t.teamID = m.teamID AND t.timestamp = m.timestamp
                LEFT JOIN CustomSquadName cs ON m.teamID = cs.teamID AND m.squad = cs.squad
                WHERE t.Tag = %s
                ORDER BY m.joinStamp ASC
            """, (tag,))
        else:
            cursor.execute("""
                SELECT 
                    CASE 
                        WHEN m.displayname IS NULL OR m.displayname = '' 
                        THEN m.username 
                        ELSE m.displayname 
                    END as CurrentDisplayName,
                    m.username as Username,
                    t.Tag as Tag,
                    m.squad as squad,
                    CASE
                        WHEN cs.CustomSquadName IS NULL OR cs.CustomSquadName = ''
                        THEN m.squad
                        ELSE cs.CustomSquadName
                    END as SquadName,
                    DATE_FORMAT(m.joinStamp, '%m/%d/%y') as Joined,
                    m.played as TeamRaces,
                    m.racesPlayed as LifetimeRaces,
                    ROUND(m.avgSpeed, 1) as AvgWPM,
                    m.highestSpeed as TopWPM,
                    m.bot as bot,
                    CASE
                        WHEN m.avgSpeed >= t.thresholdA THEN 'A'
                        WHEN m.avgSpeed >= t.thresholdB THEN 'B'
                        ELSE 'C'
                    END as Tier
                FROM team_data_latest t
                JOIN member_data_latest m ON t.teamID = m.teamID AND t.timestamp = m.timestamp
                LEFT JOIN CustomSquadName cs ON m.teamID = cs.teamID AND m.squad = cs.squad
                ORDER BY m.joinStamp ASC
            """)
        
        display_names = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(display_names)
    except Exception as e:
        print('Exception in /api/current-display-names:')
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@app.route('/api/update-member-squad', methods=['POST', 'OPTIONS'])
def update_member_squad():
    if request.method == 'OPTIONS':
        response = make_response()
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST')
        return response

    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        if 'username' not in data or 'squad' not in data:
            return jsonify({'error': 'Missing username or squad'}), 400

        username = data['username']
        squad = data['squad']

        conn = get_db_connection()
        cursor = conn.cursor()
        
        # First check if the username exists
        cursor.execute('SELECT Username FROM member_data_latest WHERE Username = %s', (username,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({'error': f'User {username} not found'}), 404

        # Update the squad
        cursor.execute(
            'UPDATE member_data_latest SET squad = %s WHERE Username = %s',
            (squad if squad != 'Unassigned' else None, username)
        )
        
        if cursor.rowcount == 0:
            conn.close()
            return jsonify({'error': 'No rows were updated'}), 400
            
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': f'Squad updated successfully for {username}'}), 200
        
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/api/update-custom-squad-name', methods=['POST', 'OPTIONS'])
def update_custom_squad_name():
    if request.method == 'OPTIONS':
        response = make_response()
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST')
        return response

    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        if 'tag' not in data or 'squad' not in data:
            return jsonify({'error': 'Missing tag or squad'}), 400

        tag = data['tag']
        squad = data['squad']
        custom_name = data.get('customName', '')

        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if the team exists
        cursor.execute('SELECT teamID FROM team_data_latest WHERE Tag = %s', (tag,))
        team_result = cursor.fetchone()
        if not team_result:
            conn.close()
            return jsonify({'error': f'Team {tag} not found'}), 404

        team_id = team_result[0]

        # Delete existing custom squad name if it exists
        cursor.execute('DELETE FROM CustomSquadName WHERE teamID = %s AND Squad = %s', (team_id, squad))
        
        # Insert new custom squad name if provided
        if custom_name:
            cursor.execute(
                'INSERT INTO CustomSquadName (teamID, Squad, CustomSquadName) VALUES (%s, %s, %s)',
                (team_id, squad, custom_name)
            )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'message': f'Custom squad name updated for {squad}'})
        
    except Exception as e:
        print('Exception in /api/update-custom-squad-name:')
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@app.route('/api/unassign-all-members', methods=['POST', 'OPTIONS'])
def unassign_all_members():
    if request.method == 'OPTIONS':
        response = make_response()
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST')
        return response

    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        if 'tag' not in data:
            return jsonify({'error': 'Missing team tag'}), 400

        tag = data['tag']

        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Update all members of the team to have squad = NULL
        cursor.execute("""
            UPDATE member_data_latest 
            SET squad = NULL 
            WHERE teamID IN (SELECT teamID FROM team_data_latest WHERE Tag = %s)
        """, (tag,))
        
        affected_rows = cursor.rowcount
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True, 
            'message': f'Unassigned {affected_rows} members from all squads'
        })
        
    except Exception as e:
        print('Exception in /api/unassign-all-members:')
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@app.route('/api/insert-squad-record', methods=['POST', 'OPTIONS'])
def insert_squad_record():
    if request.method == 'OPTIONS':
        response = make_response()
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST')
        return response

    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        if 'tag' not in data or 'squad' not in data:
            return jsonify({'error': 'Missing tag or squad'}), 400

        tag = data['tag']
        squad = data['squad']

        conn = get_db_connection()
        cursor = conn.cursor()
        
        # First get the teamID for the tag
        cursor.execute('SELECT teamID FROM team_data_latest WHERE Tag = %s', (tag,))
        team_result = cursor.fetchone()
        
        if not team_result:
            conn.close()
            return jsonify({'error': f'Team with tag {tag} not found'}), 404

        team_id = team_result[0]

        # Check if record already exists
        cursor.execute(
            'SELECT * FROM CustomSquadName WHERE teamID = %s AND squad = %s',
            (team_id, squad)
        )
        exists = cursor.fetchone()

        if exists:
            conn.close()
            return jsonify({'error': f'Record already exists for {tag} {squad}'}), 400

        # Insert new record with NULL CustomSquadName
        cursor.execute(
            'INSERT INTO CustomSquadName (teamID, squad, CustomSquadName) VALUES (%s, %s, NULL)',
            (team_id, squad)
        )
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True, 
            'message': f'Successfully added record for {tag} {squad}'
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/api/team-events', methods=['GET'])
def get_team_events():
    try:
        tag = request.args.get('tag', '')
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        if tag:
            cursor.execute("""
                SELECT 
                    EventID,
                    Title,
                    Description,
                    TeamTag,
                    DATE_FORMAT(StartTime, '%m/%d/%y %l:%i %p') as StartTime,
                    DATE_FORMAT(EndTime, '%m/%d/%y %l:%i %p') as EndTime,
                    DefaultSort,
                    MinRaces,
                    QualifyingRaces,
                    RaceIncrement,
                    PayoutIncrement,
                    Cap,
                    AccBonus96,
                    AccBonus98,
                    CASE
                        WHEN CONVERT_TZ(NOW(), 'UTC', 'America/Chicago') < StartTime THEN 'Pending'
                        WHEN CONVERT_TZ(NOW(), 'UTC', 'America/Chicago') BETWEEN StartTime AND EndTime THEN 'Active'
                        ELSE 'Concluded'
                    END as Status
                FROM events
                WHERE TeamTag LIKE CONCAT('%', %s, '%')
                ORDER BY StartTime DESC
            """, (tag,))
        else:
            cursor.execute("""
                SELECT 
                    EventID,
                    Title,
                    Description,
                    TeamTag,
                    DATE_FORMAT(StartTime, '%m/%d/%y %l:%i %p') as StartTime,
                    DATE_FORMAT(EndTime, '%m/%d/%y %l:%i %p') as EndTime,
                    DefaultSort,
                    MinRaces,
                    QualifyingRaces,
                    RaceIncrement,
                    PayoutIncrement,
                    Cap,
                    AccBonus96,
                    AccBonus98,
                    CASE
                        WHEN CONVERT_TZ(NOW(), 'UTC', 'America/Chicago') < StartTime THEN 'Pending'
                        WHEN CONVERT_TZ(NOW(), 'UTC', 'America/Chicago') BETWEEN StartTime AND EndTime THEN 'Active'
                        ELSE 'Concluded'
                    END as Status
                FROM events
                ORDER BY StartTime DESC
            """)
        
        events = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(events)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/activity', methods=['GET'])
def get_team_activity():
    try:
        tag = request.args.get('tag', '')
        if not tag:
            return jsonify({"error": "Team tag is required"}), 400
            
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get member activity for the last 24 hours
        cursor.execute("""
            SELECT 
                m.username,
                CASE 
                    WHEN m.displayname IS NULL OR m.displayname = '' 
                    THEN m.username 
                    ELSE m.displayname 
                END as displayName,
                m.squad,
                SUM(mb.racesBatch) as races,
                ROUND(AVG((mb.typedBatch / 5) / mb.secsBatch * 60), 1) as wpm,
                MAX((mb.typedBatch / 5) / mb.secsBatch * 60) as topWPM,
                MAX(mb.timestamp) as lastPlayed
            FROM member_data mb
            JOIN member_data_latest m ON mb.userID = m.userID
            JOIN team_data_latest t ON m.teamID = t.teamID
            WHERE t.tag = %s
            AND mb.timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            AND mb.secsBatch > 0
            GROUP BY m.username, m.displayname, m.squad
            ORDER BY races DESC
        """, (tag,))
        
        activity_data = cursor.fetchall()
        cursor.close()
        conn.close()
        
        # Format timestamps to ISO format
        for item in activity_data:
            if item['lastPlayed']:
                item['lastPlayed'] = item['lastPlayed'].isoformat()
        
        return jsonify(activity_data)
    except Exception as e:
        print(f"Error in get_team_activity: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/team-stats', methods=['GET'])
def get_team_stats():
    try:
        tag = request.args.get('tag', '')
        if not tag:
            return jsonify({"error": "Team tag is required"}), 400
            
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get races in the last 24 hours
        cursor.execute("""
            SELECT
                SUM(`member_data`.`racesBatch`) AS `races`
            FROM
                `member_data`
            LEFT JOIN `team_data_latest` AS `team_data_latest__via__teamID` 
                ON `member_data`.`teamID` = `team_data_latest__via__teamID`.`teamID`
            WHERE
                `member_data`.`timestamp` >= STR_TO_DATE(
                    DATE_FORMAT(
                        CAST(DATE_ADD(NOW(6), INTERVAL -1440 minute) AS datetime),
                        '%Y-%m-%d %H:%i'
                    ),
                    '%Y-%m-%d %H:%i'
                )
                AND `member_data`.`timestamp` < STR_TO_DATE(
                    DATE_FORMAT(CAST(NOW(6) AS datetime), '%Y-%m-%d %H:%i'),
                    '%Y-%m-%d %H:%i'
                )
                AND (`team_data_latest__via__teamID`.`tag` = %s)
        """, (tag,))
        
        result = cursor.fetchone()
        races = result['races'] if result and result['races'] else 0
        
        # Get average WPM in the last 24 hours
        cursor.execute("""
            SELECT
                ROUND(AVG((`member_data`.`typedBatch` / 5) / `member_data`.`secsBatch` * 60), 1) AS `avg_wpm`
            FROM
                `member_data`
            LEFT JOIN `team_data_latest` AS `team_data_latest__via__teamID` 
                ON `member_data`.`teamID` = `team_data_latest__via__teamID`.`teamID`
            WHERE
                `member_data`.`timestamp` >= STR_TO_DATE(
                    DATE_FORMAT(
                        CAST(DATE_ADD(NOW(6), INTERVAL -1440 minute) AS datetime),
                        '%Y-%m-%d %H:%i'
                    ),
                    '%Y-%m-%d %H:%i'
                )
                AND `member_data`.`timestamp` < STR_TO_DATE(
                    DATE_FORMAT(CAST(NOW(6) AS datetime), '%Y-%m-%d %H:%i'),
                    '%Y-%m-%d %H:%i'
                )
                AND (`team_data_latest__via__teamID`.`tag` = %s)
                AND `member_data`.`secsBatch` > 0
        """, (tag,))
        
        result = cursor.fetchone()
        avg_wpm = result['avg_wpm'] if result and result['avg_wpm'] else 0
        
        # Get accuracy in the last 24 hours
        cursor.execute("""
            SELECT
                ROUND((1 - SUM(`member_data`.`errsBatch`) / SUM(`member_data`.`typedBatch`)) * 100, 1) AS `accuracy`
            FROM
                `member_data`
            LEFT JOIN `team_data_latest` AS `team_data_latest__via__teamID` 
                ON `member_data`.`teamID` = `team_data_latest__via__teamID`.`teamID`
            WHERE
                `member_data`.`timestamp` >= STR_TO_DATE(
                    DATE_FORMAT(
                        CAST(DATE_ADD(NOW(6), INTERVAL -1440 minute) AS datetime),
                        '%Y-%m-%d %H:%i'
                    ),
                    '%Y-%m-%d %H:%i'
                )
                AND `member_data`.`timestamp` < STR_TO_DATE(
                    DATE_FORMAT(CAST(NOW(6) AS datetime), '%Y-%m-%d %H:%i'),
                    '%Y-%m-%d %H:%i'
                )
                AND (`team_data_latest__via__teamID`.`tag` = %s)
                AND `member_data`.`typedBatch` > 0
        """, (tag,))
        
        result = cursor.fetchone()
        accuracy = result['accuracy'] if result and result['accuracy'] else 0
        
        # Get active members in the last 24 hours
        cursor.execute("""
            SELECT
                COUNT(DISTINCT `member_data`.`userID`) AS `active_members`
            FROM
                `member_data`
            LEFT JOIN `team_data_latest` AS `team_data_latest__via__teamID` 
                ON `member_data`.`teamID` = `team_data_latest__via__teamID`.`teamID`
            WHERE
                `member_data`.`timestamp` >= STR_TO_DATE(
                    DATE_FORMAT(
                        CAST(DATE_ADD(NOW(6), INTERVAL -1440 minute) AS datetime),
                        '%Y-%m-%d %H:%i'
                    ),
                    '%Y-%m-%d %H:%i'
                )
                AND `member_data`.`timestamp` < STR_TO_DATE(
                    DATE_FORMAT(CAST(NOW(6) AS datetime), '%Y-%m-%d %H:%i'),
                    '%Y-%m-%d %H:%i'
                )
                AND (`team_data_latest__via__teamID`.`tag` = %s)
                AND `member_data`.`racesBatch` > 0
        """, (tag,))
        
        result = cursor.fetchone()
        active_members = result['active_members'] if result and result['active_members'] else 0

        # Get top racer in the last 24 hours
        cursor.execute("""
            SELECT 
                CASE 
                    WHEN mdl.displayname IS NULL OR mdl.displayname = '' 
                    THEN mdl.username 
                    ELSE mdl.displayname 
                END as top_racer,
                SUM(m.racesBatch) as total_races
            FROM member_data m
            JOIN member_data_latest mdl ON m.userID = mdl.userID
            JOIN team_data_latest t ON mdl.teamID = t.teamID
            WHERE t.tag = %s
            AND m.timestamp >= STR_TO_DATE(
                DATE_FORMAT(
                    CAST(DATE_ADD(NOW(6), INTERVAL -1440 minute) AS datetime),
                    '%Y-%m-%d %H:%i'
                ),
                '%Y-%m-%d %H:%i'
            )
            AND m.timestamp < STR_TO_DATE(
                DATE_FORMAT(CAST(NOW(6) AS datetime), '%Y-%m-%d %H:%i'),
                '%Y-%m-%d %H:%i'
            )
            GROUP BY mdl.userID, mdl.username, mdl.displayname
            ORDER BY total_races DESC
            LIMIT 1
        """, (tag,))
        
        result = cursor.fetchone()
        top_racer = result['top_racer'] if result and result['top_racer'] else 'N/A'
        
        # Get top racer in the last 7 days
        cursor.execute("""
            SELECT 
                CASE 
                    WHEN mdl.displayname IS NULL OR mdl.displayname = '' 
                    THEN mdl.username 
                    ELSE mdl.displayname 
                END as top_racer_7d,
                SUM(m.racesBatch) as total_races
            FROM member_data m
            JOIN member_data_latest mdl ON m.userID = mdl.userID
            JOIN team_data_latest t ON mdl.teamID = t.teamID
            WHERE t.tag = %s
            AND m.timestamp >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY mdl.userID, mdl.username, mdl.displayname
            ORDER BY total_races DESC
            LIMIT 1
        """, (tag,))
        
        result = cursor.fetchone()
        top_racer_7d = result['top_racer_7d'] if result and result['top_racer_7d'] else 'N/A'
        
        cursor.close()
        conn.close()
        
        return jsonify({
            "races": races,
            "avg_wpm": avg_wpm,
            "accuracy": accuracy,
            "active_members": active_members,
            "top_racer": top_racer,
            "top_racer_7d": top_racer_7d
        })
    except Exception as e:
        print(f"Error in get_team_stats: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/hourly-races', methods=['GET'])
def get_hourly_races():
    try:
        tag = request.args.get('tag', '')
        if not tag:
            return jsonify({"error": "Team tag is required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Get the teamID for the tag
        cursor.execute("SELECT teamID FROM team_data_latest WHERE tag = %s LIMIT 1", (tag,))
        team_row = cursor.fetchone()
        if not team_row:
            cursor.close()
            conn.close()
            return jsonify([])

        teamID = team_row['teamID']

        cursor.execute("""
            SELECT 
                DATE_FORMAT(m.batchEndTime, '%Y-%m-%d %H:00:00') as hour,
                CASE 
                    WHEN mdl.displayname IS NULL OR mdl.displayname = '' 
                    THEN mdl.username 
                    ELSE mdl.displayname 
                END as racer,
                SUM(m.racesBatch) as races
            FROM member_data m
            JOIN member_data_latest mdl ON m.userID = mdl.userID
            WHERE m.teamID = %s
            AND m.batchEndTime >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            GROUP BY hour, mdl.userID, mdl.username, mdl.displayname
            ORDER BY hour ASC, races DESC
        """, (teamID,))

        results = cursor.fetchall()
        cursor.close()
        conn.close()

        return jsonify(results)

    except Exception as e:
        print(f"Error in get_hourly_races: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/daily-races', methods=['GET'])
def get_daily_races():
    try:
        tag = request.args.get('tag', '')
        if not tag:
            return jsonify({"error": "Team tag is required"}), 400
            
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT
                DATE_FORMAT(source.actual_date, '%M %d, %Y') AS date,
                source.sum AS total_races
            FROM (
                SELECT
                    DATE(CONVERT_TZ(member_data.batchEndTime, 'UTC', 'America/Chicago')) as actual_date,
                    SUM(member_data.racesBatch) AS sum
                FROM member_data
                LEFT JOIN team_data_latest AS team_data_latest__via__teamID 
                    ON member_data.teamID = team_data_latest__via__teamID.teamID
                WHERE team_data_latest__via__teamID.tag = %s
                AND member_data.batchEndTime >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY DATE(CONVERT_TZ(member_data.batchEndTime, 'UTC', 'America/Chicago'))
                ORDER BY actual_date DESC
                LIMIT 8
            ) AS source
            ORDER BY source.actual_date DESC
        """, (tag,))
        
        results = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return jsonify(results)
        
    except Exception as e:
        print(f"Error in get_daily_races: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/weekly-races', methods=['GET'])
def get_weekly_races():
    try:
        tag = request.args.get('tag', '')
        if not tag:
            return jsonify({"error": "Team tag is required"}), 400
            
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT
                DATE_FORMAT(source.week_start, '%M %d, %Y') AS date,
                source.sum AS total_races
            FROM (
                SELECT
                    STR_TO_DATE(
                        CONCAT(YEARWEEK(CONVERT_TZ(member_data.batchEndTime, 'UTC', 'America/Chicago')), ' Sunday'),
                        '%X%V %W'
                    ) AS week_start,
                    SUM(member_data.racesBatch) AS sum
                FROM member_data
                LEFT JOIN team_data_latest AS team_data_latest__via__teamID 
                    ON member_data.teamID = team_data_latest__via__teamID.teamID
                WHERE team_data_latest__via__teamID.tag = %s
                AND member_data.batchEndTime >= DATE_SUB(NOW(), INTERVAL 8 WEEK)
                GROUP BY STR_TO_DATE(
                    CONCAT(YEARWEEK(CONVERT_TZ(member_data.batchEndTime, 'UTC', 'America/Chicago')), ' Sunday'),
                    '%X%V %W'
                )
                ORDER BY week_start DESC
                LIMIT 8
            ) AS source
            ORDER BY source.week_start DESC
        """, (tag,))
        
        results = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return jsonify(results)
        
    except Exception as e:
        print(f"Error in get_weekly_races: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/admin/events', methods=['POST'])
def admin_add_event():
    try:
        data = request.get_json()
        required = ['Title', 'Description', 'TeamTag', 'StartTime', 'EndTime', 'DefaultSort']
        if not all(k in data for k in required):
            return jsonify({'error': 'Missing required fields'}), 400
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            INSERT INTO events (Title, Description, TeamTag, StartTime, EndTime, DefaultSort)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (data['Title'], data['Description'], data['TeamTag'], data['StartTime'], data['EndTime'], data['DefaultSort']))
        conn.commit()
        event_id = cursor.lastrowid
        cursor.execute("""
            SELECT 
                EventID,
                Title,
                Description,
                TeamTag,
                StartTime,
                EndTime,
                DefaultSort,
                CASE
                    WHEN CONVERT_TZ(NOW(), 'UTC', 'America/Chicago') < StartTime THEN 'Pending'
                    WHEN CONVERT_TZ(NOW(), 'UTC', 'America/Chicago') BETWEEN StartTime AND EndTime THEN 'Active'
                    ELSE 'Concluded'
                END as Status
            FROM events
            WHERE EventID = %s
        """, (event_id,))
        new_event = cursor.fetchone()
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'event': new_event}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/events/<int:event_id>', methods=['PUT'])
def admin_edit_event(event_id):
    try:
        data = request.get_json()
        fields = [
            'Title', 'Description', 'TeamTag', 'StartTime', 'EndTime', 'DefaultSort',
            'MinRaces', 'QualifyingRaces', 'RaceIncrement', 'PayoutIncrement', 'Cap', 'AccBonus96', 'AccBonus98'
        ]
        updates = []
        values = []
        for f in fields:
            if f in data:
                updates.append(f"{f} = %s")
                values.append(data[f])
        if not updates:
            return jsonify({'error': 'No fields to update'}), 400
        values.append(event_id)
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(f"""
            UPDATE events SET {', '.join(updates)} WHERE EventID = %s
        """, tuple(values))
        conn.commit()
        cursor.execute("""
            SELECT 
                EventID,
                Title,
                Description,
                TeamTag,
                StartTime,
                EndTime,
                DefaultSort,
                CASE
                    WHEN CONVERT_TZ(NOW(), 'UTC', 'America/Chicago') < StartTime THEN 'Pending'
                    WHEN CONVERT_TZ(NOW(), 'UTC', 'America/Chicago') BETWEEN StartTime AND EndTime THEN 'Active'
                    ELSE 'Concluded'
                END as Status
            FROM events
            WHERE EventID = %s
        """, (event_id,))
        updated_event = cursor.fetchone()
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'event': updated_event})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/events/<int:event_id>', methods=['DELETE'])
def admin_delete_event(event_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # First delete from EventTags
        cursor.execute("DELETE FROM EventTags WHERE EventID = %s", (event_id,))
        # Then delete from events
        cursor.execute("DELETE FROM events WHERE EventID = %s", (event_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'message': f'Event {event_id} deleted'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/daily-participants', methods=['GET'])
def get_daily_participants():
    try:
        tag = request.args.get('tag', '')
        date = request.args.get('date', '')
        if not tag or not date:
            return jsonify({"error": "Team tag and date are required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            WITH source AS (
                SELECT
                    md.userID AS userID,
                    md.teamID AS teamID,
                    md.racesBatch AS racesBatch,
                    md.secsBatch AS secsBatch,
                    md.typedBatch AS typedBatch,
                    md.errsBatch AS errsBatch,
                    md.batchEndTime AS batchEndTime,
                    mdl.username AS Username,
                    CASE
                        WHEN (mdl.displayName IS NULL OR mdl.displayName = '') THEN mdl.username
                        ELSE mdl.displayName
                    END AS CurrentDisplayName,
                    tdl.teamID AS tdl_teamID,
                    tdl.tag AS TeamTag,
                    mdl.Squad AS Squad,
                    CASE
                        WHEN cs.CustomSquadName IS NULL OR cs.CustomSquadName = '' THEN mdl.Squad
                        ELSE cs.CustomSquadName
                    END AS SquadName
                FROM member_data md
                LEFT JOIN team_data_latest tdl ON md.teamID = tdl.teamID
                LEFT JOIN member_data_latest mdl ON md.userID = mdl.userID
                LEFT JOIN CustomSquadName cs ON mdl.teamID = cs.teamID AND mdl.Squad = cs.Squad
                WHERE tdl.tag = %s
                  AND DATE(CONVERT_TZ(md.batchEndTime, 'UTC', 'America/Chicago')) = %s
            )
            SELECT
                source.CurrentDisplayName AS CurrentDisplayName,
                source.userID AS UserID,
                source.Username AS Username,
                source.TeamTag AS TeamTag,
                source.Squad AS Squad,
                source.SquadName AS SquadName,
                SUM(source.racesBatch) AS TotalRaces,
                1 - (SUM(source.errsBatch) / NULLIF(SUM(source.typedBatch), 0)) AS Accuracy,
                ((SUM(source.typedBatch) / 5.0) / NULLIF(SUM(source.secsBatch), 0)) * 60 AS WPM,
                SUM(source.racesBatch) * (1 - (SUM(source.errsBatch) / NULLIF(SUM(source.typedBatch), 0))) * (100 + (((SUM(source.typedBatch) / 5.0) / NULLIF(SUM(source.secsBatch), 0)) * 60 / 2.0)) AS Points
            FROM source
            GROUP BY source.CurrentDisplayName, source.userID, source.Username, source.TeamTag, source.Squad, source.SquadName
            ORDER BY TotalRaces DESC, source.CurrentDisplayName ASC, source.userID ASC
            LIMIT 2000;
        """, (tag, date))
        
        results = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return jsonify({"participants": results})
        
    except Exception as e:
        print(f"Error in get_daily_participants: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/weekly-participants', methods=['GET'])
def get_weekly_participants():
    try:
        tag = request.args.get('tag', '')
        week = request.args.get('week', '')  # week is a YYYY-MM-DD string (Sunday)
        if not tag or not week:
            return jsonify({"error": "Team tag and week are required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT
              source.CurrentDisplayName AS CurrentDisplayName,
              source.MemberStatus AS MemberStatus,
              source.Username AS Username,
              source.TeamTag AS TeamTag,
              source.Squad AS Squad,
              source.SquadName AS SquadName,
              source.sum AS TotalRaces,
              source.sum_2 AS TotalTyped,
              source.sum_3 AS TotalErrors,
              source.sum_4 AS TotalSeconds,
              1 - (source.sum_3 / NULLIF(source.sum_2, 0)) AS Accuracy,
              source.sum * (1 - (source.sum_3 / NULLIF(source.sum_2, 0))) * (100 + (((source.sum_2 / 5.0) / NULLIF(source.sum_4, 0)) * 60 / 2.0)) AS Points,
              ((source.sum_2 / 5.0) / NULLIF(source.sum_4, 0)) * 60 AS WPM
            FROM (
              SELECT
                inner_source.CurrentDisplayName AS CurrentDisplayName,
                inner_source.MemberStatus AS MemberStatus,
                inner_source.Username AS Username,
                inner_source.TeamTag AS TeamTag,
                inner_source.Squad AS Squad,
                inner_source.SquadName AS SquadName,
                SUM(inner_source.racesBatch) AS sum,
                SUM(inner_source.typedBatch) AS sum_2,
                SUM(inner_source.errsBatch) AS sum_3,
                SUM(inner_source.secsBatch) AS sum_4
              FROM (
                SELECT
                  m.userID AS userID,
                  m.teamID AS teamID,
                  m.racesBatch AS racesBatch,
                  m.secsBatch AS secsBatch,
                  m.typedBatch AS typedBatch,
                  m.errsBatch AS errsBatch,
                  m.batchEndTime AS batchEndTime,
                  mdl.username AS Username,
                  CASE
                    WHEN (mdl.displayName IS NULL OR mdl.displayName = '') THEN mdl.username
                    ELSE mdl.displayName
                  END AS CurrentDisplayName,
                  CASE
                    WHEN mdl.timestamp < tdl.timestamp THEN 'Inactive'
                    ELSE 'Active'
                  END AS MemberStatus,
                  tdl.tag AS TeamTag,
                  CASE
                    WHEN cs.CustomSquadName IS NULL OR cs.CustomSquadName = '' THEN mdl.Squad
                    ELSE cs.CustomSquadName
                  END AS SquadName,
                  mdl.Squad AS Squad
                FROM member_data m
                LEFT JOIN team_data_latest tdl ON m.teamID = tdl.teamID
                LEFT JOIN member_data_latest mdl ON m.userID = mdl.userID
                LEFT JOIN CustomSquadName cs ON m.teamID = cs.teamID AND mdl.Squad = cs.Squad
                WHERE
                  DATE(CONVERT_TZ(m.batchEndTime, 'UTC', 'America/Chicago')) >= %s
                  AND DATE(CONVERT_TZ(m.batchEndTime, 'UTC', 'America/Chicago')) < DATE_ADD(%s, INTERVAL 7 DAY)
                  AND tdl.tag = %s
              ) AS inner_source
              GROUP BY inner_source.CurrentDisplayName, inner_source.MemberStatus, inner_source.Username, inner_source.TeamTag, inner_source.Squad, inner_source.SquadName
            ) AS source
            ORDER BY source.sum DESC, source.CurrentDisplayName ASC, source.MemberStatus ASC, source.Username ASC
            LIMIT 2000;
        """, (week, week, tag))
        
        participants = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify({"participants": participants})
    except Exception as e:
        print(f"Error in get_weekly_participants: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/all-usernames', methods=['GET'])
def get_all_usernames():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT username FROM member_data_latest ORDER BY username ASC")
        usernames = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return jsonify({'usernames': usernames})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/racer-info', methods=['GET'])
def get_racer_info():
    username = request.args.get('username', '')
    if not username:
        return jsonify({'error': 'Username is required'}), 400
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('''
            SELECT 
                m.displayName,
                m.username,
                m.userID,
                t.Tag as teamTag,
                m.role,
                m.racesPlayed,
                m.played,
                ROUND(m.avgSpeed, 1) as avgSpeed,
                m.highestSpeed,
                m.joinStamp,
                m.bot as bot
            FROM member_data_latest m
            LEFT JOIN team_data_latest t ON m.teamID = t.teamID
            WHERE m.username = %s
            LIMIT 1
        ''', (username,))
        racer = cursor.fetchone()
        cursor.close()
        conn.close()
        if not racer:
            return jsonify({'error': 'Racer not found'}), 404
        return jsonify(racer)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/racer-batches', methods=['GET'])
def get_racer_batches():
    username = request.args.get('username', '')
    if not username:
        return jsonify({'error': 'Username is required'}), 400
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('''
            SELECT
              source.batchEndTime AS batchEndTime,
              source.CurrentDisplayName AS CurrentDisplayName,
              source.team_data_latest__via__teamID__tag AS teamTag,
              source.sum AS sum,
              source.WPM AS WPM,
              source.Accuracy AS Accuracy,
              source.racesPlayedBatch AS racesPlayedBatch   
            FROM (
              SELECT
                STR_TO_DATE(
                  DATE_FORMAT(CAST(source.batchEndTime AS datetime), '%Y-%m-%d %H:%i'),
                  '%Y-%m-%d %H:%i'
                ) AS batchEndTime,
                source.CurrentDisplayName AS CurrentDisplayName,
                source.team_data_latest__via__teamID__tag AS team_data_latest__via__teamID__tag,
                SUM(source.racesBatch) AS sum,
                SUM(source.racesPlayedBatch) AS racesPlayedBatch,
                ((SUM(source.typedBatch) / 5.0) / NULLIF(SUM(source.secsBatch), 0)) * 60 AS WPM,
                1 - (SUM(source.errsBatch) / NULLIF(SUM(source.typedBatch), 0)) AS Accuracy
              FROM (
                SELECT
                  member_data.userID AS userID,
                  member_data.teamID AS teamID,
                  member_data.username AS username,
                  member_data.racesBatch AS racesBatch,
                  member_data.racesPlayedBatch AS racesPlayedBatch,
                  member_data.secsBatch AS secsBatch,
                  member_data.typedBatch AS typedBatch,
                  member_data.errsBatch AS errsBatch,
                  member_data.batchEndTime AS batchEndTime,
                  CASE
                    WHEN (member_data_latest__via__userID.displayName IS NULL OR member_data_latest__via__userID.displayName = '') THEN member_data.username
                    ELSE member_data_latest__via__userID.displayName
                  END AS CurrentDisplayName,
                  team_data_latest__via__teamID.teamID AS team_data_latest__via__teamID__teamID,
                  member_data_latest__via__userID.userID AS member_data_latest__via__userID__userID,
                  member_data_latest__via__userID.displayName AS member_data_latest__via__userID__displayName,
                  team_data_latest__via__teamID.tag AS team_data_latest__via__teamID__tag
                FROM member_data
                LEFT JOIN team_data_latest AS team_data_latest__via__teamID ON member_data.teamID = team_data_latest__via__teamID.teamID
                LEFT JOIN member_data_latest AS member_data_latest__via__userID ON member_data.userID = member_data_latest__via__userID.userID
                WHERE (member_data.racesBatch > 0) AND (member_data.username = %s)
              ) AS source
              GROUP BY
                STR_TO_DATE(
                  DATE_FORMAT(CAST(source.batchEndTime AS datetime), '%Y-%m-%d %H:%i'),
                  '%Y-%m-%d %H:%i'
                ),
                source.CurrentDisplayName,
                source.team_data_latest__via__teamID__tag
              ORDER BY
                STR_TO_DATE(
                  DATE_FORMAT(CAST(source.batchEndTime AS datetime), '%Y-%m-%d %H:%i'),
                  '%Y-%m-%d %H:%i'
                ) DESC,
                STR_TO_DATE(
                  DATE_FORMAT(CAST(source.batchEndTime AS datetime), '%Y-%m-%d %H:%i'),
                  '%Y-%m-%d %H:%i'
                ) ASC,
                source.CurrentDisplayName ASC,
                source.team_data_latest__via__teamID__tag ASC
            ) AS source
            LIMIT 1048575
        ''', (username,))
        batches = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify({'batches': batches})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/team-leaderboard', methods=['GET'])
def get_team_leaderboard():
    try:
        start_time = request.args.get('start_time')
        end_time = request.args.get('end_time')
        showbot = request.args.get('showbot', 'FALSE').upper() == 'TRUE'
        
        if not start_time or not end_time:
            return jsonify({"error": "Start time and end time are required"}), 400
            
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            WITH filtered_member_data AS (
                SELECT 
                    md.teamID,
                    md.batchEndTime,
                    md.racesBatch,
                    md.errsBatch,
                    md.typedBatch,
                    md.secsBatch,
                    mdl.bot
                FROM member_data md
                JOIN member_data_latest mdl ON md.userID = mdl.userID
                WHERE CONVERT_TZ(md.batchEndTime, 'UTC', 'America/Chicago') BETWEEN %s AND %s
                  AND md.racesBatch > 0
                  AND (%s OR COALESCE(mdl.bot, 0) = 0)
            ),
            aggregated_data AS (
                SELECT  
                    td.tag AS TeamTag, 
                    SUM(fm.racesBatch) AS Races,
                    1 - (SUM(fm.errsBatch) / NULLIF(SUM(fm.typedBatch), 0)) AS Accuracy,
                    ((SUM(fm.typedBatch) / 5.0) / NULLIF(SUM(fm.secsBatch), 0)) * 60 AS WPM,
                    SUM(fm.racesBatch) * 
                    (1 - (SUM(fm.errsBatch) / NULLIF(SUM(fm.typedBatch), 0))) * 
                    (100 + (((SUM(fm.typedBatch) / 5.0) / NULLIF(SUM(fm.secsBatch), 0)) * 60 / 2.0)) AS Points
                FROM team_data_latest td
                INNER JOIN filtered_member_data fm ON td.teamID = fm.teamID
                GROUP BY td.tag
            )
            SELECT * 
            FROM aggregated_data
            ORDER BY Points DESC, TeamTag ASC
            LIMIT 2000;
        """, (start_time, end_time, showbot))
        
        team_data = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return jsonify(team_data)
    except Exception as e:
        print(f"Error in get_team_leaderboard: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/individual-leaderboard', methods=['GET'])
def get_individual_leaderboard():
    try:
        start_time = request.args.get('start_time')
        end_time = request.args.get('end_time')
        if not start_time or not end_time:
            return jsonify({"error": "Start time and end time are required"}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            WITH filtered_member_data AS (
                SELECT 
                    userID, batchEndTime, racesBatch, errsBatch, typedBatch, secsBatch
                FROM member_data
                WHERE CONVERT_TZ(batchEndTime, 'UTC', 'America/Chicago') BETWEEN %s AND %s
                  AND racesBatch > 0
            ),
            aggregated_data AS (
                SELECT  
                    fmd.userID AS UserID,
                    mdl.username AS Username,
                    CASE 
                        WHEN mdl.displayName IS NULL OR mdl.displayName = '' THEN mdl.username
                        ELSE mdl.displayName
                    END AS CurrentDisplayName,
                    mdl.teamID AS TeamID,
                    mdl.bot AS bot,
                    SUM(fmd.racesBatch) AS Races,
                    1 - (SUM(fmd.errsBatch) / NULLIF(SUM(fmd.typedBatch), 0)) AS Accuracy,
                    ((SUM(fmd.typedBatch) / 5.0) / NULLIF(SUM(fmd.secsBatch), 0)) * 60 AS WPM,
                    SUM(fmd.racesBatch) * 
                    (1 - (SUM(fmd.errsBatch) / NULLIF(SUM(fmd.typedBatch), 0))) * 
                    (100 + (((SUM(fmd.typedBatch) / 5.0) / NULLIF(SUM(fmd.secsBatch), 0)) * 60 / 2.0)) AS Points
                FROM filtered_member_data fmd
                LEFT JOIN member_data_latest mdl ON fmd.userID = mdl.userID
                GROUP BY fmd.userID, mdl.username, mdl.displayName, mdl.teamID, mdl.bot
            )
            SELECT 
                ad.*, 
                tdl.Tag AS TeamTag
            FROM aggregated_data ad
            LEFT JOIN team_data_latest tdl ON ad.TeamID = tdl.teamID
            ORDER BY Points DESC, Username ASC
            LIMIT 2000;
        """, (start_time, end_time))
        data = cursor.fetchall()
        cursor.close()
        conn.close()
        
        return jsonify(data)
    except Exception as e:
        print(f"Error in get_individual_leaderboard: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/team-info', methods=['GET'])
def get_team_info():
    tag = request.args.get('tag', '')
    if not tag:
        return jsonify({'error': 'Team tag is required'}), 400
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('''
            SELECT 
                Tag,
                name,
                tagColor,
                createdStamp,
                displayName AS captain,
                username,
                min_races,
                min_speed,
                WeeklyRequirements,
                otherRequirements
            FROM team_data_latest
            WHERE Tag = %s
            LIMIT 1
        ''', (tag,))
        team = cursor.fetchone()
        cursor.close()
        conn.close()
        if not team:
            return jsonify({'error': 'Team not found'}), 404
        # Convert createdStamp (int) to ISO date string if present
        if team.get('createdStamp'):
            try:
                team['createdStamp'] = datetime.utcfromtimestamp(int(team['createdStamp'])).strftime('%Y-%m-%d')
            except Exception:
                team['createdStamp'] = str(team['createdStamp'])
        return jsonify(team)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/ping', methods=['GET'])
@require_role('admin')
def admin_ping():
    return jsonify({'message': 'Admin access granted!'})

@app.route('/api/bot-flagged-users', methods=['GET'])
def get_bot_flagged_users():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('''
            SELECT 
                CASE 
                    WHEN displayName IS NULL OR displayName = '' THEN username
                    ELSE displayName
                END AS DisplayName,
                username AS Username,
                userID AS UserID
            FROM member_data_latest
            WHERE bot = 1
            ORDER BY DisplayName ASC
        ''')
        users = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(users)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/set-bot-flag', methods=['POST'])
def set_bot_flag():
    try:
        data = request.get_json()
        username = data.get('username')
        flag = data.get('flag')  # should be 1 or None/null
        if not username:
            return jsonify({'error': 'Username required'}), 400
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE member_data_latest
            SET bot = %s
            WHERE username = %s
        ''', (flag, username))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/search-users', methods=['GET'])
def search_users():
    query = request.args.get('query', '').strip()
    if not query:
        return jsonify([])
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        # Try to match userID as integer if possible
        user_id = None
        try:
            user_id = int(query)
        except Exception:
            pass
        like_query = f"%{query}%"
        sql = '''
            SELECT 
                CASE 
                    WHEN displayName IS NULL OR displayName = '' THEN username
                    ELSE displayName
                END AS DisplayName,
                username AS Username,
                userID AS UserID,
                bot
            FROM member_data_latest
            WHERE (LOWER(displayName) LIKE LOWER(%s) OR LOWER(username) LIKE LOWER(%s)''' \
            + (" OR userID = %s" if user_id is not None else ")")
        params = [like_query, like_query]
        if user_id is not None:
            params.append(user_id)
        cursor.execute(sql, tuple(params))
        users = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(users)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/warn-list', methods=['GET'])
def get_warn_list():
    try:
        tag = request.args.get('tag', '')
        if not tag:
            return jsonify({"error": "Team tag is required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Get teamID and WeeklyRequirements for the given tag
        cursor.execute("SELECT teamID, WeeklyRequirements FROM team_data_latest WHERE tag = %s", (tag,))
        team = cursor.fetchone()
        if not team:
            cursor.close()
            conn.close()
            return jsonify({"error": "Team not found"}), 404
        team_id = team['teamID']
        weekly_requirements = team.get('WeeklyRequirements')

        # 2. Get all active members for the team
        cursor.execute("""
            SELECT 
                mdl.userID, 
                mdl.username AS Username,
                CASE 
                    WHEN mdl.displayName IS NULL OR mdl.displayName = '' THEN mdl.username
                    ELSE mdl.displayName 
                END AS CurrentDisplayName,
                mdl.joinStamp
            FROM member_data_latest mdl
            JOIN team_data_latest tdl ON mdl.teamID = tdl.teamID
            WHERE tdl.teamID = %s AND mdl.timestamp = tdl.timestamp
        """, (team_id,))
        members = cursor.fetchall()

        # 3. Get the start dates of the last 7 weeks from the database to remove pytz dependency
        cursor.execute("""
            SELECT DATE_SUB(
                (SELECT DATE_SUB(DATE(CONVERT_TZ(NOW(), 'UTC', 'America/Chicago')), INTERVAL (DAYOFWEEK(CONVERT_TZ(NOW(), 'UTC', 'America/Chicago')) - 1) DAY)),
                INTERVAL n.num WEEK
            ) AS sunday_date
            FROM (SELECT 0 AS num UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6) AS n
        """)
        sundays_rows = cursor.fetchall()
        sundays = sorted([row['sunday_date'] for row in sundays_rows])
        
        # 4. Fetch all relevant race data for these members in one go
        member_ids = [m['userID'] for m in members]
        if not member_ids:
            cursor.close()
            conn.close()
            return jsonify({ "members": [], "weeklyRequirements": weekly_requirements })

        # Using a placeholder string for the IN clause
        placeholders = ','.join(['%s'] * len(member_ids))
        # Use the oldest Sunday from our DB query as the start date
        start_date_str = sundays[0].strftime('%Y-%m-%d')

        race_query = f"""
            SELECT
                userID,
                SUM(racesBatch) AS race_count,
                DATE_SUB(
                    DATE(CONVERT_TZ(batchEndTime, 'UTC', 'America/Chicago')), 
                    INTERVAL (DAYOFWEEK(CONVERT_TZ(batchEndTime, 'UTC', 'America/Chicago')) - 1) DAY
                ) AS week_start_sunday
            FROM member_data
            WHERE userID IN ({placeholders})
            AND batchEndTime >= CONVERT_TZ(%s, 'America/Chicago', 'UTC')
            GROUP BY userID, week_start_sunday
        """
        
        query_params = tuple(member_ids) + (start_date_str,)
        cursor.execute(race_query, query_params)
        race_data = cursor.fetchall()

        # 5. Process data into a per-member structure
        races_by_user_week = {}
        for row in race_data:
            user_id = row['userID']
            week_start = row['week_start_sunday']
            if week_start is not None:
                if user_id not in races_by_user_week:
                    races_by_user_week[user_id] = {}
                races_by_user_week[user_id][week_start] = row['race_count']

        # 6. Assemble the final response
        result = []
        for member in members:
            user_id = member['userID']
            history = []
            # Iterate sundays from most recent to oldest to match frontend expectation
            for sunday_date in sorted(sundays, reverse=True):
                races = races_by_user_week.get(user_id, {}).get(sunday_date, 0)
                history.append(races)

            result.append({
                'UserID': user_id,
                'CurrentDisplayName': member['CurrentDisplayName'],
                'Username': member['Username'],
                'TeamTag': tag,
                'joinStamp': member['joinStamp'].isoformat() if member['joinStamp'] else None,
                'weeklyRaceHistory': history
            })
        
        # 7. Sort by W2 ascending (index 1 of history, which is last week's races)
        result.sort(key=lambda x: x['weeklyRaceHistory'][1] if x['weeklyRaceHistory'] and len(x['weeklyRaceHistory']) > 1 and x['weeklyRaceHistory'][1] is not None else 0)

        cursor.close()
        conn.close()

        return jsonify({
            "members": result,
            "weeklyRequirements": weekly_requirements
        })

    except Exception as e:
        print(f"Error in get_warn_list: {str(e)}")
        print(f"Full error details: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/update-weekly-requirements', methods=['POST'])
def update_weekly_requirements():
    try:
        data = request.get_json()
        tag = data.get('tag')
        requirements = data.get('requirements')

        if not tag:
            return jsonify({'error': 'Team tag is required'}), 400
        
        if requirements is not None:
            try:
                requirements = int(requirements)
                if requirements < 0:
                    raise ValueError()
            except (ValueError, TypeError):
                return jsonify({'error': 'Weekly requirements must be a non-negative integer'}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE team_data_latest
            SET WeeklyRequirements = %s
            WHERE Tag = %s
        """, (requirements, tag))
        
        if cursor.rowcount == 0:
            conn.close()
            return jsonify({'error': f'Team with tag {tag} not found or no update was needed'}), 404

        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Weekly requirements updated successfully.'})

    except Exception as e:
        logger.error(f"Error in update_weekly_requirements: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': f'An unexpected error occurred: {str(e)}'}), 500

@app.route('/api/event-data/<int:event_id>', methods=['GET'])
def get_event_data(event_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Step 1: Get Participants Data
        cursor.execute("""
            WITH aggregated_data AS (
              SELECT 
                u.username AS Username,
                CASE 
                    WHEN u.displayName IS NULL OR u.displayName = '' THEN u.username
                    ELSE u.displayName 
                END AS CurrentDisplayName,
                et.EventID AS EventID,
                u.Squad AS Squad,
                COALESCE(cs.CustomSquadName, u.Squad) AS SquadName,
                et.Tag AS TeamTag,
                SUM(md.racesBatch) AS TotalRaces,
                SUM(md.typedBatch) AS TotalTyped,
                SUM(md.errsBatch) AS TotalErrors,
                SUM(md.secsBatch) AS TotalSeconds,
                1 - (SUM(md.errsBatch) / NULLIF(SUM(md.typedBatch), 0)) AS Accuracy,
                SUM(md.racesBatch) * 
                  (1 - (SUM(md.errsBatch) / NULLIF(SUM(md.typedBatch), 0))) * 
                  (100 + (((SUM(md.typedBatch) / 5.0) / NULLIF(SUM(md.secsBatch), 0)) * 60 / 2.0)) AS Points,
                ((SUM(md.typedBatch) / 5.0) / NULLIF(SUM(md.secsBatch), 0)) * 60 AS WPM,
                u.timestamp AS member_timestamp,
                td.timestamp AS team_timestamp,
                u.bot,
                CASE
                    WHEN u.timestamp < td.timestamp OR u.teamID <> td.teamID THEN 'Inactive'
                    ELSE 'Active'
                END AS MemberStatus,
                CASE
                    WHEN u.avgSpeed >= td.thresholdA THEN 'A'
                    WHEN u.avgSpeed >= td.thresholdB THEN 'B'
                    ELSE 'C'
                END AS Tier
              FROM EventTags et
              LEFT JOIN team_data_latest td ON et.Tag = td.tag
              LEFT JOIN member_data md ON td.teamID = md.teamID
              LEFT JOIN member_data_latest u ON md.userID = u.userID
              LEFT JOIN events ev ON et.EventID = ev.EventID
              LEFT JOIN CustomSquadName cs ON u.teamID = cs.teamID AND u.Squad = cs.Squad
              WHERE CONVERT_TZ(md.batchEndTime, 'UTC', 'America/Chicago') BETWEEN ev.StartTime AND ev.EndTime
                AND et.EventID = %s
              GROUP BY 
                u.displayName, u.username, et.EventID, u.Squad, SquadName, et.Tag, u.timestamp, td.timestamp, u.teamID, td.teamID, u.bot, u.avgSpeed, td.thresholdA, td.thresholdB
            )
            SELECT *
            FROM aggregated_data
            ORDER BY Points DESC, CurrentDisplayName ASC, Username ASC, EventID ASC, Squad ASC, TeamTag ASC
            LIMIT 2000;
        """, (event_id,))
        participants = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            "participants": participants
        })
        
    except Exception as e:
        print(f"Error in get_event_data: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.getenv('BACKEND_PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=True) 