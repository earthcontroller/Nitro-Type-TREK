import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

DB_HOST = os.getenv('DB_HOST')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')
DB_PORT = os.getenv('DB_PORT')
DB_SSLMODE = os.getenv('DB_SSLMODE', 'REQUIRED')

class Config:
    """Base configuration."""
    TESTING = False
    DEBUG = False

class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    DB_HOST = DB_HOST
    DB_USER = DB_USER
    DB_PASS = DB_PASSWORD
    DB_NAME = DB_NAME
    DB_PORT = DB_PORT

class ProductionConfig(Config):
    """Production configuration."""
    DEBUG = False
    FLASK_DEBUG = False
    DB_HOST = DB_HOST
    DB_USER = DB_USER
    DB_PASS = DB_PASSWORD
    DB_NAME = DB_NAME
    DB_PORT = DB_PORT

class TestingConfig(Config):
    """Test configuration."""
    TESTING = True
    DEBUG = True

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
} 