import os
from dotenv import load_dotenv
import mysql.connector
from mysql.connector import Error
import time
import logging
import sys

# Configure logging to always go to stdout
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
handler.setFormatter(formatter)
root = logging.getLogger()
root.setLevel(logging.INFO)
if not root.handlers:
    root.addHandler(handler)
else:
    root.handlers = []
    root.addHandler(handler)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Cache the selected host at module level
_selected_host = None

# Get the path to the CA certificate
def _get_ca_cert_path():
    """Get the path to the CA certificate file"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    ca_cert_path = os.path.join(script_dir, '..', 'certs', 'do-ca-certificate.crt')
    return os.path.abspath(ca_cert_path)

def _select_host():
    """Select the best available host and cache the result"""
    global _selected_host
    
    if _selected_host is not None:
        return _selected_host
        
    vpc_host = os.getenv('DO_DB_VPC_HOST')
    public_host = os.getenv('DO_DB_HOST')
    
    logger.info(f"Environment variables:")
    logger.info(f"DO_DB_VPC_HOST: {vpc_host}")
    logger.info(f"DO_DB_HOST: {public_host}")
    
    # Try VPC host first
    if vpc_host:
        try:
            logger.info(f"Testing VPC connection to {vpc_host}...")
            connection = mysql.connector.connect(
                host=vpc_host,
                user=os.getenv('DO_DB_USER'),
                password=os.getenv('DO_DB_PASSWORD'),
                database=os.getenv('DO_DB_NAME'),
                port=int(os.getenv('DO_DB_PORT', '25060')),
                ssl_disabled=False,
                ssl_ca=_get_ca_cert_path(),
                connect_timeout=3
            )
            if connection:
                connection.close()
                logger.info(f"VPC connection successful, will use {vpc_host}")
                _selected_host = vpc_host
                return vpc_host
        except Exception as e:
            logger.warning(f"VPC connection failed: {e}")
    
    # Fall back to public host
    if public_host:
        logger.info(f"Will use public host: {public_host}")
        _selected_host = public_host
        return public_host
    
    raise Error("No database hosts configured in environment variables")

def get_db_connection():
    """Create a connection to the Digital Ocean MySQL database using the cached host selection"""
    host = _select_host()
    
    try:
        connection = mysql.connector.connect(
            host=host,
            user=os.getenv('DO_DB_USER'),
            password=os.getenv('DO_DB_PASSWORD'),
            database=os.getenv('DO_DB_NAME'),
            port=int(os.getenv('DO_DB_PORT', '25060')),
            ssl_disabled=False,
            ssl_ca=_get_ca_cert_path()
        )
        if connection:
            return connection
    except Error as e:
        logger.error(f"Error connecting to {host}: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error connecting to {host}: {e}")
        raise

def test_connection():
    """Test the database connection"""
    try:
        conn = get_db_connection()
        if conn.is_connected():
            cursor = conn.cursor()
            cursor.execute('SELECT VERSION()')
            db_version = cursor.fetchone()
            cursor.execute('SELECT DATABASE()')
            db_name = cursor.fetchone()
            logger.info(f"Connected to MySQL Server version {db_version[0]}")
            logger.info(f"Connected to database {db_name[0]}")
            cursor.close()
            conn.close()
            logger.info("MySQL connection is closed")
            return True
    except Error as e:
        logger.error(f"Error while connecting to MySQL: {e}")
        return False 