# Embed Documentation

The application now supports embed links for various components, making it easy to share specific data or embed it in other applications.

## Available Embed Components

### 1. EventViewer Embed

The EventViewer component can be accessed as a standalone embed link, making it easy to share specific event data or embed it in other applications.

#### URL Format
```
/embed/event?eventId={EVENT_ID}&tag={TEAM_TAG}
```

#### Parameters
- `eventId` (required): The ID of the event you want to display
- `tag` (optional): The team tag to filter events. If not provided, all events will be shown

#### Examples
- Basic embed with event ID only: `/embed/event?eventId=123`
- Embed with event ID and team tag: `/embed/event?eventId=123&tag=TEAMNAME`

### 2. WarnListTable Embed

The WarnListTable component can be accessed as a standalone embed link, showing team member race activity and warning flags for members who haven't met weekly requirements.

#### URL Format
```
/embed/warnlist?tag={TEAM_TAG}
```

#### Parameters
- `tag` (required): The team tag to display the warn list for

#### Examples
- Basic warn list embed: `/embed/warnlist?tag=TEAMNAME`

## Features

Both embed components include:

- **Clean Interface**: No navigation bars or app chrome
- **Full Functionality**: All features from the original components
- **Sorting**: Click column headers to sort data
- **Interactive Elements**: Links to Nitrotype profiles and internal navigation
- **Responsive Design**: Works well in embedded contexts

### EventViewer Specific Features
- Event information display
- Racers, Squads, and Teams tabs
- Rank column with medal icons for top 3
- Export functionality (in full app version)

### WarnListTable Specific Features
- 7-week race trend sparklines
- Warning flags for members not meeting requirements
- Color-coded activity indicators
- Weekly race requirement thresholds

## Usage Examples

### Embedding in Websites
```html
<!-- Event Viewer Embed -->
<iframe src="http://localhost:3001/embed/event?eventId=123&tag=TEAMNAME" 
        width="100%" height="600" frameborder="0"></iframe>

<!-- Warn List Embed -->
<iframe src="http://localhost:3001/embed/warnlist?tag=TEAMNAME" 
        width="100%" height="600" frameborder="0"></iframe>
```

### Direct Links
- Event Viewer: `http://localhost:3001/embed/event?eventId=123`
- Warn List: `http://localhost:3001/embed/warnlist?tag=TEAMNAME`

## Notes

- Embed links work independently without requiring the full application context
- All data is fetched directly by the embed components
- The embed views are optimized for clean, minimal presentation
- Links within the embeds will navigate within the embed context 