import EventViewerCore from './EventViewerCore';
import { Event } from './Events';
import { useSearchParams } from 'react-router-dom';
import { useEffect, useState } from 'react';

function StandaloneEventViewer() {
  const [searchParams] = useSearchParams();
  const eventId = searchParams.get('eventId');
  const teamTag = searchParams.get('tag');
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);

  useEffect(() => {
    if (eventId) {
      const parsedEventId = parseInt(eventId, 10);
      if (!isNaN(parsedEventId)) {
        setSelectedEventId(parsedEventId);
      }
    }
  }, [eventId]);

  useEffect(() => {
    const url = teamTag ? `/api/team-events?tag=${encodeURIComponent(teamTag)}` : '/api/team-events';
    fetch(url)
      .then(res => res.json())
      .then(setEvents)
      .catch(() => setEvents([]));
  }, [teamTag]);

  return (
    <EventViewerCore
      events={events}
      selectedEventId={selectedEventId}
      setSelectedEventId={setSelectedEventId}
      selectedTag={teamTag}
      showEventSelector={false}
      showExportButtons={false}
    />
  );
}

export default StandaloneEventViewer; 