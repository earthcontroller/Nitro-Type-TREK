function Shard({ activeTab, onTabChange }: { activeTab: string, onTabChange: (tab: string) => void }) {
  return (
    <div className="tabs">
      <button className={`tab ${activeTab === 'roster' ? 'active' : ''}`} onClick={() => onTabChange('roster')}>Roster</button>
      <button className={`tab ${activeTab === 'events' ? 'active' : ''}`} onClick={() => onTabChange('events')}>Events</button>
      <button className={`tab ${activeTab === 'eventviewer' ? 'active' : ''}`} onClick={() => onTabChange('eventviewer')}>Event Viewer</button>
      <button className={`tab ${activeTab === 'activity' ? 'active' : ''}`} onClick={() => onTabChange('activity')}>Activity</button>
      <button className={`tab ${activeTab === 'trackers' ? 'active' : ''}`} onClick={() => onTabChange('trackers')}>Trackers</button>
      <button className={`tab ${activeTab === 'admin' ? 'active' : ''}`} onClick={() => onTabChange('admin')}>Admin</button>
    </div>
  );
}

export default Shard; 