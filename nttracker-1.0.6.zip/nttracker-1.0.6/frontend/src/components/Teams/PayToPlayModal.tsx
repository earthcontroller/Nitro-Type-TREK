import React, { useState, useEffect } from 'react';

interface PayToPlayModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  initialData?: any;
  loading?: boolean;
  error?: string | null;
}

export function PayToPlayModal({ open, onClose, onSubmit, initialData, loading, error }: PayToPlayModalProps) {
  const [form, setForm] = useState({
    MinRaces: initialData?.MinRaces ?? 100,
    QualifyingRaces: initialData?.QualifyingRaces ?? 150,
    RaceIncrement: initialData?.RaceIncrement ?? 50,
    PayoutIncrement: initialData?.PayoutIncrement,
    Cap: initialData?.Cap ?? 10000000.00,
    AccBonus96: initialData?.AccBonus96 ?? 1.00,
    AccBonus98: initialData?.AccBonus98 ?? 1.00
  });

  useEffect(() => {
    if (open && initialData) {
      setForm({
        MinRaces: initialData.MinRaces ?? 100,
        QualifyingRaces: initialData.QualifyingRaces ?? 150,
        RaceIncrement: initialData.RaceIncrement ?? 50,
        PayoutIncrement: initialData.PayoutIncrement ?? 500000,
        Cap: initialData.Cap ?? 10000000.00,
        AccBonus96: initialData.AccBonus96 ?? 1.00,
        AccBonus98: initialData.AccBonus98 ?? 1.00
      });
    }
  }, [open, initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: name.includes('Bonus') ? parseFloat(value) : name === 'Cap' ? parseFloat(value) : parseInt(value, 10)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
  };

  if (!open) return null;

  return (
    <div className="modal show" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ minWidth: 300, maxWidth: 400 }}>
        <h2>Pay-to-Play Settings</h2>
        <form onSubmit={handleSubmit}>
          <label>
            Minimum Races
            <input
              type="number"
              name="MinRaces"
              value={form.MinRaces}
              onChange={handleChange}
              min="0"
              required
            />
          </label>
          <label>
            Qualifying Races
            <input
              type="number"
              name="QualifyingRaces"
              value={form.QualifyingRaces}
              onChange={handleChange}
              min="0"
              required
            />
          </label>
          <label>
            Race Increment
            <input
              type="number"
              name="RaceIncrement"
              value={form.RaceIncrement}
              onChange={handleChange}
              min="0"
              required
            />
          </label>
          <label>
            Payout Increment
            <input
              type="number"
              name="PayoutIncrement"
              value={form.PayoutIncrement}
              onChange={handleChange}
              min="0"
              required
            />
          </label>
          <label>
            Cap
            <input
              type="number"
              name="Cap"
              value={form.Cap}
              onChange={handleChange}
              min="0"
              step="0.01"
              required
            />
          </label>
          <label>
            96% Accuracy Bonus
            <input
              type="number"
              name="AccBonus96"
              value={form.AccBonus96}
              onChange={handleChange}
              min="0"
              step="0.01"
              required
            />
          </label>
          <label>
            98% Accuracy Bonus
            <input
              type="number"
              name="AccBonus98"
              value={form.AccBonus98}
              onChange={handleChange}
              min="0"
              step="0.01"
              required
            />
          </label>
          {error && <div className="error-message">{error}</div>}
          <div style={{ marginTop: 16, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button type="button" onClick={onClose} style={{ minWidth: 80, color: '#333', background: '#fff', border: '1px solid #ccc' }}>Cancel</button>
            <button type="submit" disabled={loading} style={{ minWidth: 80, color: '#fff', background: '#1976d2', border: 'none' }}>{loading ? 'Saving...' : 'Save'}</button>
          </div>
        </form>
      </div>
    </div>
  );
} 