import EventViewerCore from './EventViewerCore';
import { Event } from './Events';

function EventViewer(props: {
  events: Event[];
  selectedEventId: number | null;
  setSelectedEventId: (id: number | null) => void;
  selectedTag: string | null;
}) {
  return (
    <EventViewerCore
      {...props}
      showEventSelector={true}
      showExportButtons={true}
    />
  );
}

export default EventViewer; 