export interface Event {
  EventID: number;
  Title: string;
  Description: string;
  TeamTag: string;
  StartTime: string;
  EndTime: string;
  Status: 'Pending' | 'Active' | 'Concluded';
  DefaultSort: string;
  MinRaces?: number;
  QualifyingRaces?: number;
  RaceIncrement?: number;
  PayoutIncrement?: number;
  Cap?: number;
  AccBonus96?: number;
  AccBonus98?: number;
}

function EventsTable({ onEventClick, events }: { 
  onEventClick: (eventId: number) => void, 
  selectedTag: string | null,
  events: Event[]
}) {
  return (
    <table className="display-names-table">
      <thead>
        <tr>
          <th>Event ID</th>
          <th>Title</th>
          <th>Team Tag</th>
          <th>Start Time (CT)</th>
          <th>End Time (CT)</th>
          <th>Status</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        {events.map((event) => (
          <tr 
            key={event.EventID}
            onClick={() => onEventClick(event.EventID)}
            style={{ cursor: 'pointer' }}
            className="clickable-row"
          >
            <td>{event.EventID}</td>
            <td>{event.Title}</td>
            <td>{event.TeamTag}</td>
            <td>{event.StartTime}</td>
            <td>{event.EndTime}</td>
            <td>
              <span className={`status-badge status-${event.Status.toLowerCase()}`}>
                {event.Status}
              </span>
            </td>
            <td>{event.Description}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default EventsTable; 