import { useState, useEffect, useContext } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { TeamContext } from '../Shared/TeamContext';
import WarnListTable from './WarnListTable';

const squadColors: Record<string, string> = {
  'Unassigned': '#999999',
  'Avocado': '#a5ce7b',
  'Blueberry': '#85b9e8',
  'Coconut': '#f3f3f4',
  'Dragonfruit': '#f7c4c4',
  'Durian': '#c7eae9',
  'Fig': '#999ac4',
  'Grape': '#c7b3d8',
  'Mango': '#fbe499',
  'Peach': '#f7cba8'
};

function getLast7DaysLocalStrings() {
  const days: string[] = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    days.push(d.toString());
  }
  return days;
}

function getYYYYMMDDFromDate(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getLocalDateFromYYYYMMDD(ymd: string) {
  const [year, month, day] = ymd.split('-').map(Number);
  return new Date(year, month - 1, day);
}

function getLast7SundaysIncludingThisWeek(): Date[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dayOfWeek = today.getDay();
  const thisSunday = new Date(today);
  thisSunday.setDate(today.getDate() - dayOfWeek);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(thisSunday);
    d.setDate(thisSunday.getDate() - i * 7);
    return d;
  });
}

function DailyTrackerTable({ selectedTag }: { selectedTag: string | null }) {
  const last7DaysLocal = getLast7DaysLocalStrings();
  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return getYYYYMMDDFromDate(today);
  });
  const [participants, setParticipants] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: string | null; direction: 'asc' | 'desc' }>({ key: 'Points', direction: 'desc' });
  const navigate = useNavigate();
  const { tag } = useParams<{ tag?: string }>();

  useEffect(() => {
    if (tag && tag !== selectedTag) {
      navigate(`/trackers/${tag}`);
    }
  }, [tag]);

  useEffect(() => {
    if (!selectedTag || !selectedDate) {
      setParticipants([]);
      return;
    }
    setLoading(true);
    setError(null);
    fetch(`/api/daily-participants?tag=${encodeURIComponent(selectedTag)}&date=${selectedDate}`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch data');
        return res.json();
      })
      .then(data => {
        setParticipants(data.participants || []);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setParticipants([]);
        setLoading(false);
      });
  }, [selectedTag, selectedDate]);

  const handleSort = (key: string) => {
    setSortConfig(prevConfig => ({
      key,
      direction: prevConfig.key === key && prevConfig.direction === 'desc' ? 'asc' : 'desc'
    }));
  };
  const sortedParticipants = [...participants].sort((a, b) => {
    if (!sortConfig.key) return 0;
    const aValue = a[sortConfig.key];
    const bValue = b[sortConfig.key];
    if (!isNaN(Number(aValue)) && !isNaN(Number(bValue)) && aValue !== null && bValue !== null && aValue !== '' && bValue !== '') {
      return sortConfig.direction === 'asc' ? Number(aValue) - Number(bValue) : Number(bValue) - Number(aValue);
    }
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortConfig.direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
    }
    return 0;
  });
  const getSortIcon = (columnKey: string) => {
    if (sortConfig.key !== columnKey) return '↕️';
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  const formattedTitle = selectedDate
    ? getLocalDateFromYYYYMMDD(selectedDate).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })
    : '';

  const handleUsernameClick = (username: string) => {
    navigate(`/racers?username=${username}&subtab=batch${selectedTag ? `&tag=${selectedTag}` : ''}`);
  };

  return (
    <div className="event-details">
      <div style={{ marginBottom: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
        <h3 style={{ margin: 0 }}>Daily Tracker: {formattedTitle}</h3>
        <select value={selectedDate} onChange={e => setSelectedDate(e.target.value)}>
          {last7DaysLocal.map((localString) => {
            const d = new Date(localString);
            const ymd = getYYYYMMDDFromDate(d);
            return (
              <option key={ymd} value={ymd}>{d.toLocaleDateString()}</option>
            );
          })}
        </select>
      </div>
      {loading ? (
        <div className="loading-message">Loading participants...</div>
      ) : error ? (
        <div className="error-message">{error}</div>
      ) : (
        <table className="display-names-table">
          <thead>
            <tr>
              <th onClick={() => handleSort('CurrentDisplayName')} className="sortable-header">Display Name {getSortIcon('CurrentDisplayName')}</th>
              <th onClick={() => handleSort('Username')} className="sortable-header">Username {getSortIcon('Username')}</th>
              <th onClick={() => handleSort('TeamTag')} className="sortable-header">Team Tag {getSortIcon('TeamTag')}</th>
              <th onClick={() => handleSort('SquadName')} className="sortable-header">Squad Name {getSortIcon('SquadName')}</th>
              <th onClick={() => handleSort('TotalRaces')} className="sortable-header">Races {getSortIcon('TotalRaces')}</th>
              <th onClick={() => handleSort('WPM')} className="sortable-header">WPM {getSortIcon('WPM')}</th>
              <th onClick={() => handleSort('Accuracy')} className="sortable-header">Accuracy {getSortIcon('Accuracy')}</th>
              <th onClick={() => handleSort('Points')} className="sortable-header">Points {getSortIcon('Points')}</th>
            </tr>
          </thead>
          <tbody>
            {sortedParticipants.map((participant) => (
              <tr key={participant.Username}>
                <td>
                  <a
                    href={`https://www.nitrotype.com/racer/${participant.Username}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    tabIndex={0}
                    aria-label={`View ${participant.Username} on Nitrotype`}
                  >
                    {participant.CurrentDisplayName}
                  </a>
                </td>
                <td>
                  <button
                    className="username-link"
                    onClick={() => handleUsernameClick(participant.Username)}
                    tabIndex={0}
                    aria-label={`Go to ${participant.Username} in Racers Batch Inspector`}
                  >
                    {participant.Username}
                  </button>
                </td>
                <td>{participant.TeamTag}</td>
                <td>
                  <span 
                    className="squad-name-badge"
                    style={{ 
                      backgroundColor: squadColors[participant.Squad || 'Unassigned'],
                      color: '#000000'
                    }}
                  >
                    {participant.SquadName || participant.Squad || ''}
                  </span>
                </td>
                <td>{participant.TotalRaces}</td>
                <td>{Number(participant.WPM).toFixed(1)}</td>
                <td>{(Number(participant.Accuracy) * 100).toFixed(2)}%</td>
                <td>{Math.round(participant.Points).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {!loading && !participants.length && !error && (
        <div className="event-placeholder">
          <p>No participants found for this date.</p>
        </div>
      )}
    </div>
  );
}

function WeeklyTrackerTable({ selectedTag }: { selectedTag: string | null }) {
  const last7Sundays = getLast7SundaysIncludingThisWeek();
  const [selectedWeek, setSelectedWeek] = useState(() => getYYYYMMDDFromDate(last7Sundays[0]));
  const [participants, setParticipants] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: string | null; direction: 'asc' | 'desc' }>({ key: 'Points', direction: 'desc' });
  const navigate = useNavigate();

  const getSquadSortValue = (row: any) => row.SquadName || row.Squad || '';

  const handleSort = (key: string) => {
    setSortConfig(prevConfig => ({
      key,
      direction: prevConfig.key === key && prevConfig.direction === 'desc' ? 'asc' : 'desc'
    }));
  };

  const sortedParticipants = [...participants].sort((a, b) => {
    if (!sortConfig.key) return 0;
    let aValue = sortConfig.key === 'SquadName' ? getSquadSortValue(a) : a[sortConfig.key];
    let bValue = sortConfig.key === 'SquadName' ? getSquadSortValue(b) : b[sortConfig.key];

    if (sortConfig.key === 'SquadName') {
      const aEmpty = !aValue || String(aValue).trim() === '';
      const bEmpty = !bValue || String(bValue).trim() === '';
      if (aEmpty && !bEmpty) return sortConfig.direction === 'asc' ? 1 : -1;
      if (!aEmpty && bEmpty) return sortConfig.direction === 'asc' ? -1 : 1;
      aValue = aValue ? String(aValue) : '';
      bValue = bValue ? String(bValue) : '';
      return sortConfig.direction === 'asc'
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }

    if (!isNaN(Number(aValue)) && !isNaN(Number(bValue)) && aValue !== null && bValue !== null && aValue !== '' && bValue !== '') {
      return sortConfig.direction === 'asc' ? Number(aValue) - Number(bValue) : Number(bValue) - Number(aValue);
    }
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortConfig.direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
    }
    return 0;
  });

  const getSortIcon = (columnKey: string) => {
    if (sortConfig.key !== columnKey) return '↕️';
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  const getWeekRangeFromSunday = (sundayStr: string) => {
    const sunday = getLocalDateFromYYYYMMDD(sundayStr);
    const end = new Date(sunday);
    end.setDate(sunday.getDate() + 6);
    return `${sunday.toLocaleDateString()} - ${end.toLocaleDateString()}`;
  };

  const handleUsernameClick = (username: string) => {
    navigate(`/racers?username=${username}&subtab=batch`);
  };

  useEffect(() => {
    if (!selectedTag || !selectedWeek) {
      setParticipants([]);
      return;
    }
    setLoading(true);
    setError(null);
    fetch(`/api/weekly-participants?tag=${encodeURIComponent(selectedTag)}&week=${selectedWeek}`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch data');
        return res.json();
      })
      .then(data => {
        setParticipants(data.participants || []);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setParticipants([]);
        setLoading(false);
      });
  }, [selectedTag, selectedWeek]);

  return (
    <div className="event-details">
      <div style={{ marginBottom: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
        <h3 style={{ margin: 0 }}>Weekly Tracker: {getWeekRangeFromSunday(selectedWeek)}</h3>
        <select value={selectedWeek} onChange={e => setSelectedWeek(e.target.value)}>
          {last7Sundays.map((d) => {
            const ymd = getYYYYMMDDFromDate(d);
            return (
              <option key={ymd} value={ymd}>{getWeekRangeFromSunday(ymd)}</option>
            );
          })}
        </select>
      </div>
      {loading ? (
        <div className="loading-message">Loading participants...</div>
      ) : error ? (
        <div className="error-message">{error}</div>
      ) : (
        <table className="display-names-table">
          <thead>
            <tr>
              <th onClick={() => handleSort('CurrentDisplayName')} className="sortable-header">Display Name {getSortIcon('CurrentDisplayName')}</th>
              <th onClick={() => handleSort('Username')} className="sortable-header">Username {getSortIcon('Username')}</th>
              <th onClick={() => handleSort('TeamTag')} className="sortable-header">Team Tag {getSortIcon('TeamTag')}</th>
              <th onClick={() => handleSort('SquadName')} className="sortable-header">Squad Name {getSortIcon('SquadName')}</th>
              <th onClick={() => handleSort('TotalRaces')} className="sortable-header">Races {getSortIcon('TotalRaces')}</th>
              <th onClick={() => handleSort('WPM')} className="sortable-header">WPM {getSortIcon('WPM')}</th>
              <th onClick={() => handleSort('Accuracy')} className="sortable-header">Accuracy {getSortIcon('Accuracy')}</th>
              <th onClick={() => handleSort('Points')} className="sortable-header">Points {getSortIcon('Points')}</th>
            </tr>
          </thead>
          <tbody>
            {sortedParticipants.map((participant) => (
              <tr key={participant.Username}>
                <td>
                  <a
                    href={`https://www.nitrotype.com/racer/${participant.Username}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    tabIndex={0}
                    aria-label={`View ${participant.Username} on Nitrotype`}
                  >
                    {participant.CurrentDisplayName}
                  </a>
                </td>
                <td>
                  <button
                    className="username-link"
                    onClick={() => handleUsernameClick(participant.Username)}
                    tabIndex={0}
                    aria-label={`Go to ${participant.Username} in Racers Batch Inspector`}
                  >
                    {participant.Username}
                  </button>
                </td>
                <td>{participant.TeamTag}</td>
                <td>
                  <span 
                    className="squad-name-badge"
                    style={{ 
                      backgroundColor: squadColors[participant.Squad || 'Unassigned'],
                      color: '#000000'
                    }}
                  >
                    {participant.SquadName || participant.Squad || ''}
                  </span>
                </td>
                <td>{participant.TotalRaces}</td>
                <td>{Number(participant.WPM).toFixed(1)}</td>
                <td>{(Number(participant.Accuracy) * 100).toFixed(2)}%</td>
                <td>{Math.round(participant.Points).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {!loading && !participants.length && !error && (
        <div className="event-placeholder">
          <p>No participants found for this week.</p>
        </div>
      )}
    </div>
  );
}

function TrackersTabs() {
  const selectedTag = useContext(TeamContext);
  const [activeSubtab, setActiveSubtab] = useState<'daily' | 'weekly' | 'warnlist'>('daily');

  return (
    <div>
      <div className="event-tabs-bar" style={{ marginBottom: 16 }}>
        <button
          className={`event-tab-btn${activeSubtab === 'daily' ? ' active' : ''}`}
          onClick={() => setActiveSubtab('daily')}
        >
          Daily
        </button>
        <button
          className={`event-tab-btn${activeSubtab === 'weekly' ? ' active' : ''}`}
          onClick={() => setActiveSubtab('weekly')}
        >
          Weekly
        </button>
        <button
          className={`event-tab-btn${activeSubtab === 'warnlist' ? ' active' : ''}`}
          onClick={() => setActiveSubtab('warnlist')}
        >
          Warn List
        </button>
      </div>
      {activeSubtab === 'daily' && <DailyTrackerTable selectedTag={selectedTag} />}
      {activeSubtab === 'weekly' && <WeeklyTrackerTable selectedTag={selectedTag} />}
      {activeSubtab === 'warnlist' && <WarnListTable selectedTag={selectedTag} />}
    </div>
  );
}

export default TrackersTabs; 