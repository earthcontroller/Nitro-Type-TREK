import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, Title } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';

ChartJS.register(ArcElement, Tooltip, Legend, Title, ChartDataLabels);

interface EventParticipant {
  [key: string]: any;
  CurrentDisplayName: string;
  Username: string;
  TeamTag: string;
  TotalRaces: number;
  TotalTyped: number;
  TotalErrors: number;
  TotalSeconds: number;
  WPM: number;
  Accuracy: number;
  Points: number;
  Squad?: string;
  SquadName?: string;
  bot?: number;
}

interface SquadDonutChartsProps {
  participants: EventParticipant[];
}

const squadNames = [
  'Avocado', 'Blueberry', 'Coconut', 
  'Dragonfruit', 'Durian', 'Fig', 
  'Grape', 'Mango', 'Peach'
];

const squadColors: Record<string, string> = {
  'Avocado': '#a5ce7b',
  'Blueberry': '#85b9e8',
  'Coconut': '#f3f3f4',
  'Dragonfruit': '#f7c4c4',
  'Durian': '#c7eae9',
  'Fig': '#999ac4',
  'Grape': '#c7b3d8',
  'Mango': '#fbe499',
  'Peach': '#f7cba8'
};

const CHART_COLORS = [
  '#36A2EB', '#FF6384', '#4BC0C0', '#FF9F40', '#9966FF', '#FFCD56', '#C9CBCF'
];

const SquadDonutCharts = ({ participants }: SquadDonutChartsProps) => {
  if (!participants || participants.length === 0) {
    return <div>No participant data available for charts.</div>;
  }

  return (
    <div style={{ marginTop: '2rem' }}>
        <h3 style={{ color: '#fff' }}>Squad Race Distribution</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '2rem' }}>
        {squadNames.map(squadName => {
            const squadParticipants = participants.filter(p => p.Squad === squadName);

            // Use the full SquadName for the header if it exists, otherwise fall back to the squad identifier.
            const headerText = (squadParticipants.length > 0 && squadParticipants[0].SquadName)
                ? squadParticipants[0].SquadName
                : squadName;

            const chartTitle = (
              <h4 style={{
                  backgroundColor: squadColors[squadName] || '#fff',
                  color: '#000',
                  margin: 0,
                  padding: '8px 0',
                  fontSize: '18px',
                  fontWeight: 600,
                  textAlign: 'center'
              }}>
                  {headerText}
              </h4>
            );

            if (squadParticipants.length === 0) {
                return (
                    <div key={squadName} style={{ background: '#181c24', borderRadius: '8px', overflow: 'hidden' }}>
                        {chartTitle}
                        <div style={{ color: '#888', padding: '1rem', marginTop: '3rem', marginBottom: '3rem', textAlign: 'center' }}>No racers in this squad.</div>
                    </div>
                )
            }
            
            const chartData = {
            labels: squadParticipants.map(p => p.CurrentDisplayName),
            datasets: [
                {
                label: 'Races',
                data: squadParticipants.map(p => p.TotalRaces),
                backgroundColor: squadParticipants.map((_, i) => CHART_COLORS[i % CHART_COLORS.length]),
                borderColor: '#181c24',
                borderWidth: 2,
                },
            ],
            };

            const chartOptions = {
            responsive: true,
            plugins: {
                legend: {
                  position: 'top' as const,
                  labels: {
                      color: '#fff',
                      generateLabels: (chart: ChartJS) => {
                        const { data } = chart;
                        if (data.labels && data.datasets.length) {
                          return (data.labels as string[]).map((label, i) => {
                            const dataset = data.datasets[0];
                            const value = dataset.data[i] as number;
                            const total = dataset.data.reduce((sum: number, val: any) => sum + (Number(val) || 0), 0);
                            const percentage = total > 0 ? ((value / total) * 100).toFixed(1) + '%' : '0%';
                            
                            return {
                              text: `${label} (${percentage})`,
                              fillStyle: (dataset.backgroundColor as string[])[i],
                              fontColor: '#fff',
                              hidden: !chart.getDataVisibility(i),
                              index: i
                            };
                          });
                        }
                        return [];
                      }
                  }
                },
                title: {
                  display: false // Hide canvas title, we use a custom HTML one
                },
                tooltip: {
                  callbacks: {
                    label: (context: any) => {
                      const value = context.raw as number;
                      const total = context.chart.data.datasets[0].data.reduce((sum: number, val: any) => sum + (Number(val) || 0), 0);
                      const percentage = total > 0 ? ((value / total) * 100).toFixed(1) + '%' : '0%';
                      return `${value} races (${percentage})`;
                    }
                  }
                },
                datalabels: {
                    color: '#fff',
                    formatter: (value: number, context: any) => {
                        const total = context.chart.data.datasets[0].data.reduce((sum: number, val: any) => sum + (Number(val) || 0), 0);
                        const percentage = total > 0 ? ((value / total) * 100).toFixed(0) + '%' : '0%';
                        return `${value} (${percentage})`;
                    },
                    font: {
                        weight: 'bold' as const
                    },
                    textStrokeColor: '#000',
                    textStrokeWidth: 2
                }
            },
            };

            return (
              <div key={squadName} style={{ background: '#181c24', borderRadius: '8px', overflow: 'hidden' }}>
                {chartTitle}
                <div style={{ padding: '1rem' }}>
                  <Doughnut data={chartData} options={chartOptions} />
                </div>
              </div>
            );
        })}
        </div>
    </div>
  );
};

export default SquadDonutCharts; 