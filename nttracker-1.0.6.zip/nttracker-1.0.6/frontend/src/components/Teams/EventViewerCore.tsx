import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Event } from './Events';
import { exportTableToCSV, exportTableToExcel, HyperlinkConfig } from '../Shared/exportUtils';
import SquadDonutCharts from './SquadDonutCharts';
import DuelBox from './DuelBox';

interface EventParticipant {
  [key: string]: any;
  CurrentDisplayName: string;
  Username: string;
  TeamTag: string;
  MemberStatus: 'Active' | 'Inactive';
  TotalRaces: number;
  TotalTyped: number;
  TotalErrors: number;
  TotalSeconds: number;
  WPM: number;
  Accuracy: number;
  Points: number;
  Squad?: string;
  SquadName?: string;
  bot?: number;
  Tier: string;
}

interface EventData {
  participants: EventParticipant[];
}

const squadColors: Record<string, string> = {
  'Unassigned': '#999999',
  'Avocado': '#a5ce7b',
  'Blueberry': '#85b9e8',
  'Coconut': '#f3f3f4',
  'Dragonfruit': '#f7c4c4',
  'Durian': '#c7eae9',
  'Fig': '#999ac4',
  'Grape': '#c7b3d8',
  'Mango': '#fbe499',
  'Peach': '#f7cba8'
};

const teamColorMap: Record<string, string> = {
  BEEHVE: '#1976d2',
  NTPD1: '#e74c3c',
};

interface EventViewerCoreProps {
  events: Event[];
  selectedEventId: number | null;
  setSelectedEventId: (id: number | null) => void;
  selectedTag: string | null;
  showEventSelector?: boolean;
  showExportButtons?: boolean;
}

function EventViewerCore({
  events,
  selectedEventId,
  setSelectedEventId,
  selectedTag,
  showEventSelector = true,
  showExportButtons = true
}: EventViewerCoreProps) {
  const [eventData, setEventData] = useState<EventData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [participantsSortConfig, setParticipantsSortConfig] = useState<{ key: string | null; direction: 'asc' | 'desc'; }>({ key: null, direction: 'desc' });
  const [squadSortConfig, setSquadSortConfig] = useState<{ key: string | null; direction: 'asc' | 'desc'; }>({ key: null, direction: 'desc' });
  const [teamSortConfig, setTeamSortConfig] = useState<{ key: string | null; direction: 'asc' | 'desc'; }>({ key: null, direction: 'desc' });
  const [teamTierSortConfig, setTeamTierSortConfig] = useState<{ key: 'teamTag' | 'tier'; direction: 'asc' | 'desc' }>({ key: 'tier', direction: 'asc' });
  
  const [activeTab, setActiveTab] = useState<'racers' | 'squads' | 'teams'>(() => {
    const saved = localStorage.getItem('eventViewerActiveTab');
    return (saved === 'racers' || saved === 'squads' || saved === 'teams') ? saved : 'racers';
  });

  useEffect(() => {
    localStorage.setItem('eventViewerActiveTab', activeTab);
  }, [activeTab]);

  const [showInactive, setShowInactive] = useState(false);
  const navigate = useNavigate();

  // Map event DefaultSort values to participant property keys
  const participantSortKeyMap: Record<string, string> = {
    Races: 'TotalRaces',
    WPM: 'WPM',
    Accuracy: 'Accuracy',
    Points: 'Points',
    Tier: 'Tier',
    Username: 'Username',
    DisplayName: 'CurrentDisplayName',
    SquadName: 'SquadName',
  };

  useEffect(() => {
    if (selectedEventId) {
      const event = events.find(e => e.EventID === selectedEventId);
      let defaultSortKey = event?.DefaultSort || 'TotalRaces';
      defaultSortKey = participantSortKeyMap[defaultSortKey] || defaultSortKey;
      setParticipantsSortConfig({ key: defaultSortKey, direction: 'desc' });
      setTeamSortConfig({ key: 'Points', direction: 'desc' });
      setSquadSortConfig({ key: defaultSortKey === 'TotalRaces' ? 'Races' : defaultSortKey, direction: 'desc' });
    }
  }, [selectedEventId, events]);

  useEffect(() => {
    if (selectedEventId) {
      fetchEventData(selectedEventId);
    } else {
      setEventData(null);
    }
  }, [selectedEventId]);

  const fetchEventData = async (eventId: number) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/event-data/${eventId}`);
      if (!response.ok) throw new Error('Failed to fetch event data');
      const data = await response.json();
      setEventData(data);
    } catch (error) {
      console.error('Error fetching event data:', error);
      setError('Failed to fetch event data');
      setEventData(null);
    } finally {
      setLoading(false);
    }
  };

  const handleParticipantsSort = (key: string) => {
    setParticipantsSortConfig(prevConfig => ({
      key,
      direction: prevConfig.key === key && prevConfig.direction === 'desc' ? 'asc' : 'desc'
    }));
  };

  const handleSquadSort = (key: string) => {
    setSquadSortConfig(prevConfig => ({
      key,
      direction: prevConfig.key === key && prevConfig.direction === 'desc' ? 'asc' : 'desc'
    }));
  };

  const handleTeamSort = (key: string) => {
    setTeamSortConfig(prevConfig => ({
      key,
      direction: prevConfig.key === key && prevConfig.direction === 'desc' ? 'asc' : 'desc'
    }));
  };

  const sortedParticipants = [...(eventData?.participants || [])].sort((a, b) => {
    if (!participantsSortConfig.key) return 0;
    const aValue = a[participantsSortConfig.key];
    const bValue = b[participantsSortConfig.key];
    if (!isNaN(Number(aValue)) && !isNaN(Number(bValue)) && aValue !== null && bValue !== null) {
      return participantsSortConfig.direction === 'asc' ? Number(aValue) - Number(bValue) : Number(bValue) - Number(aValue);
    }
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return participantsSortConfig.direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
    }
    return 0;
  });

  const calculatedTeamSummary = (() => {
    const teamAggregations = new Map<string, {
      teamTag: string;
      totalRaces: number;
      totalTyped: number;
      totalErrors: number;
      totalSeconds: number;
    }>();
    (eventData?.participants || [])
      .filter(p => showInactive || p.MemberStatus === 'Active')
      .forEach(participant => {
      const teamTag = participant.TeamTag;
      if (!teamAggregations.has(teamTag)) {
        teamAggregations.set(teamTag, {
          teamTag,
          totalRaces: 0,
          totalTyped: 0,
          totalErrors: 0,
          totalSeconds: 0
        });
      }
      const agg = teamAggregations.get(teamTag)!;
      agg.totalRaces += Number(participant.TotalRaces);
      agg.totalTyped += Number(participant.TotalTyped);
      agg.totalErrors += Number(participant.TotalErrors);
      agg.totalSeconds += Number(participant.TotalSeconds);
    });
    return Array.from(teamAggregations.values()).map(agg => {
      const accuracy = agg.totalTyped > 0 ? 1 - (agg.totalErrors / agg.totalTyped) : 0;
      const wpm = agg.totalSeconds > 0 ? ((agg.totalTyped / 5.0) / agg.totalSeconds) * 60 : 0;
      const points = agg.totalRaces * accuracy * (100 + (wpm / 2.0));
      return {
        Tag: agg.teamTag,
        Races: agg.totalRaces,
        WPM: wpm,
        Accuracy: accuracy,
        Points: points
      };
    });
  })();

  const sortedTeamSummary = [...calculatedTeamSummary].sort((a, b) => {
    if (!teamSortConfig.key) return 0;
    let aValue = (a as any)[teamSortConfig.key];
    let bValue = (b as any)[teamSortConfig.key];
    if (!isNaN(Number(aValue)) && !isNaN(Number(bValue)) && aValue !== null && bValue !== null) {
      return teamSortConfig.direction === 'asc'
        ? Number(aValue) - Number(bValue)
        : Number(bValue) - Number(aValue);
    }
    aValue = aValue ? String(aValue) : '';
    bValue = bValue ? String(bValue) : '';
    return teamSortConfig.direction === 'asc'
      ? aValue.localeCompare(bValue)
      : bValue.localeCompare(aValue);
  });

  const calculatedSquadSummary = (() => {
    const squadAggregations = new Map<string, {
      squad: string;
      squadName: string;
      totalRaces: number;
      totalTyped: number;
      totalErrors: number;
      totalSeconds: number;
    }>();
    (eventData?.participants || [])
      .filter(p => showInactive || p.MemberStatus === 'Active')
      .forEach(participant => {
        const squad = participant.Squad || 'Unassigned';
        const squadName = participant.SquadName || participant.Squad || 'Unassigned';
        if (!squadAggregations.has(squadName)) {
          squadAggregations.set(squadName, {
            squad,
            squadName,
            totalRaces: 0,
            totalTyped: 0,
            totalErrors: 0,
            totalSeconds: 0
          });
        }
        const agg = squadAggregations.get(squadName)!;
        agg.totalRaces += Number(participant.TotalRaces);
        agg.totalTyped += Number(participant.TotalTyped);
        agg.totalErrors += Number(participant.TotalErrors);
        agg.totalSeconds += Number(participant.TotalSeconds);
      });
    return Array.from(squadAggregations.values()).map(agg => {
      const accuracy = agg.totalTyped > 0 ? 1 - (agg.totalErrors / agg.totalTyped) : 0;
      const wpm = agg.totalSeconds > 0 ? ((agg.totalTyped / 5.0) / agg.totalSeconds) * 60 : 0;
      const points = agg.totalRaces * accuracy * (100 + (wpm / 2.0));
      return {
        SquadName: agg.squadName,
        Squad: agg.squad,
        Races: agg.totalRaces,
        WPM: wpm,
        Accuracy: accuracy,
        Points: points
      };
    });
  })();

  const sortedSquadSummary = [...calculatedSquadSummary].sort((a, b) => {
    if (!squadSortConfig.key) return 0;
    let aValue = squadSortConfig.key === 'SquadName' ? a.SquadName : (a as any)[squadSortConfig.key];
    let bValue = squadSortConfig.key === 'SquadName' ? b.SquadName : (b as any)[squadSortConfig.key];
    if (!isNaN(Number(aValue)) && !isNaN(Number(bValue)) && aValue !== null && bValue !== null) {
      return squadSortConfig.direction === 'asc' ? Number(aValue) - Number(bValue) : Number(bValue) - Number(aValue);
    }
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return squadSortConfig.direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
    }
    return 0;
  });

  function handleExportCurrentTable(type: 'csv' | 'excel') {
    let data: any[] = [];
    let headers: string[] = [];
    let filename = '';
    let hyperlinkConfig: HyperlinkConfig = {};
    if (activeTab === 'racers') {
      const event = events.find(ev => ev.EventID === selectedEventId);
      const showWinnings = !!(event && event.PayoutIncrement && Number(event.PayoutIncrement) !== 0);
      
      // Determine if we should include TeamTag in export (only when there are multiple teams)
      const teams = event?.TeamTag ? event.TeamTag.split(/[, ]+/).filter(Boolean) : [];
      const showTeamTag = teams.length > 1;
      
      // Add computed winnings to each participant
      data = sortedParticipants.map(participant => {
        const participantWithWinnings = { ...participant };
        if (showWinnings && event) {
          participantWithWinnings.Winnings = computeWinnings(participant, event);
        }
        return participantWithWinnings;
      });
      
      headers = ['CurrentDisplayName', 'Username'];
      if (showTeamTag) {
        headers.push('TeamTag');
      }
      headers.push('SquadName', 'TotalRaces', 'WPM', 'Accuracy', 'Points', 'Tier', 'bot', 'MemberStatus');
      if (showWinnings) {
        headers.push('Winnings');
      }
      filename = `event_${selectedEventId}_participants.${type === 'csv' ? 'csv' : 'xlsx'}`;
      hyperlinkConfig = {
        CurrentDisplayName: row => `https://www.nitrotype.com/racer/${row.Username}`,
        Username: row => `https://www.nitrotype.com/racer/${row.Username}`,
      };
    } else if (activeTab === 'squads') {
      data = sortedSquadSummary;
      headers = ['SquadName', 'Races', 'WPM', 'Accuracy', 'Points'];
      filename = `event_${selectedEventId}_squads.${type === 'csv' ? 'csv' : 'xlsx'}`;
    } else if (activeTab === 'teams') {
      data = sortedTeamSummary;
      headers = ['Tag', 'Races', 'WPM', 'Accuracy', 'Points'];
      filename = `event_${selectedEventId}_teams.${type === 'csv' ? 'csv' : 'xlsx'}`;
    }
    if (type === 'csv') {
      exportTableToCSV(data, headers, filename);
    } else {
      exportTableToExcel(data, headers, filename, hyperlinkConfig);
    }
  }

  // Helper for sort icons
  const getSortIcon = (columnKey: string, currentKey: string | null, direction: 'asc' | 'desc') => {
    if (currentKey !== columnKey) return '↕️';
    return direction === 'asc' ? '↑' : '↓';
  };

  // Medal styles for top 3
  const medals = [
    { color: 'linear-gradient(135deg, #FFD700 60%, #FFFACD 100%)', label: '1' }, // Gold
    { color: 'linear-gradient(135deg, #C0C0C0 60%, #F5F5F5 100%)', label: '2' }, // Silver
    { color: 'linear-gradient(135deg, #CD7F32 60%, #FFDAB9 100%)', label: '3' }, // Bronze
  ];
  const medalStyle = (color: string) => ({
    display: 'inline-block',
    width: 28,
    height: 28,
    borderRadius: '50%',
    background: color,
    color: '#222',
    fontWeight: 700,
    fontSize: 18,
    lineHeight: '28px',
    textAlign: 'center' as const,
    marginRight: 2,
    boxShadow: '0 1px 4px rgba(0,0,0,0.10)'
  });

  const handleUsernameClick = (username: string) => {
    navigate(`/racers?username=${username}&subtab=batch${selectedTag ? `&tag=${selectedTag}` : ''}`);
  };

  // Function to convert URLs in text to clickable links
  const renderTextWithLinks = (text: string) => {
    if (!text) return null;
    
    // URL regex pattern that matches http/https URLs
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const parts = text.split(urlRegex);
    
    return parts.map((part, index) => {
      if (urlRegex.test(part)) {
        return (
          <a
            key={index}
            href={part}
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: '#1976d2', textDecoration: 'underline' }}
          >
            {part}
          </a>
        );
      }
      return part;
    });
  };

  function computeWinnings(participant: EventParticipant, event: Event): string {
    const {
      PayoutIncrement,
      MinRaces,
      QualifyingRaces,
      RaceIncrement,
      Cap,
      AccBonus96,
      AccBonus98,
    } = event;
    if (!PayoutIncrement || Number(PayoutIncrement) === 0 || !QualifyingRaces || participant.TotalRaces < QualifyingRaces) {
      return '';
    }
    const racesOverMin = participant.TotalRaces - (MinRaces || 0);
    if (racesOverMin < 0) return '';
    const increments = Math.floor(racesOverMin / (RaceIncrement || 1));
    let bonus = 1;
    if (participant.Accuracy >= 0.98) {
      bonus = Number(AccBonus98) || 1;
    } else if (participant.Accuracy >= 0.96) {
      bonus = Number(AccBonus96) || 1;
    }
    let payout = increments * Number(PayoutIncrement) * bonus;
    if (Cap && payout > Number(Cap)) payout = Number(Cap);
    if (payout <= 0) return '';
    return `$${Math.round(payout).toLocaleString()}`;
  }

  const renderRacersTable = () => {
    const filteredParticipants = sortedParticipants.filter(p => showInactive || p.MemberStatus === 'Active');
    const event = events.find(ev => ev.EventID === selectedEventId);
    const showWinnings = !!(event && event.PayoutIncrement && Number(event.PayoutIncrement) !== 0);
    
    // Determine if we should show the Team Tag column (only when there are multiple teams)
    const teams = event?.TeamTag ? event.TeamTag.split(/[, ]+/).filter(Boolean) : [];
    const showTeamTag = teams.length > 1;
    
    return (
      <div className="event-details">
        <table className="display-names-table">
          <thead>
            <tr>
              <th style={{ width: 60, textAlign: 'center' }}>Rank</th>
              <th onClick={() => handleParticipantsSort('CurrentDisplayName')} className="sortable-header">Display Name {getSortIcon('CurrentDisplayName', participantsSortConfig.key, participantsSortConfig.direction)}</th>
              <th onClick={() => handleParticipantsSort('Username')} className="sortable-header" style={{ maxWidth: 120, width: 120, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Username {getSortIcon('Username', participantsSortConfig.key, participantsSortConfig.direction)}</th>
              {showTeamTag && <th onClick={() => handleParticipantsSort('TeamTag')} className="sortable-header">Team Tag {getSortIcon('TeamTag', participantsSortConfig.key, participantsSortConfig.direction)}</th>}
              <th onClick={() => handleParticipantsSort('SquadName')} className="sortable-header">Squad Name {getSortIcon('SquadName', participantsSortConfig.key, participantsSortConfig.direction)}</th>
              <th onClick={() => handleParticipantsSort('TotalRaces')} className="sortable-header">Races {getSortIcon('TotalRaces', participantsSortConfig.key, participantsSortConfig.direction)}</th>
              <th onClick={() => handleParticipantsSort('WPM')} className="sortable-header">WPM {getSortIcon('WPM', participantsSortConfig.key, participantsSortConfig.direction)}</th>
              <th onClick={() => handleParticipantsSort('Accuracy')} className="sortable-header">Accuracy {getSortIcon('Accuracy', participantsSortConfig.key, participantsSortConfig.direction)}</th>
              <th onClick={() => handleParticipantsSort('Points')} className="sortable-header">Points {getSortIcon('Points', participantsSortConfig.key, participantsSortConfig.direction)}</th>
              <th onClick={() => handleParticipantsSort('Tier')} className="sortable-header">Tier {getSortIcon('Tier', participantsSortConfig.key, participantsSortConfig.direction)}</th>
              {showWinnings && <th>Winnings</th>}
            </tr>
          </thead>
          <tbody>
            {filteredParticipants.map((participant, idx) => (
              <tr key={participant.Username}>
                <td style={{ textAlign: 'center', fontWeight: 600 }}>
                  {idx < 3 ? (
                    <span style={medalStyle(medals[idx].color)} title={idx === 0 ? 'Gold Medal' : idx === 1 ? 'Silver Medal' : 'Bronze Medal'}>
                      {medals[idx].label}
                    </span>
                  ) : (
                    idx + 1
                  )}
                </td>
                <td>
                  <a
                    href={`https://www.nitrotype.com/racer/${participant.Username}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    tabIndex={0}
                    aria-label={`View ${participant.Username} on Nitrotype`}
                  >
                    {participant.CurrentDisplayName}
                    {participant.bot === 1 && <span title="Bot" style={{ marginLeft: 4 }}>🤖</span>}
                  </a>
                  {participant.MemberStatus === 'Inactive' && ' (left)'}
                </td>
                <td
                  style={{
                    maxWidth: 120,
                    width: 120,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    cursor: 'pointer',
                  }}
                  title={participant.Username}
                >
                  <button
                    className="username-link"
                    onClick={() => handleUsernameClick(participant.Username)}
                    tabIndex={0}
                    aria-label={`Go to ${participant.Username} in Racers Batch Inspector`}
                    style={{
                      maxWidth: '100%',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                      background: 'none',
                      border: 'none',
                      padding: 0,
                      font: 'inherit',
                      cursor: 'pointer',
                    }}
                    title={participant.Username}
                  >
                    {participant.Username}
                  </button>
                </td>
                {showTeamTag && <td>{participant.TeamTag}</td>}
                <td>
                  <span 
                    className="squad-name-badge"
                    style={{ 
                      backgroundColor: squadColors[participant.Squad || 'Unassigned'],
                      color: '#000000'
                    }}
                  >
                    {participant.SquadName || participant.Squad || ''}
                  </span>
                </td>
                <td onClick={() => handleParticipantsSort('TotalRaces')} className="sortable-header">{participant.TotalRaces}</td>
                <td onClick={() => handleParticipantsSort('WPM')} className="sortable-header">{Number(participant.WPM).toFixed(1)}</td>
                <td onClick={() => handleParticipantsSort('Accuracy')} className="sortable-header">{(Number(participant.Accuracy) * 100).toFixed(2)}%</td>
                <td onClick={() => handleParticipantsSort('Points')} className="sortable-header">{Math.round(participant.Points).toLocaleString()}</td>
                <td>
                  <span 
                    style={{
                      display: 'inline-block',
                      width: 24,
                      height: 24,
                      borderRadius: '50%',
                      background: participant.Tier === 'A' ? '#1976d2' : participant.Tier === 'B' ? '#9c27b0' : '#ff88f6',
                      color: '#fff',
                      fontWeight: 700,
                      fontSize: 14,
                      lineHeight: '24px',
                      textAlign: 'center',
                      boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
                    }}
                    title={`Tier ${participant.Tier}`}
                  >
                    {participant.Tier}
                  </span>
                </td>
                {showWinnings && <td>{computeWinnings(participant, event)}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderSquadSummary = () => (
    <div className="event-details" style={{ marginBottom: '2rem' }}>
      <table className="display-names-table">
        <thead>
          <tr>
            <th onClick={() => handleSquadSort('SquadName')} className="sortable-header">Squad Name {getSortIcon('SquadName', squadSortConfig.key, squadSortConfig.direction)}</th>
            <th onClick={() => handleSquadSort('Races')} className="sortable-header">Races {getSortIcon('Races', squadSortConfig.key, squadSortConfig.direction)}</th>
            <th onClick={() => handleSquadSort('WPM')} className="sortable-header">WPM {getSortIcon('WPM', squadSortConfig.key, squadSortConfig.direction)}</th>
            <th onClick={() => handleSquadSort('Accuracy')} className="sortable-header">Accuracy {getSortIcon('Accuracy', squadSortConfig.key, squadSortConfig.direction)}</th>
            <th onClick={() => handleSquadSort('Points')} className="sortable-header">Points {getSortIcon('Points', squadSortConfig.key, squadSortConfig.direction)}</th>
          </tr>
        </thead>
        <tbody>
          {sortedSquadSummary.map((squad) => (
            <tr key={squad.SquadName}>
              <td>
                <span
                  className="squad-name-badge"
                  style={{ backgroundColor: squadColors[squad.Squad] || '#999999', color: '#000000' }}
                >
                  {squad.SquadName !== 'Unassigned' ? squad.SquadName : ''}
                </span>
              </td>
              <td>{squad.Races}</td>
              <td>{Number(squad.WPM).toFixed(1)}</td>
              <td>{(Number(squad.Accuracy) * 100).toFixed(2)}%</td>
              <td>{Math.round(squad.Points).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderTeamSummary = () => {
    const event = events.find(ev => ev.EventID === selectedEventId);
    return (
      <div className="event-details" style={{ marginBottom: '2rem' }}>
        <DuelBox
          rows={(() => {
            const teamTierAggregations = new Map<string, {
              teamTag: string;
              tier: string;
              totalRaces: number;
              totalTyped: number;
              totalErrors: number;
              totalSeconds: number;
            }>();
            eventData?.participants
              .filter(p => showInactive || p.MemberStatus === 'Active')
              .forEach(participant => {
              const teamTag = participant.TeamTag;
              const tier = participant.Tier;
              const key = `${teamTag}||${tier}`;
              if (!teamTierAggregations.has(key)) {
                teamTierAggregations.set(key, {
                  teamTag,
                  tier,
                  totalRaces: 0,
                  totalTyped: 0,
                  totalErrors: 0,
                  totalSeconds: 0
                });
              }
              const agg = teamTierAggregations.get(key)!;
              agg.totalRaces += Number(participant.TotalRaces);
              agg.totalTyped += Number(participant.TotalTyped);
              agg.totalErrors += Number(participant.TotalErrors);
              agg.totalSeconds += Number(participant.TotalSeconds);
            });
            return Array.from(teamTierAggregations.values()).map(agg => {
              const accuracy = agg.totalTyped > 0 ? 1 - (agg.totalErrors / agg.totalTyped) : 0;
              const wpm = agg.totalSeconds > 0 ? ((agg.totalTyped / 5.0) / agg.totalSeconds) * 60 : 0;
              return {
                teamTag: agg.teamTag,
                tier: agg.tier,
                Races: agg.totalRaces,
                WPM: wpm,
                Accuracy: accuracy
              };
            });
          })()}
          teamColors={teamColorMap}
          eventInfo={event ? { TeamTag: event.TeamTag || '', StartTime: event.StartTime, EndTime: event.EndTime, Status: event.Status } : { TeamTag: '', StartTime: '', EndTime: '', Status: '' }}
        />
        <table className="display-names-table">
          <thead>
            <tr>
              <th onClick={() => handleTeamSort('Tag')} className="sortable-header">Team Tag {getSortIcon('Tag', teamSortConfig.key, teamSortConfig.direction)}</th>
              <th onClick={() => handleTeamSort('Races')} className="sortable-header">Races {getSortIcon('Races', teamSortConfig.key, teamSortConfig.direction)}</th>
              <th onClick={() => handleTeamSort('WPM')} className="sortable-header">WPM {getSortIcon('WPM', teamSortConfig.key, teamSortConfig.direction)}</th>
              <th onClick={() => handleTeamSort('Accuracy')} className="sortable-header">Accuracy {getSortIcon('Accuracy', teamSortConfig.key, teamSortConfig.direction)}</th>
              <th onClick={() => handleTeamSort('Points')} className="sortable-header">Points {getSortIcon('Points', teamSortConfig.key, teamSortConfig.direction)}</th>
            </tr>
          </thead>
          <tbody>
            {sortedTeamSummary.map((team) => (
              <tr key={team.Tag}>
                <td>{team.Tag}</td>
                <td>{team.Races}</td>
                <td>{Number(team.WPM).toFixed(1)}</td>
                <td>{(Number(team.Accuracy) * 100).toFixed(2)}%</td>
                <td>{Math.round(team.Points).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div style={{ marginTop: '2rem' }}>
          <h4 style={{ marginBottom: '1rem' }}>Results by Team & Tier</h4>
          <table className="display-names-table">
            <thead>
              <tr>
                <th onClick={() => setTeamTierSortConfig(prev => ({ key: 'teamTag', direction: prev.key === 'teamTag' && prev.direction === 'asc' ? 'desc' : 'asc' }))} className="sortable-header" style={{ cursor: 'pointer' }}>
                  Team Tag {teamTierSortConfig.key === 'teamTag' ? (teamTierSortConfig.direction === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th onClick={() => setTeamTierSortConfig(prev => ({ key: 'tier', direction: prev.key === 'tier' && prev.direction === 'asc' ? 'desc' : 'asc' }))} className="sortable-header" style={{ cursor: 'pointer' }}>
                  Tier {teamTierSortConfig.key === 'tier' ? (teamTierSortConfig.direction === 'asc' ? '↑' : '↓') : ''}
                </th>
                <th>Races</th>
                <th>WPM</th>
                <th>Accuracy</th>
                <th>Points</th>
              </tr>
            </thead>
            <tbody>
              {(() => {
                const teamTierAggregations = new Map<string, {
                  teamTag: string;
                  tier: string;
                  totalRaces: number;
                  totalTyped: number;
                  totalErrors: number;
                  totalSeconds: number;
                }>();
                eventData?.participants
                  .filter(p => showInactive || p.MemberStatus === 'Active')
                  .forEach(participant => {
                  const teamTag = participant.TeamTag;
                  const tier = participant.Tier;
                  const key = `${teamTag}||${tier}`;
                  if (!teamTierAggregations.has(key)) {
                    teamTierAggregations.set(key, {
                      teamTag,
                      tier,
                      totalRaces: 0,
                      totalTyped: 0,
                      totalErrors: 0,
                      totalSeconds: 0
                    });
                  }
                  const agg = teamTierAggregations.get(key)!;
                  agg.totalRaces += Number(participant.TotalRaces);
                  agg.totalTyped += Number(participant.TotalTyped);
                  agg.totalErrors += Number(participant.TotalErrors);
                  agg.totalSeconds += Number(participant.TotalSeconds);
                });
                let calculatedRows = Array.from(teamTierAggregations.values()).map(agg => {
                  const accuracy = agg.totalTyped > 0 ? 1 - (agg.totalErrors / agg.totalTyped) : 0;
                  const wpm = agg.totalSeconds > 0 ? ((agg.totalTyped / 5.0) / agg.totalSeconds) * 60 : 0;
                  const points = agg.totalRaces * accuracy * (100 + (wpm / 2.0));
                  return {
                    teamTag: agg.teamTag,
                    tier: agg.tier,
                    Races: agg.totalRaces,
                    WPM: wpm,
                    Accuracy: accuracy,
                    Points: points
                  };
                });
                if (teamTierSortConfig.key === 'tier') {
                  calculatedRows.sort((a, b) => teamTierSortConfig.direction === 'asc' ? a.tier.localeCompare(b.tier) : b.tier.localeCompare(a.tier));
                } else if (teamTierSortConfig.key === 'teamTag') {
                  calculatedRows.sort((a, b) => teamTierSortConfig.direction === 'asc' ? a.teamTag.localeCompare(b.teamTag) : b.teamTag.localeCompare(a.teamTag));
                }
                return calculatedRows.map((row) => (
                  <tr key={row.teamTag + '-' + row.tier}>
                    <td>{row.teamTag}</td>
                    <td>
                      <span 
                        style={{
                          display: 'inline-block',
                          width: 24,
                          height: 24,
                          borderRadius: '50%',
                          background: row.tier === 'A' ? '#1976d2' : row.tier === 'B' ? '#9c27b0' : '#ff88f6',
                          color: '#fff',
                          fontWeight: 700,
                          fontSize: 14,
                          lineHeight: '24px',
                          textAlign: 'center',
                          boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
                        }}
                        title={`Tier ${row.tier}`}
                      >
                        {row.tier}
                      </span>
                    </td>
                    <td>{row.Races}</td>
                    <td>{Number(row.WPM).toFixed(1)}</td>
                    <td>{(Number(row.Accuracy) * 100).toFixed(2)}%</td>
                    <td>{Math.round(row.Points).toLocaleString()}</td>
                  </tr>
                ));
              })()}
            </tbody>
          </table>
          <h4 style={{ marginBottom: '1rem', color: '#666' }}>Note: Sums of points in the table do not exactly equal the sums in the team aggregation table above. That is because the NT points formula is non-linear so different aggregations of data can produce different results.</h4>
        </div>
      </div>
    );
  };

  // Main return
  const event = events.find(ev => ev.EventID === selectedEventId);

  return (
    <div className="event-viewer-container">
      {showEventSelector && (
        <div className="event-selector" style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <select
            value={selectedEventId || ''}
            onChange={e => setSelectedEventId(e.target.value ? Number(e.target.value) : null)}
            className="event-dropdown"
          >
            <option value="">Select an event</option>
            {events.map(event => (
              <option key={event.EventID} value={event.EventID}>
                {event.Title} (ID: {event.EventID})
              </option>
            ))}
          </select>
          {selectedEventId && showExportButtons && (
            <div className="export-buttons">
              <button onClick={() => handleExportCurrentTable('csv')} className="export-btn">Export CSV</button>
              <button onClick={() => handleExportCurrentTable('excel')} className="export-btn">Export Excel</button>
            </div>
          )}
        </div>
      )}
      {/* Event Info Section */}
      {selectedEventId && event && (
        <div className="event-info-card">
          <div className="event-info-header">
            <span className="event-info-title">{event.Title}</span>
            <span className={`status-badge status-${event.Status.toLowerCase()}`}>{event.Status}</span>
          </div>
          <div className="event-info-description">{renderTextWithLinks(event.Description)}</div>
          <div className="event-info-details">
            <span><strong>Start:</strong> {new Date(event.StartTime).toLocaleString(undefined, { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })} <b>(CT)</b></span>
            <span><strong>End:</strong> {new Date(event.EndTime).toLocaleString(undefined, { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })} <b>(CT)</b></span>
            <span><strong>Teams:</strong> {event.TeamTag ? event.TeamTag.split(/[, ]+/).filter(Boolean).join(', ') : 'N/A'}</span>
          </div>
          {event.PayoutIncrement && Number(event.PayoutIncrement) !== 0 && (
            <div className="event-paytoplay-details" style={{ marginTop: 12, padding: 12, background: '#232a36', borderRadius: 8, border: '1px solid #2c3440', color: '#fff' }}>
              <h4 style={{ margin: '0 0 8px 0', color: '#4caf50' }}>Pay-to-Play Settings</h4>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px 24px', lineHeight: '1.2' }}>
                <span><strong>Minimum Races:</strong> {event.MinRaces}</span>
                <span><strong>Qualifying Races:</strong> {event.QualifyingRaces}</span>
                <span><strong>Race Increment:</strong> {event.RaceIncrement}</span>
                <span><strong>Payout Increment:</strong> ${Math.round(Number(event.PayoutIncrement)).toLocaleString()}</span>
                <span><strong>Cap:</strong> ${Math.round(Number(event.Cap)).toLocaleString()}</span>
                <span><strong>96% Accuracy Bonus:</strong> {event.AccBonus96}</span>
                <span><strong>98% Accuracy Bonus:</strong> {event.AccBonus98}</span>
              </div>
            </div>
          )}
        </div>
      )}
      {/* Tab bar */}
      <div className="event-tabs-bar" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex' }}>
          <button
            className={`event-tab-btn${activeTab === 'racers' ? ' active' : ''}`}
            onClick={() => setActiveTab('racers')}
          >
            Racers
          </button>
          <button
            className={`event-tab-btn${activeTab === 'squads' ? ' active' : ''}`}
            onClick={() => setActiveTab('squads')}
          >
            Squads
          </button>
          <button
            className={`event-tab-btn${activeTab === 'teams' ? ' active' : ''}`}
            onClick={() => setActiveTab('teams')}
          >
            Teams
          </button>
        </div>
        {(activeTab === 'racers' || activeTab === 'squads' || activeTab === 'teams') && (
          <label style={{ display: 'flex', alignItems: 'center', fontSize: 'inherit' }}>
            <input
              type="checkbox"
              checked={showInactive}
              onChange={e => setShowInactive(e.target.checked)}
              style={{ marginRight: '4px' }}
            />
            Show inactive racers
          </label>
        )}
      </div>
      <div className="tab-content">
        {loading && <div className="loading-indicator">Loading event data...</div>}
        {error && <div className="error-message">{error}</div>}
        {!loading && !error && eventData && (
          <>
            {activeTab === 'racers' && renderRacersTable()}
            {activeTab === 'squads' && (
              <>
                {renderSquadSummary()}
                <SquadDonutCharts participants={(eventData?.participants || []).filter(p => showInactive || p.MemberStatus === 'Active')} />
              </>
            )}
            {activeTab === 'teams' && renderTeamSummary()}
          </>
        )}
      </div>
      {(!loading && !eventData?.participants.length && activeTab === 'racers') && selectedEventId && (
        <div className="event-placeholder">
          <p>No participants found for this event.</p>
        </div>
      )}
      {(!loading && activeTab === 'racers' && !selectedEventId) && (
        <div className="event-placeholder">
          <p>Choose an event from the dropdown above to view participants.</p>
        </div>
      )}
    </div>
  );
}

export default EventViewerCore; 