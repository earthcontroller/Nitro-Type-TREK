import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { DisplayName } from '../Shared/Interfaces';

// Color mapping for squads
const squadColors: Record<string, string> = {
  'Unassigned': '#999999',
  'Avocado': '#a5ce7b',
  'Blueberry': '#85b9e8',
  'Coconut': '#f3f3f4',
  'Dragonfruit': '#f7c4c4',
  'Durian': '#c7eae9',
  'Fig': '#999ac4',
  'Grape': '#c7b3d8',
  'Mango': '#fbe499',
  'Peach': '#f7cba8'
};

function RosterTable({ displayNames }: { displayNames: DisplayName[] }) {
  // Default sort: Joined, ascending
  const [sortConfig, setSortConfig] = React.useState<{ key: string; direction: 'asc' | 'desc' }>({ key: 'Joined', direction: 'asc' });
  const navigate = useNavigate();

  const getSquadSortValue = (row: DisplayName) => row.SquadName || row.squad || '';

  const sortedDisplayNames = useMemo(() => {
    const sorted = [...displayNames];
    if (sortConfig.key === 'SquadName') {
      sorted.sort((a, b) => {
        const aValue = getSquadSortValue(a);
        const bValue = getSquadSortValue(b);
        if (!aValue && bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        if (aValue && !bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        return sortConfig.direction === 'asc'
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      });
    } else if (sortConfig.key) {
      sorted.sort((a, b) => {
        const aValue = a[sortConfig.key as keyof DisplayName];
        const bValue = b[sortConfig.key as keyof DisplayName];
        // Try numeric sort if both are numbers
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return sortConfig.direction === 'asc' ? aValue - bValue : bValue - aValue;
        }
        // Try date sort for Joined
        if (sortConfig.key === 'Joined') {
          const aDate = new Date(aValue as string);
          const bDate = new Date(bValue as string);
          return sortConfig.direction === 'asc' ? aDate.getTime() - bDate.getTime() : bDate.getTime() - aDate.getTime();
        }
        // Fallback to string sort
        return sortConfig.direction === 'asc'
          ? String(aValue).localeCompare(String(bValue))
          : String(bValue).localeCompare(String(aValue));
      });
    }
    return sorted;
  }, [displayNames, sortConfig]);

  const handleSort = (key: string) => {
    if (key === 'Tag') return; // Team Tag is not sortable
    setSortConfig((prev) => {
      if (prev.key === key) {
        return { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' };
      }
      return { key, direction: 'asc' };
    });
  };

  const getSortIcon = (key: string) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  const handleUsernameClick = (username: string) => {
    const searchParams = new URLSearchParams(window.location.search);
    const tag = searchParams.get('tag');
    navigate(`/racers?username=${username}&subtab=batch${tag ? `&tag=${tag}` : ''}`);
  };

  return (
    <table className="display-names-table">
      <thead>
        <tr>
          <th onClick={() => handleSort('CurrentDisplayName')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Current Display Name {getSortIcon('CurrentDisplayName')}
          </th>
          <th onClick={() => handleSort('Username')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Username {getSortIcon('Username')}
          </th>
          <th>Team Tag</th>
          <th onClick={() => handleSort('SquadName')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Squad Name {getSortIcon('SquadName')}
          </th>
          <th onClick={() => handleSort('Joined')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Joined {getSortIcon('Joined')}
          </th>
          <th onClick={() => handleSort('TeamRaces')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Team Races {getSortIcon('TeamRaces')}
          </th>
          <th onClick={() => handleSort('LifetimeRaces')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Lifetime Races {getSortIcon('LifetimeRaces')}
          </th>
          <th onClick={() => handleSort('AvgWPM')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Avg WPM {getSortIcon('AvgWPM')}
          </th>
          <th onClick={() => handleSort('TopWPM')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Top WPM {getSortIcon('TopWPM')}
          </th>
          <th onClick={() => handleSort('Tier')} className="sortable-header" style={{ cursor: 'pointer' }}>
            Tier {getSortIcon('Tier')}
          </th>
        </tr>
      </thead>
      <tbody>
        {sortedDisplayNames.map((item, index) => (
          <tr key={index}>
            <td>
              <a
                href={`https://www.nitrotype.com/racer/${item.Username}`}
                target="_blank"
                rel="noopener noreferrer"
                tabIndex={0}
                aria-label={`View ${item.Username} on Nitrotype`}
              >
                {item.CurrentDisplayName}
                {item.bot === 1 && <span title="Bot" style={{ marginLeft: 4 }}>🤖</span>}
              </a>
            </td>
            <td>
              <button
                className="username-link"
                onClick={() => handleUsernameClick(item.Username)}
                tabIndex={0}
                aria-label={`Go to ${item.Username} in Racers Batch Inspector`}
              >
                {item.Username}
              </button>
            </td>
            <td>{item.Tag}</td>
            <td>
              <span 
                className="squad-name-badge"
                style={{ 
                  backgroundColor: squadColors[item.squad || 'Unassigned'],
                  color: '#000000'
                }}
              >
                {item.SquadName}
              </span>
            </td>
            <td>{item.Joined}</td>
            <td>{item.TeamRaces}</td>
            <td>{item.LifetimeRaces}</td>
            <td>{item.AvgWPM}</td>
            <td>{item.TopWPM}</td>
            <td>
              <span 
                style={{
                  display: 'inline-block',
                  width: 24,
                  height: 24,
                  borderRadius: '50%',
                  background: item.Tier === 'A' ? '#1976d2' : item.Tier === 'B' ? '#9c27b0' : '#ff88f6',
                  color: '#fff',
                  fontWeight: 700,
                  fontSize: 14,
                  lineHeight: '24px',
                  textAlign: 'center',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
                }}
                title={`Tier ${item.Tier}`}
              >
                {item.Tier}
              </span>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default RosterTable; 