import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Chart } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartDataLabels
);

interface WarnListMember {
  UserID: number;
  CurrentDisplayName: string;
  Username: string;
  TeamTag: string;
  joinStamp: string | null;
  weeklyRaceHistory: number[];
}

interface WarnListTableProps {
  selectedTag: string | null;
}

function WeeklyRaceSparkline({ data, weeklyRequirements }: { data: number[], weeklyRequirements: number | null }) {
  const weekLabels = [
    '6 weeks ago',
    '5 weeks ago',
    '4 weeks ago',
    '3 weeks ago',
    '2 weeks ago',
    'Last Week',
    'This Week',
  ];

  const datasets: any[] = [
    {
      type: 'bar' as const,
      label: 'Races',
      data: data,
      backgroundColor: data.map((races) => {
        if (weeklyRequirements === null || races >= weeklyRequirements) {
          return '#4CAF50'; // Green: Requirement met or no requirement set
        }
        return '#F44336'; // Red: Requirement not met
      }),
      borderColor: '#333333',
      borderWidth: 1,
      borderRadius: 2,
      barThickness: 8,
      order: 2,
    },
  ];

  if (weeklyRequirements && weeklyRequirements > 0) {
    datasets.push({
      type: 'line' as const,
      label: 'Min Races',
      data: Array(7).fill(weeklyRequirements),
      borderColor: '#FFC107',
      borderWidth: 2,
      borderDash: [5, 5],
      pointRadius: 0,
      fill: false,
      order: 1,
    });
  }

  const chartData = {
    labels: weekLabels,
    datasets: datasets,
  };

  const options: any = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        filter: (tooltipItem: any) => {
          // Only show tooltip for the bar chart
          return tooltipItem.datasetIndex === 0;
        },
        callbacks: {
          label: (context: any) => `Races: ${context.parsed.y}`,
        },
      },
      datalabels: {
        display: false,
      },
    },
    scales: {
      x: {
        display: false,
      },
      y: {
        display: false,
        beginAtZero: true,
        suggestedMax: Math.max(...data, (weeklyRequirements || 0) + 2), // Give a little space above the line
      },
    },
  };

  return (
    <div style={{ width: '120px', height: '40px' }}>
      <Chart type="bar" data={chartData} options={options} />
    </div>
  );
}

export default function WarnListTable({ selectedTag }: WarnListTableProps) {
  const [members, setMembers] = useState<WarnListMember[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: string | null; direction: 'asc' | 'desc' }>({ key: 'Last Week', direction: 'asc' });
  const [weeklyRequirements, setWeeklyRequirements] = useState<number | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!selectedTag) {
      setMembers([]);
      setWeeklyRequirements(null);
      return;
    }
    
    setLoading(true);
    setError(null);
    
    fetch(`/api/warn-list?tag=${encodeURIComponent(selectedTag)}`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch data');
        return res.json();
      })
      .then(data => {
        setMembers(data.members || []);
        setWeeklyRequirements(data.weeklyRequirements);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setMembers([]);
        setWeeklyRequirements(null);
        setLoading(false);
      });
  }, [selectedTag]);

  const handleSort = (key: string) => {
    setSortConfig(prevConfig => ({
      key,
      direction: prevConfig.key === key && prevConfig.direction === 'desc' ? 'asc' : 'desc'
    }));
  };

  const shouldShowWarning = (member: WarnListMember, weeklyRequirements: number | null, fourteenDaysAgo: Date): boolean => {
    if (!weeklyRequirements || weeklyRequirements <= 0) {
      return false;
    }

    const lastWeekRaces = member.weeklyRaceHistory[1] ?? 0;
    const thisWeekRaces = member.weeklyRaceHistory[0] ?? 0;

    if (lastWeekRaces >= weeklyRequirements || thisWeekRaces >= weeklyRequirements) {
      return false;
    }

    if (!member.joinStamp) {
      return false;
    }

    const joinDate = new Date(member.joinStamp);

    return joinDate <= fourteenDaysAgo;
  };

  const fourteenDaysAgo = new Date();
  fourteenDaysAgo.setDate(new Date().getDate() - 14);

  const sortedMembers = [...members].sort((a, b) => {
    const aHasWarning = shouldShowWarning(a, weeklyRequirements, fourteenDaysAgo);
    const bHasWarning = shouldShowWarning(b, weeklyRequirements, fourteenDaysAgo);

    if (aHasWarning !== bHasWarning) {
      return aHasWarning ? -1 : 1;
    }
    
    if (!sortConfig.key) return 0;
    
    let aValue: any, bValue: any;
    
    if (sortConfig.key === 'This Week') {
      aValue = a.weeklyRaceHistory[0] ?? 0;
      bValue = b.weeklyRaceHistory[0] ?? 0;
      return sortConfig.direction === 'asc' ? aValue - bValue : bValue - aValue;
    }
    if (sortConfig.key === 'Last Week') {
      aValue = a.weeklyRaceHistory[1] ?? 0;
      bValue = b.weeklyRaceHistory[1] ?? 0;
      return sortConfig.direction === 'asc' ? aValue - bValue : bValue - aValue;
    }
    
    aValue = a[sortConfig.key as keyof WarnListMember];
    bValue = b[sortConfig.key as keyof WarnListMember];

    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortConfig.direction === 'asc' 
        ? aValue.localeCompare(bValue) 
        : bValue.localeCompare(aValue);
    }
    
    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return sortConfig.direction === 'asc' ? aValue - bValue : bValue - aValue;
    }
    
    return 0;
  });

  const getSortIcon = (columnKey: string) => {
    if (sortConfig.key !== columnKey) return '↕️';
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  const handleUsernameClick = (username: string) => {
    navigate(`/racers?username=${username}&subtab=batch`);
  };

  const formatJoinDate = (joinStamp: string | null) => {
    if (!joinStamp) return 'N/A';
    try {
      return new Date(joinStamp).toLocaleDateString();
    } catch {
      return 'N/A';
    }
  };

  if (loading) {
    return <div className="loading-message">Loading warn list...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="event-details">
      <div style={{ marginBottom: 12 }}>
        <h3 style={{ margin: 0 }}>Warn List - 7-Week Race Trend</h3>
        <p style={{ margin: '8px 0 0 0', color: 'var(--text-secondary)', fontSize: '14px' }}>
          If team has set Weekly Race Requirements, this table will flag racers that did not meet the requirements the last week.  
          Sparklines show race activity over the past 7 weeks with color coding: 
          <span style={{ color: '#4CAF50' }}> Green</span> (met team requirements), 
          <span style={{ color: '#FFC107' }}> Yellow</span> (team requiements), 
          <span style={{ color: '#F44336' }}> Red</span> (did not meet team requirements).
        </p>
      </div>
      
      {members.length > 0 ? (
        <table className="display-names-table">
          <thead>
            <tr>
              <th onClick={() => handleSort('CurrentDisplayName')} className="sortable-header">
                Display Name {getSortIcon('CurrentDisplayName')}
              </th>
              <th onClick={() => handleSort('Username')} className="sortable-header">
                Username {getSortIcon('Username')}
              </th>
              <th onClick={() => handleSort('TeamTag')} className="sortable-header">
                Team Tag {getSortIcon('TeamTag')}
              </th>
              <th onClick={() => handleSort('joinStamp')} className="sortable-header">
                Joined {getSortIcon('joinStamp')}
              </th>
              <th>7-Week Race Trend</th>
              <th onClick={() => handleSort('This Week')} className="sortable-header">This Week {getSortIcon('This Week')}</th>
              <th onClick={() => handleSort('Last Week')} className="sortable-header">Last Week {getSortIcon('Last Week')}</th>
            </tr>
          </thead>
          <tbody>
            {sortedMembers.map((member) => (
              <tr key={member.UserID}>
                <td>
                  {shouldShowWarning(member, weeklyRequirements, fourteenDaysAgo) && <span style={{ marginRight: '8px', fontSize: '1.2em' }}>⚠️</span>}
                  <a
                    href={`https://www.nitrotype.com/racer/${member.Username}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    tabIndex={0}
                    aria-label={`View ${member.Username} on Nitrotype`}
                  >
                    {member.CurrentDisplayName}
                  </a>
                </td>
                <td>
                  <button
                    className="username-link"
                    onClick={() => handleUsernameClick(member.Username)}
                    tabIndex={0}
                    aria-label={`Go to ${member.Username} in Racers Batch Inspector`}
                  >
                    {member.Username}
                  </button>
                </td>
                <td>{member.TeamTag}</td>
                <td>{formatJoinDate(member.joinStamp)}</td>
                <td>
                  <WeeklyRaceSparkline
                    data={[...member.weeklyRaceHistory].reverse()}
                    weeklyRequirements={weeklyRequirements}
                  />
                </td>
                <td>{member.weeklyRaceHistory[0]}</td>
                <td>{member.weeklyRaceHistory[1]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="event-placeholder">
          <p>No members found for this team.</p>
        </div>
      )}
    </div>
  );
} 