import React, { useState, useEffect } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { DisplayName } from '../Shared/Interfaces';
import { PayToPlayModal } from './PayToPlayModal';

interface DragItem {
  username: string;
  currentSquad: string;
}

interface EditNameDialogProps {
  open: boolean;
  onClose: () => void;
  onSave: (newName: string) => void;
  currentName: string;
  squad: string;
}

const EditNameDialog = ({ open, onClose, onSave, currentName }: EditNameDialogProps) => {
  const [newName, setNewName] = useState(currentName);

  const handleSave = () => {
    onSave(newName);
    onClose();
  };

  const handleRemove = () => {
    onSave('');  // Send empty string to clear the custom name
    onClose();
  };

  return (
    <div className={`modal ${open ? 'show' : ''}`} onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <h2>Edit Squad Name</h2>
        <input
          type="text"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="Enter custom name"
        />
        <div className="modal-buttons" style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 16 }}>
          <button onClick={handleSave} style={{ minWidth: 80, color: '#fff', background: '#1976d2', border: 'none' }}>Save</button>
          <button onClick={handleRemove} className="remove-button" style={{ minWidth: 80, color: '#fff', background: '#e53935', border: 'none' }}>Remove Custom Name</button>
          <button onClick={onClose} style={{ minWidth: 80, color: '#333', background: '#fff', border: '1px solid #ccc' }}>Cancel</button>
        </div>
      </div>
    </div>
  );
};

const MemberCard = ({ member }: { member: DisplayName }) => {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'member',
    item: { 
      username: member.Username,
      currentSquad: member.squad 
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  return (
    <div
      ref={drag}
      className="member-name"
      style={{ opacity: isDragging ? 0.5 : 1 }}
    >
      {member.CurrentDisplayName}
    </div>
  );
};

const squadColors: Record<string, string> = {
  'Unassigned': '#999999',
  'Avocado': '#a5ce7b',
  'Blueberry': '#85b9e8',
  'Coconut': '#f3f3f4',
  'Dragonfruit': '#f7c4c4',
  'Durian': '#c7eae9',
  'Fig': '#999ac4',
  'Grape': '#c7b3d8',
  'Mango': '#fbe499',
  'Peach': '#f7cba8'
};

const SquadBox = ({ squad, members, onDrop, selectedTag, setDisplayNames }: { 
  squad: string; 
  members: DisplayName[]; 
  onDrop: (username: string, newSquad: string) => void;
  selectedTag: string;
  setDisplayNames: React.Dispatch<React.SetStateAction<DisplayName[]>>;
}) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [customName, setCustomName] = useState(() => {
    if (members.length > 0 && members[0].SquadName !== squad) {
      return members[0].SquadName;
    }
    return squad;
  });

  useEffect(() => {
    if (members.length > 0 && members[0].SquadName !== squad) {
      setCustomName(members[0].SquadName);
    } else {
      setCustomName(squad);
    }
  }, [members, squad]);

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDialogOpen(true);
  };

  const handleSave = async (newName: string) => {
    try {
      const response = await fetch('/api/update-custom-squad-name', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          tag: selectedTag,
          squad: squad,
          customName: newName
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update squad name');
      }

      setCustomName(newName || squad);

      const url = `/api/current-display-names?tag=${encodeURIComponent(selectedTag)}`;
      const displayNamesResponse = await fetch(url);
      if (!displayNamesResponse.ok) {
        throw new Error('Failed to refresh display names');
      }
      const data = await displayNamesResponse.json();
      setDisplayNames(data);

    } catch (error) {
      console.error('Error updating squad name:', error);
      alert('Failed to update squad name');
    }
  };

  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'member',
    drop: (item: DragItem) => {
      if (item.currentSquad !== squad) {
        onDrop(item.username, squad);
      }
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  }));

  return (
    <div
      ref={drop}
      className="squad-box"
      style={{ 
        backgroundColor: isOver ? `${squadColors[squad]}80` : undefined,
        transition: 'background-color 0.2s ease'
      }}
    >
      <div className="squad-header" style={{ backgroundColor: squadColors[squad] }}>
        {squad !== 'Unassigned' && (
          <div className="squad-header-content">
            <span>{customName || squad}</span>
            <button className="edit-button" onClick={handleEditClick}>✎</button>
          </div>
        )}
        {squad === 'Unassigned' && <span>{squad}</span>}
      </div>
      <div className="squad-content">
        {members.map((member) => (
          <MemberCard key={member.Username} member={member} />
        ))}
      </div>
      <EditNameDialog
        open={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        onSave={handleSave}
        currentName={customName}
        squad={squad}
      />
    </div>
  );
};

export function SquadsPage({ displayNames, selectedTag, setDisplayNames }: { 
  displayNames: DisplayName[]; 
  selectedTag: string;
  setDisplayNames: React.Dispatch<React.SetStateAction<DisplayName[]>>;
}): JSX.Element {
  const groupedMembers = displayNames.reduce((acc, member) => {
    const squad = member.squad || 'Unassigned';
    if (!acc[squad]) {
      acc[squad] = [];
    }
    acc[squad].push(member);
    return acc;
  }, {} as Record<string, DisplayName[]>);

  const handleDrop = async (username: string, newSquad: string) => {
    try {
      console.log('Updating squad:', { username, squad: newSquad }); // Debug log
      const response = await fetch('/api/update-member-squad', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          squad: newSquad
        })
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to update squad');
      }

      console.log('Squad updated successfully:', data); // Debug log

      // Refresh the display names to get updated data
      const url = `/api/current-display-names?tag=${encodeURIComponent(selectedTag)}`;
      const displayNamesResponse = await fetch(url);
      if (!displayNamesResponse.ok) {
        throw new Error('Failed to refresh display names');
      }
      const newData = await displayNamesResponse.json();
      setDisplayNames(newData);

    } catch (error) {
      console.error('Error updating squad:', error);
      alert(error instanceof Error ? error.message : 'Failed to update squad');
    }
  };

  const [unassignLoading, setUnassignLoading] = useState(false);

  const handleUnassignAll = async () => {
    if (unassignLoading) return;
    const confirmed = window.confirm(
      `This action will remove all squad assignments for ${selectedTag}. Are you sure you want to continue?`
    );
    if (!confirmed) return;

    setUnassignLoading(true);
    try {
      const response = await fetch('/api/unassign-all-members', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tag: selectedTag })
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to unassign all members');
      }

      alert('All members unassigned successfully!');
      // Refresh the display names to get updated data
      const url = `/api/current-display-names?tag=${encodeURIComponent(selectedTag)}`;
      const displayNamesResponse = await fetch(url);
      if (!displayNamesResponse.ok) {
        throw new Error('Failed to refresh display names');
      }
      const newData = await displayNamesResponse.json();
      setDisplayNames(newData);

    } catch (error) {
      console.error('Error unassigning all members:', error);
      alert(error instanceof Error ? error.message : 'Failed to unassign all members');
    } finally {
      setUnassignLoading(false);
    }
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="squads-container" style={{ position: 'relative' }}>
        <div className="squads-grid">
          <SquadBox
            squad="Unassigned"
            members={groupedMembers['Unassigned'] || []}
            onDrop={handleDrop}
            selectedTag={selectedTag}
            setDisplayNames={setDisplayNames}
          />
          <div className="squads-grid-right">
            {['Avocado', 'Blueberry', 'Coconut', 'Dragonfruit', 'Durian', 'Fig', 'Grape', 'Mango', 'Peach'].map((squad) => (
              <SquadBox
                key={squad}
                squad={squad}
                members={groupedMembers[squad] || []}
                onDrop={handleDrop}
                selectedTag={selectedTag}
                setDisplayNames={setDisplayNames}
              />
            ))}
          </div>
        </div>
        {/* Unassign All button absolutely positioned below Unassigned box */}
        <button
          onClick={handleUnassignAll}
          disabled={unassignLoading}
          className="unassign-all-btn"
        >
          {unassignLoading ? 'Unassigning...' : 'Unassign All'}
        </button>
      </div>
    </DndProvider>
  );
}

function AdminEventModal({ open, onClose, onSubmit, initialData, loading, error }: {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  initialData?: any;
  loading?: boolean;
  error?: string | null;
}) {
  // Format date for datetime-local input
  function formatDateTime(dt: string) {
    if (!dt) return '';
    const d = new Date(dt);
    // Pad with zeros
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  const [form, setForm] = useState<any>(initialData ? {
    ...initialData,
    StartTime: formatDateTime(initialData.StartTime),
    EndTime: formatDateTime(initialData.EndTime),
    DefaultSort: 'Races',
  } : {
    Title: '',
    Description: '',
    TeamTag: '',
    StartTime: '',
    EndTime: '',
    DefaultSort: 'Races',
  });

  useEffect(() => {
    setForm(initialData ? {
      ...initialData,
      StartTime: formatDateTime(initialData.StartTime),
      EndTime: formatDateTime(initialData.EndTime)
    } : {
      Title: '',
      Description: '',
      TeamTag: '',
      StartTime: '',
      EndTime: '',
      DefaultSort: 'Races',
    });
  }, [initialData, open]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
  };

  // Calculate status for display
  let status = '';
  if (form.StartTime && form.EndTime) {
    const now = new Date();
    const start = new Date(form.StartTime);
    const end = new Date(form.EndTime);
    if (now < start) status = 'Pending';
    else if (now >= start && now <= end) status = 'Active';
    else status = 'Concluded';
  }

  if (!open) return null;

  return (
    <div className="modal show" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ minWidth: 300, maxWidth: 400 }}>
        <h2>{initialData ? 'Edit Event' : 'Add Event'}</h2>
        {initialData && (
          <div style={{ marginBottom: 8 }}>
            <span className={`status-badge status-${status.toLowerCase()}`}>{status}</span>
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <label>Title<input name="Title" value={form.Title} onChange={handleChange} required /></label>
          <label>Description</label>
          <textarea name="Description" value={form.Description} onChange={handleChange} rows={3} style={{ width: '100%', marginBottom: 8, background: '#fff', color: '#000' }} />
          <label>Team Tag(s)</label>
          <div className="input-helper" style={{ fontStyle: 'italic', marginBottom: 2 }}>Enter participating Team Tag(s) separated by spaces.</div>
          <input name="TeamTag" value={form.TeamTag} onChange={handleChange} required placeholder="e.g. BEEHVE TEAM2" style={{ width: '100%' }} />
          <label>Start Time (CT)<input name="StartTime" value={form.StartTime} onChange={handleChange} required type="datetime-local" style={{ width: '100%' }} /></label>
          <label>End Time (CT)<input name="EndTime" value={form.EndTime} onChange={handleChange} required type="datetime-local" style={{ width: '100%' }} /></label>
          <label>Default Sort</label>
          <div className="input-helper" style={{ fontStyle: 'italic', marginBottom: 2 }}>Select the default sort column for this event's tables.</div>
          <select name="DefaultSort" value={form.DefaultSort || 'Races'} onChange={handleChange} required style={{ width: '100%', marginBottom: 8, background: '#fff', color: '#000' }}>
            <option value="Races">Races</option>
            <option value="WPM">WPM</option>
            <option value="Accuracy">Accuracy</option>
            <option value="Points">Points</option>
          </select>
          {error && <div className="error-message">{error}</div>}
          <div style={{ marginTop: 16, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button type="button" onClick={onClose} style={{ minWidth: 80, color: '#333', background: '#fff', border: '1px solid #ccc' }}>Cancel</button>
            <button type="submit" disabled={loading} style={{ minWidth: 80, color: '#fff', background: '#1976d2', border: 'none' }}>{loading ? 'Saving...' : 'Save'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AdminDeleteDialog({ open, onClose, onConfirm, loading, error }: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  loading?: boolean;
  error?: string | null;
}) {
  if (!open) return null;
  return (
    <div className="modal show" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ minWidth: 320 }}>
        <h3>Delete Event?</h3>
        <p>Are you sure you want to delete this event? This action cannot be undone.</p>
        {error && <div className="error-message">{error}</div>}
        <div style={{ marginTop: 16, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button type="button" onClick={onClose} style={{ minWidth: 80, color: '#333', background: '#fff', border: '1px solid #ccc' }}>Cancel</button>
          <button type="button" onClick={onConfirm} disabled={loading} style={{ minWidth: 80, background: '#e53935', color: '#fff', border: 'none' }}>{loading ? 'Deleting...' : 'Delete'}</button>
        </div>
      </div>
    </div>
  );
}

function AdminEventsSection({ selectedTag, events, setEvents }: { 
  selectedTag: string;
  events: any[];
  setEvents: React.Dispatch<React.SetStateAction<any[]>>;
}) {
  const [eventModalOpen, setEventModalOpen] = useState(false);
  const [eventModalLoading, setEventModalLoading] = useState(false);
  const [eventModalError, setEventModalError] = useState<string | null>(null);
  const [eventModalInitial, setEventModalInitial] = useState<any | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteEventId, setDeleteEventId] = useState<number | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [payModalEvent, setPayModalEvent] = useState<any | null>(null);
  const [payModalOpen, setPayModalOpen] = useState(false);
  const [payModalLoading, setPayModalLoading] = useState(false);
  const [payModalError, setPayModalError] = useState<string | null>(null);

  const handleAddEvent = () => {
    setEventModalInitial(null);
    setEventModalOpen(true);
  };
  const handleEditEvent = (event: any) => {
    setEventModalInitial(event);
    setEventModalOpen(true);
  };
  const handleDeleteEvent = (eventId: number) => {
    setDeleteEventId(eventId);
    setDeleteDialogOpen(true);
  };
  const handlePayToPlay = (event: any) => {
    setPayModalEvent(event);
    setPayModalOpen(true);
  };
  const handlePayToPlaySubmit = async (form: any) => {
    setPayModalLoading(true);
    setPayModalError(null);
    try {
      const response = await fetch(`/api/admin/events/${payModalEvent.EventID}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(form)
      });
      if (!response.ok) {
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          const data = await response.json();
          throw new Error(data.error || 'Failed to update pay-to-play settings');
        } else {
          throw new Error('Server error occurred');
        }
      }
      setPayModalOpen(false);
      // Refresh events list
      const eventsResponse = await fetch('/api/team-events?tag=' + encodeURIComponent(selectedTag));
      if (!eventsResponse.ok) {
        throw new Error('Failed to refresh events');
      }
      const eventsData = await eventsResponse.json();
      setEvents(eventsData || []);
    } catch (error) {
      setPayModalError(error instanceof Error ? error.message : 'Failed to update pay-to-play settings');
    } finally {
      setPayModalLoading(false);
    }
  };
  const handleEventModalSubmit = async (form: any) => {
    setEventModalLoading(true);
    setEventModalError(null);
    try {
      if (eventModalInitial) {
        // Edit
        const res = await fetch(`/api/admin/events/${eventModalInitial.EventID}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(form),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to update event');
        // Refresh events list to get properly formatted data
        const eventsResponse = await fetch('/api/team-events?tag=' + encodeURIComponent(selectedTag));
        if (!eventsResponse.ok) {
          throw new Error('Failed to refresh events');
        }
        const eventsData = await eventsResponse.json();
        setEvents(eventsData || []);
      } else {
        // Add
        const res = await fetch('/api/admin/events', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(form),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to add event');
        // Refresh events list to get properly formatted data
        const eventsResponse = await fetch('/api/team-events?tag=' + encodeURIComponent(selectedTag));
        if (!eventsResponse.ok) {
          throw new Error('Failed to refresh events');
        }
        const eventsData = await eventsResponse.json();
        setEvents(eventsData || []);
      }
      setEventModalOpen(false);
    } catch (err: any) {
      setEventModalError(err.message);
    } finally {
      setEventModalLoading(false);
    }
  };
  const handleDeleteConfirm = async () => {
    if (!deleteEventId) return;
    setDeleteLoading(true);
    setDeleteError(null);
    try {
      const res = await fetch(`/api/admin/events/${deleteEventId}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete event');
      setEvents(evts => evts.filter(e => e.EventID !== deleteEventId));
      setDeleteDialogOpen(false);
    } catch (err: any) {
      setDeleteError(err.message);
    } finally {
      setDeleteLoading(false);
    }
  };

  const actionBtnStyle = {
    width: 40,
    height: 40,
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    border: 'none',
    marginRight: '0.5rem',
    padding: 0,
  };

  return (
    <div className="admin-events-section">
      <h2>Admin Events</h2>
      <button className="add-event-btn" style={{ marginBottom: '1rem' }} aria-label="Add Event" onClick={handleAddEvent}>
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ marginRight: 6, verticalAlign: 'middle' }}>
          <circle cx="10" cy="10" r="10" fill="#1976d2"/>
          <path d="M10 5v10M5 10h10" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
        </svg>
        Add Event
      </button>
      <table className="display-names-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Status</th>
            <th>Start Time (CT)</th>
            <th>End Time (CT)</th>
            <th>Teams</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {events.map(event => (
            <tr key={event.EventID}>
              <td>{event.Title}</td>
              <td>{event.Description}</td>
              <td><span className={`status-badge status-${event.Status.toLowerCase()}`}>{event.Status}</span></td>
              <td>{new Date(event.StartTime).toLocaleString()}</td>
              <td>{new Date(event.EndTime).toLocaleString()}</td>
              <td>{event.TeamTag}</td>
              <td>
                <div className="event-action-btns">
                  
                  <button
                    className="edit-event-btn"
                    aria-label="Edit Event"
                    style={{ ...actionBtnStyle, background: '#1976d2', color: '#fff' }}
                    onClick={() => handleEditEvent(event)}
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M3 14.25V17h2.75l8.13-8.13-2.75-2.75L3 14.25zM17.71 6.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" fill="currentColor"/>
                    </svg>
                  </button>
                  <button
                    className="pay-to-play-btn"
                    aria-label="Pay-to-Play Settings"
                    style={{ ...actionBtnStyle, background: '#4caf50', color: '#fff' }}
                    onClick={() => handlePayToPlay(event)}
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="11" cy="11" r="11" fill="none"/>
                      <text x="11" y="16" textAnchor="middle" fontSize="16" fill="#fff" fontWeight="bold">$</text>
                    </svg>
                  </button>
                  <button
                    className="delete-event-btn"
                    aria-label="Delete Event"
                    style={{ ...actionBtnStyle, background: '#e53935', color: '#fff', marginRight: 0 }}
                    onClick={() => handleDeleteEvent(event.EventID)}
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M6 7v8a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V7" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M4 7h12" stroke="#fff" strokeWidth="1.5" strokeLinecap="round"/>
                      <path d="M8 7V5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2" stroke="#fff" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <AdminEventModal open={eventModalOpen} onClose={() => setEventModalOpen(false)} onSubmit={handleEventModalSubmit} initialData={eventModalInitial} loading={eventModalLoading} error={eventModalError} />
      <AdminDeleteDialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)} onConfirm={handleDeleteConfirm} loading={deleteLoading} error={deleteError} />
      <PayToPlayModal 
        open={payModalOpen} 
        onClose={() => setPayModalOpen(false)} 
        onSubmit={handlePayToPlaySubmit} 
        initialData={payModalEvent} 
        loading={payModalLoading} 
        error={payModalError} 
      />
    </div>
  );
}

export { AdminEventsSection };