import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ChartDataLabels);

interface TeamTierRow {
  teamTag: string;
  tier: string;
  Races: number;
  WPM: number;
  Accuracy: number;
}

interface DuelBoxProps {
  rows: TeamTierRow[];
  teamColors: Record<string, string>;
  eventInfo: { TeamTag: string; StartTime?: string; EndTime?: string; Status?: string };
}

const metricLabels = [
  { key: 'Races', label: 'Races', icon: '🏁' },
  { key: 'WPM', label: 'WPM', icon: '⚡' },
  { key: 'Accuracy', label: 'Accuracy', icon: '🎯' },
];

const tierOrder = ['A', 'B', 'C'];

const metricColors: Record<string, string[]> = {
  Races: ['#43a047', '#1976d2'], // blue, yellow
  WPM: ['#43a047', '#1976d2'],   // blue, green
  Accuracy: ['#43a047', '#1976d2'], // green, blue
};

// Helper to format time left
function formatTimeLeft(ms: number) {
  if (ms <= 0) return '';
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  let parts = [];
  if (days > 0) parts.push(`${days} day${days > 1 ? 's' : ''}`);
  if (hours > 0) parts.push(`${hours} hour${hours > 1 ? 's' : ''}`);
  if (minutes > 0 && days === 0) parts.push(`${minutes} minute${minutes > 1 ? 's' : ''}`);
  if (parts.length === 0) return 'less than a minute';
  return parts.join(' ');
}

const DuelBox: React.FC<DuelBoxProps> = ({ rows, eventInfo }) => {
  // Get expected teams from event info
  const expectedTeams = eventInfo.TeamTag ? eventInfo.TeamTag.split(/[, ]+/).filter(Boolean) : [];
  if (expectedTeams.length !== 2) return null;
  const teams = expectedTeams;
  const tiers = tierOrder.filter(t => rows.some(r => r.tier === t));

  // Build duel score structure and breakdown
  const duelScores: Record<string, number> = { [teams[0]]: 0, [teams[1]]: 0 };
  const tierBreakdown: Record<string, any> = {};
  tiers.forEach(tier => {
    const teamAData = rows.find(r => r.teamTag === teams[0] && r.tier === tier) || { teamTag: teams[0], tier, Races: 0, Accuracy: 0, WPM: 0 };
    const teamBData = rows.find(r => r.teamTag === teams[1] && r.tier === tier) || { teamTag: teams[1], tier, Races: 0, Accuracy: 0, WPM: 0 };
    // Races
    let racesWinners: string[] = [];
    if (teamAData.Races > teamBData.Races) racesWinners = [teamAData.teamTag];
    else if (teamBData.Races > teamAData.Races) racesWinners = [teamBData.teamTag];
    else racesWinners = [teamAData.teamTag, teamBData.teamTag];
    racesWinners.forEach(t => duelScores[t] += 3);
    // Accuracy
    let accWinners: string[] = [];
    if (teamAData.Accuracy > teamBData.Accuracy) accWinners = [teamAData.teamTag];
    else if (teamBData.Accuracy > teamAData.Accuracy) accWinners = [teamBData.teamTag];
    else accWinners = [teamAData.teamTag, teamBData.teamTag];
    accWinners.forEach(t => duelScores[t] += 1);
    // WPM
    let wpmWinners: string[] = [];
    if (teamAData.WPM > teamBData.WPM) wpmWinners = [teamAData.teamTag];
    else if (teamBData.WPM > teamAData.WPM) wpmWinners = [teamBData.teamTag];
    else wpmWinners = [teamAData.teamTag, teamBData.teamTag];
    wpmWinners.forEach(t => duelScores[t] += 1);
    // Save breakdown
    tierBreakdown[tier] = {
      races: racesWinners,
      accuracy: accWinners,
      wpm: wpmWinners,
      rows: [teamAData, teamBData]
    };
  });
  // Determine winner
  let winner = null;
  if (duelScores[teams[0]] > duelScores[teams[1]]) winner = teams[0];
  else if (duelScores[teams[1]] > duelScores[teams[0]]) winner = teams[1];

  // Prepare data for each metric
  const getChartData = (metric: 'Races' | 'WPM' | 'Accuracy') => {
    const colors = metricColors[metric] || ['#1976d2', '#ffc107', '#43a047'];
    return {
      labels: tiers,
      datasets: teams.map((team, idx) => ({
        label: team,
        data: tiers.map(tier => {
          const row = rows.find(r => r.teamTag === team && r.tier === tier);
          if (!row) return 0;
          if (metric === 'Accuracy') return Number((row.Accuracy * 100).toFixed(2));
          return Number(row[metric].toFixed(2));
        }),
        backgroundColor: colors[idx % colors.length],
        borderRadius: 8,
        maxBarThickness: 32,
      })),
    };
  };

  const chartOptions = (metric: string) => ({
    indexAxis: 'y' as const,
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          font: { size: 16 },
          color: '#fff',
        },
      },
      title: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (ctx: any) => {
            if (metric === 'Accuracy') return `${ctx.dataset.label}: ${ctx.parsed.x.toFixed(2)}%`;
            return `${ctx.dataset.label}: ${ctx.parsed.x}`;
          },
        },
      },
      datalabels: {
        color: '#fff',
        font: { weight: 'bold' as const, size: 14 },
        anchor: 'center' as const,
        align: 'center' as const,
        formatter: (value: number) => value != null ? value.toLocaleString() : '',
        display: true,
        clamp: true,
        clip: false,
      },
    },
    scales: {
      x: {
        beginAtZero: true,
        grid: { color: '#333' },
        ticks: { color: '#fff', font: { size: 15 } },
        min: metric === 'Accuracy' ? 85 : undefined,
      },
      y: {
        grid: { color: '#333' },
        ticks: {
          color: '#fff',
          font: { size: 16 },
          callback: (val: any, idx: number) => {
            const t = tiers[idx];
            return t ? t : val;
          },
        },
      },
    },
    layout: {
      padding: 12,
    },
    maintainAspectRatio: false,
    aspectRatio: 2.2,
  });

  // Determine event timing
  let isConcluded = false;
  let isNotStarted = false;
  let isOngoing = false;
  const now = new Date();
  let start: Date | undefined = undefined;
  let end: Date | undefined = undefined;
  if (eventInfo.StartTime) start = new Date(eventInfo.StartTime);
  if (eventInfo.EndTime) end = new Date(eventInfo.EndTime);
  if (eventInfo.Status) {
    isConcluded = eventInfo.Status.toLowerCase() === 'concluded';
    isNotStarted = eventInfo.Status.toLowerCase() === 'pending';
    isOngoing = eventInfo.Status.toLowerCase() === 'active';
  } else if (start && end) {
    if (now < start) isNotStarted = true;
    else if (now > end) isConcluded = true;
    else isOngoing = true;
  } else if (end) {
    if (now > end) isConcluded = true;
    else isOngoing = true;
  }

  return (
    <div style={{ width: '100%', margin: '2rem 0 0 0', background: '#232a36', borderRadius: 12 }}>
      {/* Duel Table (graphical) */}
      <div style={{ margin: '0 0 2rem 0', padding: '1rem', background: '#1a1d23', borderRadius: 8, border: '1px solid #2c3440', color: '#fff', maxWidth: '100%', overflowX: 'auto' }}>
        <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 1, textAlign: 'center', letterSpacing: 1, position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
            🏆 It's a Duel! 🏆
            <span style={{ position: 'relative', display: 'inline-block' }}>
              <span
                style={{
                  cursor: 'pointer',
                  fontSize: 18,
                  marginLeft: 6,
                  color: '#b0b8c9',
                  verticalAlign: 'middle',
                  userSelect: 'none',
                }}
                tabIndex={0}
                aria-label="What is a Duel?"
                onMouseEnter={e => {
                  const tooltip = e.currentTarget.nextSibling as HTMLElement;
                  if (tooltip) tooltip.style.display = 'block';
                }}
                onMouseLeave={e => {
                  const tooltip = e.currentTarget.nextSibling as HTMLElement;
                  if (tooltip) tooltip.style.display = 'none';
                }}
                onFocus={e => {
                  const tooltip = e.currentTarget.nextSibling as HTMLElement;
                  if (tooltip) tooltip.style.display = 'block';
                }}
                onBlur={e => {
                  const tooltip = e.currentTarget.nextSibling as HTMLElement;
                  if (tooltip) tooltip.style.display = 'none';
                }}
              >
                ℹ️
              </span>
              <span
                style={{
                  display: 'none',
                  position: 'absolute',
                  left: '50%',
                  top: '120%',
                  transform: 'translateX(-50%)',
                  background: '#232a36',
                  color: '#fff',
                  padding: '12px 16px',
                  borderRadius: 8,
                  boxShadow: '0 2px 8px rgba(0,0,0,0.25)',
                  fontSize: 15,
                  zIndex: 300,
                  minWidth: 620,
                  maxWidth: 800,
                  textAlign: 'left',
                  pointerEvents: 'none',
                  whiteSpace: 'normal',
                }}
                role="tooltip"
              >
                <strong>What is a Duel?</strong><br/>
                A Duel is a head-to-head competition between exactly two teams.<br/><br/>
                <strong>Scoring:</strong><br/>
                For each Tier (A, B, C):<br/>
                <ul style={{ margin: '6px 0 0 18px', padding: 0 }}>
                  <li>The team with the most <b>Races</b> gets <b>3 points</b> 🏁</li>
                  <li>The team with the highest <b>Accuracy</b> gets <b>1 point</b> 🎯</li>
                  <li>The team with the highest <b>WPM</b> gets <b>1 point</b> ⚡</li>
                  <li>If there is a tie in any category, both teams get the points for that category.</li>
                </ul>
                <br/>
                The team with the most total points wins the Duel!
              </span>
            </span>
          </span>
          <span style={{ display: 'block', fontSize: 14, fontStyle: 'italic', color: '#b0b8c9', marginTop: 2 }}>
            concept credited to Nusakan of ntcomps.com
          </span>
        </div>
        <table className="display-names-table" style={{ background: 'transparent', minWidth: 600, width: '100%', borderCollapse: 'separate', borderSpacing: '0 4px' }}>
          <thead>
            <tr>
              <th style={{ fontSize: 18, fontWeight: 700, padding: '6px 12px', textAlign: 'center' }}>Tier</th>
              {teams.map(team => <th key={team} style={{ fontSize: 20, fontWeight: 800, color: '#ffd700', padding: '6px 16px', textAlign: 'center', letterSpacing: 1 }}>{team}</th>)}
            </tr>
          </thead>
          <tbody>
            {tiers.map(tier => (
              <tr key={tier}>
                <td style={{ fontWeight: 700, fontSize: 16, padding: '8px 12px', textAlign: 'center', background: '#232a36', borderRadius: 8 }}>
                  <span 
                    style={{
                      display: 'inline-block',
                      width: 24,
                      height: 24,
                      borderRadius: '50%',
                      background: tier === 'A' ? '#1976d2' : tier === 'B' ? '#9c27b0' : '#ff88f6',
                      color: '#fff',
                      fontWeight: 700,
                      fontSize: 14,
                      lineHeight: '24px',
                      textAlign: 'center',
                      boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
                    }}
                    title={`Tier ${tier}`}
                  >
                    {tier}
                  </span>
                </td>
                {teams.map(team => (
                  <td key={team} style={{ textAlign: 'center', fontWeight: 700, fontSize: 16, padding: '8px 16px', background: '#232a36', borderRadius: 8 }}>
                    {tierBreakdown[tier]?.races.includes(team) && <span style={{ color: '#ffd700', fontSize: 18, marginRight: 4 }} title="Most Races">🏁+3 </span>}
                    {tierBreakdown[tier]?.accuracy.includes(team) && <span style={{ color: '#4caf50', fontSize: 18, marginRight: 4 }} title="Best Accuracy">🎯+1 </span>}
                    {tierBreakdown[tier]?.wpm.includes(team) && <span style={{ color: '#42a5f5', fontSize: 18 }} title="Fastest WPM">⚡+1</span>}
                  </td>
                ))}
              </tr>
            ))}
            <tr style={{ background: '#232a36' }}>
              <td style={{ fontWeight: 900, fontSize: 18, padding: '10px 12px', textAlign: 'center', borderRadius: 8 }}>Total</td>
              {teams.map(team => (
                <td key={team} style={{ fontWeight: 900, fontSize: 18, color: '#ffd700', padding: '10px 16px', textAlign: 'center', borderRadius: 8 }}>{duelScores[team]} pts</td>
              ))}
            </tr>
          </tbody>
        </table>
        {/* Winner/tie/'is ahead' message always below the table */}
        {(isOngoing || isConcluded) && (
          <div style={{ marginTop: 16, fontSize: 18, fontWeight: 800, color: winner ? '#4caf50' : '#ffb300', textAlign: 'center', letterSpacing: 1 }}>
            {winner
              ? isConcluded
                ? `🏅 ${winner} has won the duel!`
                : end
                  ? `🥇 ${winner} is ahead with ${formatTimeLeft(end.getTime() - now.getTime())} to go!`
                  : `🥇 ${winner} is ahead!`
              : "🤝 It's a tie!"}
          </div>
        )}
        {/* Always show 'Duel starts in...' message below the table if event is not started */}
        {isNotStarted && start && (
          <div style={{ marginTop: 16, fontSize: 18, fontWeight: 800, color: '#ffb300', textAlign: 'center', letterSpacing: 1 }}>
            {`⏳ Duel starts in ${formatTimeLeft(start.getTime() - now.getTime())}!`}
          </div>
        )}
      </div>
      {/* Duel Charts */}
      <div style={{ display: 'flex', gap: 24, width: '100%', justifyContent: 'space-between' }}>
        {metricLabels.map(({ key, label, icon }) => (
          <div key={key} style={{ flex: 1, minWidth: 0, background: 'transparent', borderRadius: 12, boxShadow: '0 1px 4px rgba(0,0,0,0.06)', padding: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: 320 }}>
            <span style={{ fontSize: 22, fontWeight: 700, marginBottom: 0, color: '#fff', letterSpacing: 1 }}>{icon} {label} {icon}</span>
            <div style={{ width: '100%', flex: 1 }}>
              <Bar data={getChartData(key as any)} options={chartOptions(label)} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DuelBox; 