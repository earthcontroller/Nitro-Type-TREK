import { useEffect, useState, useRef, useContext } from 'react';
import { Chart as ChartJS } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { Chart } from 'react-chartjs-2';
import { TeamContext } from '../Shared/TeamContext';

function HourlyRacesChart({ selectedTag }: { selectedTag: string | null }) {
    const [hourlyData, setHourlyData] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [showAllLegends, setShowAllLegends] = useState(false);
    const chartRef = useRef<any>(null);
  
    // Metabase-inspired color palette
    const chartColors = [
      'rgb(88, 121, 193)',    // Blue
      'rgb(96, 181, 142)',    // Green
      'rgb(230, 107, 90)',    // Red
      'rgb(226, 192, 141)',   // Tan
      'rgb(172, 114, 194)',   // Purple
      'rgb(95, 183, 196)',    // Teal
      'rgb(237, 171, 86)',    // Orange
      'rgb(168, 184, 196)',   // Gray
      'rgb(242, 143, 173)',   // Pink
      'rgb(129, 168, 95)',    // Olive
      'rgb(158, 157, 36)',    // Moss
      'rgb(158, 115, 148)',   // Mauve
    ];
  
    // Register plugins only once at component mount
    useEffect(() => {
      ChartJS.register(ChartDataLabels);
      return () => {
        if (chartRef.current) {
          chartRef.current.destroy();
        }
        ChartJS.unregister(ChartDataLabels);
      };
    }, []);
  
    useEffect(() => {
      const fetchHourlyData = async () => {
        if (!selectedTag) return;
        
        setIsLoading(true);
        setError(null);
        
        try {
          const response = await fetch(`/api/hourly-races?tag=${selectedTag}`);
          if (!response.ok) throw new Error('Failed to fetch hourly data');
          
          const data = await response.json();
          setHourlyData(data);
        } catch (err) {
          setError(err instanceof Error ? err.message : 'An error occurred');
        } finally {
          setIsLoading(false);
        }
      };
  
      fetchHourlyData();
    }, [selectedTag]);
  
    if (isLoading) return <div className="stats-loading">Loading chart data...</div>;
    if (error) return <div className="stats-error">Error: {error}</div>;
    if (!hourlyData.length) return null;
  
    // Process data for the chart
    const hours = Array.from(new Set(hourlyData.map(d => d.hour))).sort();
    const racers = Array.from(new Set(hourlyData.map(d => d.racer)));
  
    // Sort racers by total races (descending)
    const racerTotals = racers.map(racer => ({
      racer,
      total: hours.reduce((sum, hour) => {
        const entry = hourlyData.find(d => d.hour === hour && d.racer === racer);
        return sum + (entry ? entry.races : 0);
      }, 0)
    })).sort((a, b) => b.total - a.total);
  
    const sortedRacers = racerTotals.map(r => r.racer);
    const visibleRacers = showAllLegends ? sortedRacers : sortedRacers.slice(0, 20);
  
    const data = {
      labels: hours.map(h => {
        // Convert hour string (UTC) to local time for display
        const d = new Date(h + 'Z'); // Ensure it's parsed as UTC
        return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      }),
      datasets: sortedRacers.map((racer, index) => ({
        label: racer,
        data: hours.map(hour => {
          const entry = hourlyData.find(d => d.hour === hour && d.racer === racer);
          return entry ? entry.races : 0;
        }),
        backgroundColor: chartColors[index % chartColors.length],
        showInLegend: visibleRacers.includes(racer)
      }))
    };
  
    const options = {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 0
      },
      plugins: {
        legend: {
          position: 'right' as const,
          align: 'start' as const,
          maxWidth: 200,
          maxHeight: 360,
          display: true,
          labels: {
            color: 'white',
            boxWidth: 12,
            padding: 8,
            font: {
              size: 11
            },
            filter: (item: any) => {
              const dataset = data.datasets[item.datasetIndex];
              return dataset.showInLegend;
            }
          }
        },
        datalabels: {
          display: (context: any) => {
            const value = context.dataset.data[context.dataIndex];
            return value > 0;
          },
          color: 'white',
          font: {
            weight: 'bold' as const,
            size: 11
          },
          formatter: (value: number) => value.toString()
        }
      },
      scales: {
        x: {
          stacked: true,
          grid: {
            display: false
          },
          ticks: {
            color: 'white',
            maxRotation: 45,
            minRotation: 45
          }
        },
        y: {
          stacked: true,
          beginAtZero: true,
          grid: {
            color: '#333333'
          },
          ticks: {
            color: 'white'
          }
        }
      }
    };
  
    return (
      <div style={{ 
        height: '400px',
        backgroundColor: '#1a1a1a',
        padding: '1rem',
        borderRadius: '8px',
        position: 'relative'
      }}>
        <Chart 
          type="bar"
          data={data}
          options={options}
          ref={chartRef}
        />
        {racers.length > 20 && (
          <button
            onClick={() => setShowAllLegends(!showAllLegends)}
            style={{
              position: 'absolute',
              right: 10,
              bottom: 10,
              background: 'transparent',
              border: '1px solid #666666',
              color: 'white',
              padding: '4px 8px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '11px'
            }}
          >
            {showAllLegends ? 'Show Less' : 'Show More'}
          </button>
        )}
      </div>
    );
  }
  
  function DailyRacesChart({ selectedTag }: { selectedTag: string | null }) {
    const [dailyData, setDailyData] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
  
    useEffect(() => {
      const fetchData = async () => {
        if (!selectedTag) return;
        setIsLoading(true);
        setError(null);
        try {
          const response = await fetch(`/api/daily-races?tag=${selectedTag}`);
          if (!response.ok) throw new Error('Failed to fetch daily data');
          const data = await response.json();
          setDailyData(data);
        } catch (err) {
          setError(err instanceof Error ? err.message : 'An error occurred');
        } finally {
          setIsLoading(false);
        }
      };
      fetchData();
    }, [selectedTag]);
  
    if (isLoading) return <div className="stats-loading">Loading chart data...</div>;
    if (error) return <div className="stats-error">Error: {error}</div>;
    if (!dailyData.length) return null;
  
    const dayMap: Record<string, { total_races: number }> = {};

    dailyData.forEach((row) => {
      const d = new Date(row.date).toLocaleDateString('en-US');
      if (!dayMap[d]) dayMap[d] = { total_races: 0 };
      dayMap[d].total_races += Number(row.total_races) || 0;
    });

    // Convert to array, sort by date descending, limit to 8 days
    const days = Object.keys(dayMap)
      .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
      .slice(0, 8);
  
    const chartData = {
      labels: days, // Already formatted as local date strings
      datasets: [
        {
          label: 'Team Races',
          data: days.map(d => dayMap[d] ? Number(dayMap[d].total_races) : 0),
          backgroundColor: '#1976d2',
          barThickness: 20,
          categoryPercentage: 0.5,
        },
      ],
    };
    const chartHeight = 400;
    const chartOptions = {
      indexAxis: 'y' as const,
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false,
          position: 'top' as const,
          labels: { color: '#fff', font: { size: 14 } },
        },
        title: {
          display: true,
          text: 'Daily Races',
          color: '#fff',
          font: { size: 18, weight: 'bold' as const },
          padding: { bottom: 20 },
        },
        datalabels: {
          color: '#fff',
          anchor: 'end' as const,
          align: 'end' as const,
          offset: 4,
          font: { size: 12 },
          formatter: (value: number) => value.toLocaleString(),
        },
      },
      scales: {
        x: {
          title: { display: true, text: 'Races', color: '#fff', font: { size: 16 } },
          grid: { color: '#333' },
          ticks: { color: '#fff', font: { size: 13 } },
        },
        y: {
          title: { display: true, text: 'Day', color: '#fff', font: { size: 16 } },
          grid: { color: '#333' },
          ticks: { color: '#fff', font: { size: 13 } },
        },
      },
    };
    return (
      <div style={{ width: '50%', height: chartHeight }}>
        <Chart type="bar" data={chartData} options={chartOptions} plugins={[ChartDataLabels]} height={chartHeight} />
      </div>
    );
  }
  
  function WeeklyRacesChart({ selectedTag }: { selectedTag: string | null }) {
    const [weeklyData, setWeeklyData] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
  
    useEffect(() => {
      const fetchData = async () => {
        if (!selectedTag) return;
        setIsLoading(true);
        setError(null);
        try {
          const response = await fetch(`/api/weekly-races?tag=${selectedTag}`);
          if (!response.ok) throw new Error('Failed to fetch weekly data');
          const data = await response.json();
          setWeeklyData(data);
        } catch (err) {
          setError(err instanceof Error ? err.message : 'An error occurred');
        } finally {
          setIsLoading(false);
        }
      };
  
      fetchData();
    }, [selectedTag]);
  
    if (isLoading) return <div className="stats-loading">Loading chart data...</div>;
    if (error) return <div className="stats-error">Error: {error}</div>;
    if (!weeklyData.length) return null;
  
    // Use the same formatting as DailyRacesChart
    const weekMap: Record<string, number> = {};
    weeklyData.forEach(row => {
      // row.date is already formatted as 'Month DD, YYYY' from backend
      if (!weekMap[row.date]) weekMap[row.date] = 0;
      weekMap[row.date] += Number(row.total_races) || 0;
    });
    // Sort by date descending, limit to 8 weeks
    const weeks = Object.keys(weekMap)
      .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
      .slice(0, 8);
  
    const chartData = {
      labels: weeks,
      datasets: [
        {
          label: 'Team Races',
          data: weeks.map(w => weekMap[w]),
          backgroundColor: '#1976d2',
          barThickness: 20,
          categoryPercentage: 0.5,
        },
      ],
    };
    const chartHeight = 400;
    const chartOptions = {
      indexAxis: 'y' as const,
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false,
          position: 'top' as const,
          labels: { color: '#fff', font: { size: 14 } },
        },
        title: {
          display: true,
          text: 'Weekly Races',
          color: '#fff',
          font: { size: 18, weight: 'bold' as const },
          padding: { bottom: 20 },
        },
        datalabels: {
          color: '#fff',
          anchor: 'end' as const,
          align: 'end' as const,
          offset: 4,
          font: { size: 12 },
          formatter: (value: number) => value.toLocaleString(),
        },
      },
      scales: {
        x: {
          title: { display: true, text: 'Races', color: '#fff', font: { size: 16 } },
          grid: { color: '#333' },
          ticks: { color: '#fff', font: { size: 13 } },
        },
        y: {
          title: { display: true, text: 'Week', color: '#fff', font: { size: 16 } },
          grid: { color: '#333' },
          ticks: { color: '#fff', font: { size: 13 } },
        },
      },
    };
    return (
      <div style={{ width: '50%', height: chartHeight }}>
        <Chart type="bar" data={chartData} options={chartOptions} plugins={[ChartDataLabels]} height={chartHeight} />
      </div>
    );
  }
  
  function ActivityViewer() {
    const selectedTag = useContext(TeamContext);
  
    return (
      <div className="activity-viewer">
        <TeamStats selectedTag={selectedTag} />
        <div style={{ marginTop: '1rem' }}>
          <HourlyRacesChart selectedTag={selectedTag} />
        </div>
        <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', width: '100%' }}>
          <DailyRacesChart selectedTag={selectedTag} />
          <WeeklyRacesChart selectedTag={selectedTag} />
        </div>
      </div>
    );
  }
  
  interface TeamStats {
    races: number;
    avg_wpm: number;
    accuracy: number;
    active_members: number;
    top_racer: string;
    top_racer_7d: string;
  }
  
  function TeamStats({ selectedTag }: { selectedTag: string | null }): JSX.Element {
    const [stats, setStats] = useState<TeamStats | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
  
    useEffect(() => {
      if (selectedTag) {
        setLoading(true);
        setError(null);
        
        fetch(`/api/team-stats?tag=${encodeURIComponent(selectedTag)}`)
          .then(response => {
            if (!response.ok) {
              throw new Error('Failed to fetch team stats');
            }
            return response.json();
          })
          .then(data => {
            setStats(data);
            setLoading(false);
          })
          .catch(error => {
            console.error('Error fetching team stats:', error);
            setError('Failed to load team stats. Please try again later.');
            setLoading(false);
          });
      } else {
        setStats(null);
      }
    }, [selectedTag]);
  
    if (!selectedTag) {
      return <div></div>;
    }
  
    if (loading) {
      return <div className="stats-loading">Loading team stats...</div>;
    }
  
    if (error) {
      return <div className="stats-error">{error}</div>;
    }
  
    if (!stats) {
      return <div></div>;
    }
  
    return (
      <div className="team-stats">
        <div className="stat-card">
          <div className="stat-title">Last 24 Hours: Races</div>
          <div className="stat-value">{stats.races.toLocaleString()}</div>
        </div>
        <div className="stat-card">
          <div className="stat-title">Last 24 Hours: Avg WPM</div>
          <div className="stat-value">{stats.avg_wpm}</div>
        </div>
        <div className="stat-card">
          <div className="stat-title">Last 24 Hours: Accuracy</div>
          <div className="stat-value">{stats.accuracy}%</div>
        </div>
        <div className="stat-card">
          <div className="stat-title">Last 24 Hours: Active Members</div>
          <div className="stat-value">{stats.active_members}</div>
        </div>
        <div className="stat-card">
          <div className="stat-title">Last 24 Hours: Top Racer</div>
          <div className="stat-value">{stats.top_racer}</div>
        </div>
        <div className="stat-card">
          <div className="stat-title">Last 7 Days: Top Racer</div>
          <div className="stat-value">{stats.top_racer_7d}</div>
        </div>
      </div>
    );
  }
  

export default ActivityViewer; 