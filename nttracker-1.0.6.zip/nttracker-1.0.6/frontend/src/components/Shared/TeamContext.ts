import { createContext } from 'react';
export const TeamContext = createContext<string | null>(null); 