import * as XLSX from 'xlsx';

export type HyperlinkConfig = {
  [columnName: string]: (row: any) => string | undefined;
};

/**
 * Export data to CSV file.
 * @param data Array of row objects
 * @param headers Array of column keys (order matters)
 * @param filename Output filename
 */
export function exportTableToCSV(data: any[], headers: string[], filename: string) {
  const csvRows = [headers.join(',')];
  data.forEach(row => {
    const values = headers.map(h => {
      let v = row[h] ?? '';
      if (typeof v === 'string') v = '"' + v.replace(/"/g, '""') + '"';
      return v;
    });
    csvRows.push(values.join(','));
  });
  const csvContent = csvRows.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}

/**
 * Export data to Excel file, with optional hyperlinks per column.
 * @param data Array of row objects
 * @param headers Array of column keys (order matters)
 * @param filename Output filename
 * @param hyperlinkConfig Optional mapping of column name to URL builder function
 */
export function exportTableToExcel(
  data: any[],
  headers: string[],
  filename: string,
  hyperlinkConfig: HyperlinkConfig = {}
) {
  const worksheetData = [headers, ...data.map(row => headers.map(h => row[h] ?? ''))];
  const ws = XLSX.utils.aoa_to_sheet(worksheetData);

  // Add hyperlinks if configured
  Object.entries(hyperlinkConfig).forEach(([col, getUrl]) => {
    const colIdx = headers.indexOf(col);
    if (colIdx === -1) return;
    for (let i = 0; i < data.length; i++) {
      const url = getUrl(data[i]);
      if (url) {
        const cellRef = XLSX.utils.encode_cell({ c: colIdx, r: i + 1 }); // +1 for header row
        if (ws[cellRef]) ws[cellRef].l = { Target: url };
      }
    }
  });

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  XLSX.writeFile(wb, filename);
}

/**
 * Example usage:
 *
 * import { exportTableToExcel, exportTableToCSV, HyperlinkConfig } from './Shared/exportUtils';
 *
 * const hyperlinkConfig: HyperlinkConfig = {
 *   Username: row => `https://www.nitrotype.com/racer/${row.Username}`,
 *   CurrentDisplayName: row => `https://www.nitrotype.com/racer/${row.Username}`,
 * };
 *
 * exportTableToExcel(data, headers, filename, hyperlinkConfig);
 * exportTableToCSV(data, headers, filename);
 */ 