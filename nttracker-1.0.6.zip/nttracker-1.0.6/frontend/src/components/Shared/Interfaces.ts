export interface DisplayName {
  CurrentDisplayName: string;
  Username: string;
  Tag: string;
  squad: string;  // Global squad assignment
  SquadName: string;  // Team-specific custom nickname
  Joined: string;
  TeamRaces: number;
  LifetimeRaces: number;
  AvgWPM: number;
  TopWPM: number;
  bot?: number;
  Tier: string;  // A, B, or C based on avgSpeed vs team thresholds
} 