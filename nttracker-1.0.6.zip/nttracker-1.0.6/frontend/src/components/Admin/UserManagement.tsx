import React, { useEffect, useState } from 'react';

interface User {
  id: number;
  username: string;
  role: 'admin' | 'teamadmin';
  userID?: number;
  created_at: string;
  last_login: string | null;
}

interface MemberData {
  userID: number;
  username: string;
}

const roles = ['admin', 'teamadmin'];

const AdminSecondaryTabs: React.FC<{ activeTab: string, onTabChange: (tab: string) => void }> = ({ activeTab, onTabChange }) => (
  <div className="tabs" style={{ marginBottom: 24 }}>
    <button className={`tab${activeTab === 'usermgmt' ? ' active' : ''}`} onClick={() => onTabChange('usermgmt')}>User Management</button>
    <button className={`tab${activeTab === 'botflags' ? ' active' : ''}`} onClick={() => onTabChange('botflags')}>Bot Flags</button>
  </div>
);

const UserManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'usermgmt' | 'botflags'>('usermgmt');
  const [users, setUsers] = useState<User[]>([]);
  const [members, setMembers] = useState<MemberData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [modal, setModal] = useState<'add' | 'edit' | 'password' | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [form, setForm] = useState({ username: '', password: '', role: 'teamadmin', userID: '' });
  const [formError, setFormError] = useState('');

  // Bot Flags state
  const [flaggedUsers, setFlaggedUsers] = useState<any[]>([]);
  const [botSearch, setBotSearch] = useState('');
  const [botSearchResult, setBotSearchResult] = useState<any | null>(null);
  const [botSearchLoading, setBotSearchLoading] = useState(false);
  const [botSearchError, setBotSearchError] = useState('');

  const fetchUsers = () => {
    setLoading(true);
    fetch('/api/users')
      .then(res => res.json())
      .then(data => { setUsers(data); setLoading(false); })
      .catch(() => { setError('Failed to fetch users'); setLoading(false); });
  };

  const fetchMembers = () => {
    fetch('/api/member-data-latest')
      .then(res => res.json())
      .then(data => { setMembers(data); })
      .catch(() => { setError('Failed to fetch members'); });
  };

  // Fetch flagged users for Bot Flags tab
  const fetchFlaggedUsers = () => {
    fetch('/api/bot-flagged-users')
      .then(res => res.json())
      .then(data => setFlaggedUsers(data))
      .catch(() => setFlaggedUsers([]));
  };

  useEffect(() => {
    fetchUsers();
    fetchMembers();
  }, []);

  useEffect(() => {
    if (activeTab === 'botflags') fetchFlaggedUsers();
  }, [activeTab]);

  // Bot flag actions
  const clearBotFlag = (username: string) => {
    fetch('/api/set-bot-flag', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, flag: null })
    })
      .then(res => res.json())
      .then(() => fetchFlaggedUsers());
  };
  const setBotFlag = (username: string) => {
    fetch('/api/set-bot-flag', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, flag: 1 })
    })
      .then(res => res.json())
      .then(() => fetchFlaggedUsers());
  };

  // Search for user by displayName, username, or userID (partial, case-insensitive)
  const handleBotSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setBotSearchLoading(true);
    setBotSearchError('');
    setBotSearchResult(null);
    fetch(`/api/search-users?query=${encodeURIComponent(botSearch)}`)
      .then(res => res.json())
      .then(data => {
        if (data.error) setBotSearchError(data.error);
        else setBotSearchResult(data);
        setBotSearchLoading(false);
      })
      .catch(() => {
        setBotSearchError('Failed to fetch user');
        setBotSearchLoading(false);
      });
  };

  const openAdd = () => {
    setForm({ username: '', password: '', role: 'teamadmin', userID: '' });
    setModal('add');
    setFormError('');
  };
  const openEdit = (user: User) => {
    setSelectedUser(user);
    setForm({ username: user.username, password: '', role: user.role, userID: user.userID ? user.userID.toString() : '' });
    setModal('edit');
    setFormError('');
  };
  const openPassword = (user: User) => {
    setSelectedUser(user);
    setForm({ username: user.username, password: '', role: user.role, userID: user.userID ? user.userID.toString() : '' });
    setModal('password');
    setFormError('');
  };
  const closeModal = () => { setModal(null); setSelectedUser(null); setFormError(''); };

  const handleAdd = () => {
    if (!form.username || !form.password) { setFormError('Username and password required'); return; }
    fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) { closeModal(); fetchUsers(); }
        else setFormError(data.error || 'Add failed');
      })
      .catch(() => setFormError('Add failed'));
  };
  const handleEdit = () => {
    if (!selectedUser) return;
    if (!form.username) { setFormError('Username required'); return; }
    fetch(`/api/users/${selectedUser.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: form.username, role: form.role, userID: form.userID })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) { closeModal(); fetchUsers(); }
        else setFormError(data.error || 'Edit failed');
      })
      .catch(() => setFormError('Edit failed'));
  };
  const handlePassword = () => {
    if (!selectedUser) return;
    if (!form.password) { setFormError('Password required'); return; }
    fetch(`/api/users/${selectedUser.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: form.password })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) { closeModal(); fetchUsers(); }
        else setFormError(data.error || 'Password change failed');
      })
      .catch(() => setFormError('Password change failed'));
  };
  const handleDelete = (user: User) => {
    if (!window.confirm(`Delete user ${user.username}?`)) return;
    fetch(`/api/users/${user.id}`, { method: 'DELETE' })
      .then(res => res.json())
      .then(data => { if (data.success) fetchUsers(); else alert(data.error || 'Delete failed'); })
      .catch(() => alert('Delete failed'));
  };

  return (
    <div style={{ maxWidth: 1200, margin: '40px auto', color: '#fff' }}>
      <AdminSecondaryTabs activeTab={activeTab} onTabChange={tab => setActiveTab(tab as 'usermgmt' | 'botflags')} />
      {activeTab === 'usermgmt' && (
        <div style={{ background: '#181c24', borderRadius: 8, padding: 24, minHeight: 300, boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
          {loading ? <div>Loading users...</div> : error ? <div style={{ color: '#e53935' }}>{error}</div> : (
            <>
              <button onClick={openAdd} style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 8, padding: '8px 20px', fontWeight: 600, fontSize: 16, marginBottom: 18, cursor: 'pointer' }}>Add User</button>
              <table className="display-names-table">
                <thead>
                  <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>User ID</th>
                    <th>Created</th>
                    <th>Last Login</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(user => (
                    <tr key={user.id}>
                      <td>{user.username}</td>
                      <td>{user.role}</td>
                      <td>{user.userID ? (() => {
                        const member = members.find(m => m.userID === user.userID);
                        if (!member) return user.userID;
                        return (
                          <a
                            href={`/racers?username=${encodeURIComponent(member.username)}&subtab=batch`}
                            style={{ color: '#1976d2', textDecoration: 'underline', cursor: 'pointer' }}
                            title={`View ${member.username} in Racers tab`}
                          >
                            {user.userID}
                          </a>
                        );
                      })() : ''}</td>
                      <td>{user.created_at ? new Date(user.created_at).toLocaleString() : ''}</td>
                      <td>{user.last_login ? new Date(user.last_login).toLocaleString() : ''}</td>
                      <td>
                        <div style={{ display: 'flex', gap: 8 }}>
                          <button
                            onClick={() => openEdit(user)}
                            title="Edit"
                            style={{ background: '#1976d2', border: 'none', borderRadius: '50%', width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                          >
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M3 14.25V17h2.75l8.13-8.13-2.75-2.75L3 14.25zM17.71 6.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" fill="#fff"/>
                            </svg>
                          </button>
                          <button
                            onClick={() => openPassword(user)}
                            title="Change Password"
                            style={{ background: '#ffb300', border: 'none', borderRadius: '50%', width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                          >
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <circle cx="10" cy="13" r="5" fill="#fff" fillOpacity="0.15"/>
                              <rect x="6" y="11" width="8" height="5" rx="2" fill="#fff"/>
                              <rect x="8.5" y="13" width="3" height="2" rx="1" fill="#ffb300"/>
                              <path d="M10 11V9.5a2 2 0 1 1 4 0V11" stroke="#fff" strokeWidth="1.2" strokeLinecap="round"/>
                            </svg>
                          </button>
                          <button
                            onClick={() => handleDelete(user)}
                            title="Delete"
                            style={{ background: '#e53935', border: 'none', borderRadius: '50%', width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                          >
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M6 7v8a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V7" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                              <path d="M4 7h12" stroke="#fff" strokeWidth="1.5" strokeLinecap="round"/>
                              <path d="M8 7V5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2" stroke="#fff" strokeWidth="1.5" strokeLinecap="round"/>
                            </svg>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </div>
      )}
      {activeTab === 'botflags' && (
        <div style={{ background: '#181c24', borderRadius: 8, padding: 24, minHeight: 300, boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
          <h3>Set Bot Flags</h3>
          <form onSubmit={handleBotSearch} style={{ marginBottom: 24, display: 'flex', gap: 12, alignItems: 'center' }}>
            <input
              type="text"
              placeholder="Search display name, username, or userID..."
              value={botSearch}
              onChange={e => setBotSearch(e.target.value)}
              style={{ padding: 8, borderRadius: 6, border: '1px solid #444', fontSize: 16, width: 320 }}
            />
            <button type="submit" style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 8, padding: '8px 20px', fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>Search</button>
          </form>
          {botSearchLoading && <div>Searching...</div>}
          {botSearchError && <div style={{ color: '#e53935' }}>{botSearchError}</div>}
          {Array.isArray(botSearchResult) && botSearchResult.length > 0 && (
            <>
              <div style={{ fontWeight: 600, marginBottom: 8 }}>Search Results</div>
              <table className="display-names-table" style={{ marginBottom: 32 }}>
                <thead>
                  <tr>
                    <th>Display Name</th>
                    <th>Username</th>
                    <th>UserID</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {botSearchResult.map((user: any) => (
                    <tr key={user.UserID}>
                      <td>{user.DisplayName}</td>
                      <td>{user.Username}</td>
                      <td>{user.UserID}</td>
                      <td>
                        {user.bot === 1 ? (
                          <span title="Already flagged" style={{ fontSize: 22 }}>🤖</span>
                        ) : (
                          <button
                            title="Set bot flag"
                            onClick={() => { setBotFlag(user.Username); fetchFlaggedUsers(); }}
                            style={{ background: '#1976d2', border: 'none', borderRadius: '50%', width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                          >
                            <span style={{ fontSize: 22 }}>🤖</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
          {Array.isArray(botSearchResult) && botSearchResult.length === 0 && (
            <div style={{ color: '#aaa', marginBottom: 24 }}>No users found.</div>
          )}
          <div style={{ fontWeight: 600, marginBottom: 8 }}>Currently Flagged Users</div>
          <table className="display-names-table">
            <thead>
              <tr>
                <th>Display Name</th>
                <th>Username</th>
                <th>UserID</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {flaggedUsers.map(user => (
                <tr key={user.UserID}>
                  <td>{user.DisplayName}</td>
                  <td>{user.Username}</td>
                  <td>{user.UserID}</td>
                  <td>
                    <button
                      title="Clear bot flag"
                      onClick={() => clearBotFlag(user.Username)}
                      style={{ background: '#e53935', border: 'none', borderRadius: '50%', width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                    >
                      {/* Circle with X icon */}
                      <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="10" cy="10" r="9" stroke="#fff" strokeWidth="2" fill="none" />
                        <path d="M6 6l8 8M14 6l-8 8" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                    </button>
                  </td>
                </tr>
              ))}
              {flaggedUsers.length === 0 && (
                <tr><td colSpan={4} style={{ textAlign: 'center', color: '#aaa' }}>No flagged users found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
      {/* Add/Edit/Password Modal */}
      {modal && (
        <div className="modal-overlay" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: '#000a', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="modal-content" style={{ background: '#222', padding: 32, borderRadius: 12, minWidth: 320, boxShadow: '0 4px 24px #0008', color: '#fff', position: 'relative' }}>
            <button onClick={closeModal} style={{ position: 'absolute', top: 12, right: 12, background: 'none', border: 'none', color: '#fff', fontSize: 22, cursor: 'pointer' }}>&times;</button>
            <h3 style={{ marginBottom: 18 }}>{modal === 'add' ? 'Add User' : modal === 'edit' ? 'Edit User' : 'Change Password'}</h3>
            <form onSubmit={e => { e.preventDefault(); if (modal === 'add') handleAdd(); else if (modal === 'edit') handleEdit(); else if (modal === 'password') handlePassword(); }}>
              {(modal === 'add' || modal === 'edit') && (
                <>
                  <div style={{ marginBottom: 16 }}>
                    <input type="text" placeholder="Username" value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value }))} style={{ width: '100%', padding: 10, borderRadius: 6, border: '1px solid #444', fontSize: 16 }} autoFocus />
                  </div>
                  {modal === 'add' && (
                    <div style={{ marginBottom: 16 }}>
                      <input type="password" placeholder="Password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} style={{ width: '100%', padding: 10, borderRadius: 6, border: '1px solid #444', fontSize: 16 }} />
                    </div>
                  )}
                  <div style={{ marginBottom: 16 }}>
                    <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value as 'admin' | 'teamadmin' }))} style={{ width: '100%', padding: 10, borderRadius: 6, border: '1px solid #444', fontSize: 16 }}>
                      {roles.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                  <div style={{ marginBottom: 16 }}>
                    <select value={form.userID} onChange={e => setForm(f => ({ ...f, userID: e.target.value }))} style={{ width: '100%', padding: 10, borderRadius: 6, border: '1px solid #444', fontSize: 16 }}>
                      <option value="">Select User ID</option>
                      {members.map((member) => (
                        <option key={member.userID} value={member.userID}>
                          {member.username} ({member.userID})
                        </option>
                      ))}
                    </select>
                  </div>
                </>
              )}
              {modal === 'password' && (
                <div style={{ marginBottom: 16 }}>
                  <input type="password" placeholder="New Password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} style={{ width: '100%', padding: 10, borderRadius: 6, border: '1px solid #444', fontSize: 16 }} autoFocus />
                </div>
              )}
              {formError && <div style={{ color: '#e53935', marginBottom: 12 }}>{formError}</div>}
              <button type="submit" style={{ width: '100%', background: '#1976d2', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 0', fontWeight: 600, fontSize: 17, cursor: 'pointer' }}>{modal === 'add' ? 'Add' : modal === 'edit' ? 'Save' : 'Change Password'}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagement; 