import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Chart } from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import Slider from '@mui/material/Slider';
import { Bar } from 'react-chartjs-2';

function BatchInspector({ selectedFromNav = '', setSelectedFromNav, subtabFromNav = 'batch', setSubtabFromNav }: { selectedFromNav?: string, setSelectedFromNav?: (s: string) => void, subtabFromNav?: 'batch' | 'daily' | 'weekly', setSubtabFromNav?: (s: 'batch' | 'daily' | 'weekly') => void }) {
  const [usernames, setUsernames] = useState<string[]>([]);
  const [filter, setFilter] = useState('');
  const [selected, setSelected] = useState('');
  const [racerInfo, setRacerInfo] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [batches, setBatches] = useState<any[]>([]);
  const [batchesLoading, setBatchesLoading] = useState(false);
  const [batchesError, setBatchesError] = useState<string | null>(null);
  const [batchPage, setBatchPage] = useState(1);
  const BATCHES_PER_PAGE = 50;
  const [sliderRange, setSliderRange] = useState<[number, number] | null>(null);
  const [activeSubtab, setActiveSubtab] = useState<'batch' | 'daily' | 'weekly'>('batch');
  const [searchParams, setSearchParams] = useSearchParams();
  const username = searchParams.get('username');
  const subtab = searchParams.get('subtab') || 'batch';

  useEffect(() => {
    if (username && username !== selected) {
      setSelected(username);
      setBatchPage(1);
    }
  }, [username]);

  useEffect(() => {
    if (subtab && ['batch', 'daily', 'weekly'].includes(subtab)) {
      setActiveSubtab(subtab as 'batch' | 'daily' | 'weekly');
    }
  }, [subtab]);

  useEffect(() => {
    if (selectedFromNav && selectedFromNav !== selected) {
      setSearchParams(prev => {
        const newParams = new URLSearchParams(prev);
        newParams.set('username', selectedFromNav);
        newParams.set('subtab', subtabFromNav);
        return newParams;
      });
      if (setSelectedFromNav) setSelectedFromNav(''); // Clear after use
    }
  }, [selectedFromNav]);

  useEffect(() => {
    if (subtabFromNav && subtabFromNav !== activeSubtab) {
      setSearchParams(prev => {
        const newParams = new URLSearchParams(prev);
        newParams.set('subtab', subtabFromNav);
        return newParams;
      });
      if (setSubtabFromNav) setSubtabFromNav('batch'); // Reset to default after use
    }
  }, [subtabFromNav]);

  useEffect(() => {
    fetch('/api/all-usernames')
      .then(res => res.json())
      .then(data => setUsernames(data.usernames || []));
  }, []);

  // Fetch racer info when selected changes
  useEffect(() => {
    if (!selected) {
      setRacerInfo(null);
      setError(null);
      setBatches([]);
      setBatchesError(null);
      setBatchPage(1);
      return;
    }
    setLoading(true);
    setError(null);
    fetch(`/api/racer-info?username=${encodeURIComponent(selected)}`)
      .then(res => res.json())
      .then(data => {
        if (data.error) {
          setError(data.error);
          setRacerInfo(null);
        } else {
          setRacerInfo(data);
        }
        setLoading(false);
      })
      .catch(() => {
        setError('Failed to fetch racer info');
        setRacerInfo(null);
        setLoading(false);
      });
  }, [selected]);

  // Fetch batch data when selected changes
  useEffect(() => {
    if (!selected) {
      setBatches([]);
      setBatchesError(null);
      setBatchPage(1);
      return;
    }
    setBatchesLoading(true);
    setBatchesError(null);
    fetch(`/api/racer-batches?username=${encodeURIComponent(selected)}`)
      .then(res => res.json())
      .then(data => {
        if (data.error) {
          setBatchesError(data.error);
          setBatches([]);
        } else {
          setBatches(data.batches || []);
        }
        setBatchPage(1);
        setBatchesLoading(false);
      })
      .catch(() => {
        setBatchesError('Failed to fetch batch data');
        setBatches([]);
        setBatchPage(1);
        setBatchesLoading(false);
      });
  }, [selected]);

  // Case-sensitive filter
  const filtered = usernames.filter(u => u.includes(filter));

  // Compute slider min/max from batches
  const batchTimes = batches.map(row => new Date(row.batchEndTime).getTime()).sort((a, b) => a - b);
  const sliderMin = batchTimes.length ? batchTimes[0] : 0;
  const sliderMax = batchTimes.length ? batchTimes[batchTimes.length - 1] : 0;
  // If sliderRange is null, show all
  const [sliderStart, sliderEnd] = sliderRange || [sliderMin, sliderMax];

  // Filtered batches for chart and table
  const filteredBatches = batches.filter(row => {
    const t = new Date(row.batchEndTime).getTime();
    return t >= sliderStart && t <= sliderEnd;
  });
  // Paginate filteredBatches for table
  const totalPages = Math.ceil(filteredBatches.length / BATCHES_PER_PAGE);
  const pagedBatches = filteredBatches.slice((batchPage - 1) * BATCHES_PER_PAGE, batchPage * BATCHES_PER_PAGE);

  // Chart data
  const sortedFilteredBatches = [...filteredBatches].sort(
    (a, b) => new Date(a.batchEndTime).getTime() - new Date(b.batchEndTime).getTime()
  );
  const chartLabels = sortedFilteredBatches.map(row => {
    const d = new Date(row.batchEndTime);
    // Format: YYYY-MM-DD HH:mm (no seconds)
    return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  });
  const chartWPM = sortedFilteredBatches.map(row => row.WPM !== null && row.WPM !== undefined ? Number(row.WPM) : null);
  const chartRaces = sortedFilteredBatches.map(row => row.sum);
  const chartAccuracy = sortedFilteredBatches.map(row => row.Accuracy !== null && row.Accuracy !== undefined ? Number(row.Accuracy) * 100 : null);

  // Dynamic left Y-axis max (WPM)
  const maxWPM = Math.max(...chartWPM.filter((v): v is number => v !== null && !isNaN(v)));
  const yMax = Math.ceil((maxWPM || 100) / 10) * 10;

  const chartData: any = {
    labels: chartLabels,
    datasets: [
      {
        type: 'line' as const,
        label: 'WPM',
        data: chartWPM,
        borderColor: '#1976d2',
        backgroundColor: 'rgba(25, 118, 210, 0.2)',
        yAxisID: 'y',
        tension: 0.2,
        pointRadius: 2,
        borderWidth: 2,
      },
      {
        type: 'bar' as const,
        label: 'Races',
        data: chartRaces,
        backgroundColor: 'rgba(255, 193, 7, 0.7)',
        borderColor: '#ffc107',
        yAxisID: 'y',
        borderWidth: 1,
        barPercentage: 0.8,
        categoryPercentage: 0.8,
      },
      {
        type: 'line' as const,
        label: 'Accuracy',
        data: chartAccuracy,
        borderColor: '#43a047',
        backgroundColor: 'rgba(67, 160, 71, 0.2)',
        yAxisID: 'y2',
        tension: 0.2,
        pointRadius: 2,
        borderWidth: 2,
      },
    ],
  };

  const chartOptions: any = {
    responsive: true,
    plugins: {
      legend: { position: 'top' as const },
      datalabels: { display: false },
      tooltip: { mode: 'index', intersect: false },
    },
    scales: {
      x: {
        title: { display: true, text: 'Batch End Time' },
        ticks: {
          maxRotation: 45,
          minRotation: 45,
          autoSkip: false, // Show all labels
          maxTicksLimit: 30, // Increase label density
          callback: function(this: any, index: number): string {
            // Show more labels, but still avoid total clutter
            const step = Math.ceil(chartLabels.length / 30);
            return index % step === 0 ? chartLabels[index] : '';
          },
        },
      },
      y: {
        title: { display: true, text: 'WPM / Races' },
        beginAtZero: true,
        max: yMax,
      },
      y2: {
        title: { display: true, text: 'Accuracy (%)' },
        position: 'right',
        min: 70,
        max: 100,
        grid: { drawOnChartArea: false },
        ticks: { callback: (v: number) => v + '%' },
      },
    },
    interaction: { mode: 'index' as const, intersect: false },
    maintainAspectRatio: false,
  };

  return (
    <div className="container" style={{ padding: 24 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div className="tag-selector" style={{ maxWidth: 400 }}>
          <label className="select-label" htmlFor="username-filter">Username</label>
          <input
            id="username-filter"
            type="text"
            placeholder="Type to filter usernames..."
            value={filter}
            onChange={e => setFilter(e.target.value)}
            style={{ marginBottom: 8, width: '100%', padding: '0.75rem', borderRadius: 4, border: '1px solid var(--border-color)', background: 'var(--bg-primary)', color: 'var(--text-primary)' }}
          />
          <select
            value={selected}
            onChange={e => {
              setSelected(e.target.value);
              setSearchParams(prev => {
                const newParams = new URLSearchParams(prev);
                newParams.set('username', e.target.value);
                newParams.set('subtab', activeSubtab);
                return newParams;
              });
            }}
            className="tag-dropdown"
            style={{ width: '100%' }}
          >
            <option value="">Select username</option>
            {filtered.map(u => (
              <option key={u} value={u}>{u}</option>
            ))}
          </select>
        </div>
        {/* Slider top right of page */}
        {batches.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, marginLeft: 24, minWidth: 260 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', justifyContent: 'flex-end' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Date Range:</span>
              <Slider
                min={sliderMin}
                max={sliderMax}
                value={[sliderStart, sliderEnd]}
                step={60 * 1000}
                onChange={(_, newValue) => {
                  if (Array.isArray(newValue)) setSliderRange([newValue[0], newValue[1]]);
                }}
                valueLabelDisplay="auto"
                getAriaLabel={() => 'Date range'}
                valueLabelFormat={val => new Date(val).toLocaleString([], { year: 'numeric', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                sx={{ width: 340 }}
              />
            </div>
            <span style={{ color: 'var(--text-secondary)', fontSize: 13, textAlign: 'right', width: 340, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {sliderStart !== sliderMin || sliderEnd !== sliderMax
                ? `${new Date(sliderStart).toLocaleString([], { year: 'numeric', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })} - ${new Date(sliderEnd).toLocaleString([], { year: 'numeric', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`
                : 'All'}
            </span>
          </div>
        )}
      </div>
      {racerInfo && (
        <div
          className="racer-info-banner"
          style={{
            width: '100%',
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            background: 'var(--bg-secondary)',
            borderRadius: 8,
            border: '1px solid var(--border-color)',
            padding: '8px 20px',
            margin: '0 0 24px 0',
            minHeight: 0,
            boxSizing: 'border-box',
            fontSize: '1em',
            gap: '24px'
          }}
        >
          <span style={{ fontWeight: 700, fontSize: '1.2em', marginRight: 24 }}>
            {racerInfo.displayName || racerInfo.username}
            {racerInfo.bot === 1 && <span title="Bot" style={{ marginLeft: 4 }}>🤖</span>}
          </span>
          <span><strong>Username:</strong> {racerInfo.username}</span>
          <span><strong>UserID:</strong> {racerInfo.userID}</span>
          <span><strong>Team Tag:</strong> {racerInfo.teamTag}</span>
          <span><strong>Role:</strong> {racerInfo.role}</span>
          <span><strong>Lifetime Races:</strong> {racerInfo.racesPlayed}</span>
          <span><strong>Team Races:</strong> {racerInfo.played}</span>
          <span><strong>Avg WPM:</strong> {racerInfo.avgSpeed}</span>
          <span><strong>Top WPM:</strong> {racerInfo.highestSpeed}</span>
          <span><strong>Joined:</strong>{" "}
          {racerInfo.joinStamp
            ? new Date(racerInfo.joinStamp).toLocaleString(undefined, {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
              hour: 'numeric',
              minute: '2-digit',
              hour12: true
            })
          : ''}
        </span>
        </div>
      )}
      {/* Second-level tab bar for Batch Inspector, Daily Races, Weekly Races */}
      <div style={{ display: 'flex', gap: 0, marginBottom: 16, borderBottom: '1px solid #1565c0', marginTop: 16 }}>
        <button
          className={`tab${activeSubtab === 'batch' ? ' active' : ''}`}
          style={{
            background: activeSubtab === 'batch' ? '#1976d2' : 'transparent',
            color: activeSubtab === 'batch' ? '#fff' : '#1976d2',
            fontWeight: 600,
            fontSize: 16,
            cursor: 'pointer',
            padding: '8px 20px',
            border: 'none',
            borderRadius: '8px 8px 0 0',
            outline: 'none',
            transition: 'background 0.2s, color 0.2s',
            borderBottom: activeSubtab === 'batch' ? '2px solid #1976d2' : 'none',
          }}
          onClick={() => {
            setActiveSubtab('batch');
            setSearchParams(prev => {
              const newParams = new URLSearchParams(prev);
              newParams.set('subtab', 'batch');
              return newParams;
            });
          }}
        >
          Batch Inspector
        </button>
        <button
          className={`tab${activeSubtab === 'daily' ? ' active' : ''}`}
          style={{
            background: activeSubtab === 'daily' ? '#1976d2' : 'transparent',
            color: activeSubtab === 'daily' ? '#fff' : '#1976d2',
            fontWeight: 600,
            fontSize: 16,
            cursor: 'pointer',
            padding: '8px 20px',
            border: 'none',
            borderRadius: '8px 8px 0 0',
            outline: 'none',
            transition: 'background 0.2s, color 0.2s',
            borderBottom: activeSubtab === 'daily' ? '2px solid #1976d2' : 'none',
          }}
          onClick={() => {
            setActiveSubtab('daily');
            setSearchParams(prev => {
              const newParams = new URLSearchParams(prev);
              newParams.set('subtab', 'daily');
              return newParams;
            });
          }}
        >
          Daily Races
        </button>
        <button
          className={`tab${activeSubtab === 'weekly' ? ' active' : ''}`}
          style={{
            background: activeSubtab === 'weekly' ? '#1976d2' : 'transparent',
            color: activeSubtab === 'weekly' ? '#fff' : '#1976d2',
            fontWeight: 600,
            fontSize: 16,
            cursor: 'pointer',
            padding: '8px 20px',
            border: 'none',
            borderRadius: '8px 8px 0 0',
            outline: 'none',
            transition: 'background 0.2s, color 0.2s',
            borderBottom: activeSubtab === 'weekly' ? '2px solid #1976d2' : 'none',
          }}
          onClick={() => {
            setActiveSubtab('weekly');
            setSearchParams(prev => {
              const newParams = new URLSearchParams(prev);
              newParams.set('subtab', 'weekly');
              return newParams;
            });
          }}
        >
          Weekly Races
        </button>
      </div>
      {/* Tab content */}
      {activeSubtab === 'batch' && filteredBatches.length > 0 && (
        <>
          <div style={{ width: '100%', marginBottom: 24, minHeight: 600 }}>
            <div style={{ width: '100%', height: 600 }}>
              <Chart type="bar" data={chartData} options={chartOptions} plugins={[ChartDataLabels]} />
            </div>
          </div>
          {/* Racer batch table only for Batch Inspector tab */}
          {selected && (
            <div style={{ marginTop: 16 }}>
              {batchesLoading ? (
                <div className="loading-message">Loading batch data...</div>
              ) : batchesError ? (
                <div className="error-message">{batchesError}</div>
              ) : (
                <>
                  <table className="display-names-table">
                    <thead>
                      <tr>
                        <th>Batch End Time</th>
                        <th>Display Name</th>
                        <th>Team Tag</th>
                        <th>Races</th>
                        <th>WPM</th>
                        <th>Accuracy</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pagedBatches.map((row, idx) => (
                        <tr key={idx}>
                          <td>
                            {new Date(row.batchEndTime).toLocaleString(undefined, {
                              year: 'numeric',
                              month: 'numeric',
                              day: 'numeric',
                              hour: 'numeric',
                              minute: '2-digit',
                              hour12: true
                            })}
                          </td>
                          <td>{row.CurrentDisplayName}</td>
                          <td>{row.teamTag}</td>
                          <td>{row.sum}</td>
                          <td>{row.WPM !== null && row.WPM !== undefined ? Number(row.WPM).toFixed(1) : ''}</td>
                          <td>{row.Accuracy !== null && row.Accuracy !== undefined ? (Number(row.Accuracy) * 100).toFixed(2) + '%' : ''}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {totalPages > 1 && (
                    <div style={{
                      display: 'flex',
                      justifyContent: 'flex-end',
                      alignItems: 'center',
                      gap: 16,
                      marginTop: 12,
                      fontSize: '1em'
                    }}>
                      <span>
                        Rows {((batchPage - 1) * BATCHES_PER_PAGE) + 1}
                        -
                        {Math.min(batchPage * BATCHES_PER_PAGE, batches.length)}
                        {' '}of {batches.length}
                      </span>
                      <button
                        onClick={() => setBatchPage(p => Math.max(1, p - 1))}
                        disabled={batchPage === 1}
                        style={{ fontSize: '1.2em', background: 'none', border: 'none', color: batchPage === 1 ? '#888' : '#1976d2', cursor: batchPage === 1 ? 'default' : 'pointer' }}
                        aria-label="Previous page"
                      >
                        &#60;
                      </button>
                      <button
                        onClick={() => setBatchPage(p => Math.min(totalPages, p + 1))}
                        disabled={batchPage === totalPages}
                        style={{ fontSize: '1.2em', background: 'none', border: 'none', color: batchPage === totalPages ? '#888' : '#1976d2', cursor: batchPage === totalPages ? 'default' : 'pointer' }}
                        aria-label="Next page"
                      >
                        &#62;
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </>
      )}
      {activeSubtab === 'daily' && (
        <DailyRacesBarChart filteredBatches={filteredBatches} />
      )}
      {activeSubtab === 'weekly' && (
        <WeeklyRacesBarChart filteredBatches={filteredBatches} />
      )}
      {filtered.length === 0 && <div>No usernames found.</div>}
      {loading && <div className="loading-message">Loading racer info...</div>}
      {error && <div className="error-message">{error}</div>}
    </div>
  );
}

function DailyRacesBarChart({ filteredBatches }: { filteredBatches: any[] }) {
  const dayMap: Record<string, { teamRaces: number; lifetimeRaces: number }> = {};

  filteredBatches.forEach((row) => {
    const d = new Date(row.batchEndTime).toLocaleDateString("en-US");
    if (!dayMap[d]) dayMap[d] = { teamRaces: 0, lifetimeRaces: 0 };
    dayMap[d].teamRaces += Number(row.sum) || 0;
    dayMap[d].lifetimeRaces += Number(row.racesPlayedBatch) || 0;
  });

  // Convert to array, sort by date descending (most recent first), limit to 30 days
  const days = Object.keys(dayMap)
    .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
    .slice(0, 30);

  const chartData = {
    labels: days, // Directly use `days`, it's already formatted
    datasets: [
      {
        label: 'Team Races',
        data: days.map((d) => dayMap[d] ? Number(dayMap[d].teamRaces) : 0), // Handle potential undefined values
        backgroundColor: '#1976d2',
        barThickness: 14,
        categoryPercentage: 0.5,
      },
      {
        label: 'Lifetime Races',
        data: days.map((d) => dayMap[d] ? Number(dayMap[d].lifetimeRaces) : 0), // Same fix here
        backgroundColor: '#ffc107',
        barThickness: 14,
        categoryPercentage: 0.5,
      },
    ],
  };
  const chartHeight = Math.max(400, days.length * 40);
  const chartOptions = {
    indexAxis: 'y' as const,
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: 'top' as const,
        labels: { color: '#fff', font: { size: 14 } },
      },
      title: {
        display: true,
        text: 'Daily Races',
        color: '#fff',
        font: { size: 18, weight: 'bold' as const },
        padding: { bottom: 20 },
      },
      datalabels: {
        color: '#fff',
        anchor: 'end' as const,
        align: 'end' as const,
        offset: 4,
        font: { size: 12 },
        formatter: (value: number) => value.toLocaleString(),
      },
    },
    scales: {
      x: {
        title: { display: true, text: 'Races', color: '#fff', font: { size: 16 } },
        grid: { color: '#333' },
        ticks: { color: '#fff', font: { size: 13 } },
      },
      y: {
        title: { display: true, text: 'Day', color: '#fff', font: { size: 16 } },
        grid: { color: '#333' },
        ticks: { color: '#fff', font: { size: 13 } },
      },
    },
  };
  return (
    <div style={{ width: '100%', minHeight: chartHeight, background: '#222', borderRadius: 8, padding: 24 }}>
      <Bar data={chartData} options={chartOptions} plugins={[ChartDataLabels]} height={chartHeight} />
    </div>
  );
}

function WeeklyRacesBarChart({ filteredBatches }: { filteredBatches: any[] }) {
  const weekMap: Record<string, { teamRaces: number; lifetimeRaces: number }> = {};

  filteredBatches.forEach((row) => {
    const date = new Date(row.batchEndTime);
    
    // Calculate the Sunday of that week
    const sunday = new Date(date);
    sunday.setDate(date.getDate() - date.getDay()); // Move back to Sunday

    // Format as "M/D/YYYY"
    const weekStart = sunday.toLocaleDateString("en-US");

    if (!weekMap[weekStart]) weekMap[weekStart] = { teamRaces: 0, lifetimeRaces: 0 };
    weekMap[weekStart].teamRaces += Number(row.sum) || 0;
    weekMap[weekStart].lifetimeRaces += Number(row.racesPlayedBatch) || 0;
  });

  // Convert to array, sort by most recent week, limit to last 10 weeks
  const weeks = Object.keys(weekMap)
    .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
    .slice(0, 30); 

  const chartData = {
    labels: weeks, // Weekly labels formatted as "M/D/YYYY"
    datasets: [
      {
        label: 'Team Races',
        data: weeks.map((w) => weekMap[w] ? Number(weekMap[w].teamRaces) : 0),
        backgroundColor: '#1976d2',
        barThickness: 14,
        categoryPercentage: 0.5,
      },
      {
        label: 'Lifetime Races',
        data: weeks.map((w) => weekMap[w] ? Number(weekMap[w].lifetimeRaces) : 0),
        backgroundColor: '#ffc107',
        barThickness: 14,
        categoryPercentage: 0.5,
      },
    ],
  };
  const chartHeight = Math.max(400, weeks.length * 40);
  const chartOptions = {
    indexAxis: 'y' as const,
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: 'top' as const,
        labels: { color: '#fff', font: { size: 14 } },
      },
      title: {
        display: true,
        text: 'Weekly Races',
        color: '#fff',
        font: { size: 18, weight: 'bold' as const },
        padding: { bottom: 20 },
      },
      datalabels: {
        color: '#fff',
        anchor: 'end' as const,
        align: 'end' as const,
        offset: 4,
        font: { size: 12 },
        formatter: (value: number) => value.toLocaleString(),
      },
    },
    scales: {
      x: {
        title: { display: true, text: 'Races', color: '#fff', font: { size: 16 } },
        grid: { color: '#333' },
        ticks: { color: '#fff', font: { size: 13 } },
      },
      y: {
        title: { display: true, text: 'Week', color: '#fff', font: { size: 16 } },
        grid: { color: '#333' },
        ticks: { color: '#fff', font: { size: 13 } },
      },
    },
  };
  return (
    <div style={{ width: '100%', minHeight: chartHeight, background: '#222', borderRadius: 8, padding: 24 }}>
      <Bar data={chartData} options={chartOptions} plugins={[ChartDataLabels]} height={chartHeight} />
    </div>
  );
}

export function SecondaryTabs({ activeTab, onTabChange }: { activeTab: string, onTabChange: (tab: string) => void }) {
  return (
    <div className="tabs">
      <button className={`tab ${activeTab === 'roster' ? 'active' : ''}`} onClick={() => onTabChange('roster')}>Roster</button>
      <button className={`tab ${activeTab === 'events' ? 'active' : ''}`} onClick={() => onTabChange('events')}>Events</button>
      <button className={`tab ${activeTab === 'eventviewer' ? 'active' : ''}`} onClick={() => onTabChange('eventviewer')}>Event Viewer</button>
      <button className={`tab ${activeTab === 'activity' ? 'active' : ''}`} onClick={() => onTabChange('activity')}>Activity</button>
      <button className={`tab ${activeTab === 'trackers' ? 'active' : ''}`} onClick={() => onTabChange('trackers')}>Trackers</button>
      <button className={`tab ${activeTab === 'admin' ? 'active' : ''}`} onClick={() => onTabChange('admin')}>Admin</button>
    </div>
  );
}

export default BatchInspector; 