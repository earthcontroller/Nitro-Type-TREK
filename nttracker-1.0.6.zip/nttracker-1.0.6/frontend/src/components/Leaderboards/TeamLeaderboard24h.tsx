import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toCentralTime, toMySQLDateTime } from './timezoneUtils';

interface TeamLeaderboardRow {
  TeamTag: string;
  Races: number;
  Accuracy: number;
  WPM: number;
  Points: number;
}

function formatPercent(val: any) {
  const num = Number(val);
  if (val === null || val === undefined || isNaN(num)) return '-';
  return (num * 100).toFixed(2) + '%';
}

function formatNumber(val: any) {
  const num = Number(val);
  if (val === null || val === undefined || isNaN(num)) return '-';
  return Math.round(num).toLocaleString();
}

function formatWPM(val: any) {
  const num = Number(val);
  if (val === null || val === undefined || isNaN(num)) return '-';
  return num.toFixed(1);
}

const sortableColumns = [
  { key: 'Races', label: 'Races' },
  { key: 'Accuracy', label: 'Accuracy' },
  { key: 'WPM', label: 'WPM' },
  { key: 'Points', label: 'Points' },
];

type SortKey = 'Races' | 'Accuracy' | 'WPM' | 'Points';

type SortConfig = {
  key: SortKey;
  direction: 'asc' | 'desc';
};

const medalStyle = (color: string) => ({
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 32,
  height: 32,
  borderRadius: '50%',
  background: color,
  color: '#fff',
  fontWeight: 700,
  fontSize: 18,
  boxShadow: '0 2px 6px rgba(0,0,0,0.15)',
  margin: '0 auto',
  textShadow: '0 1px 3px rgba(0,0,0,0.6), 0 0 2px #fff',
});

const medals = [
  { color: 'linear-gradient(135deg, #FFD700 60%, #FFFACD 100%)', label: '1' }, // Gold
  { color: 'linear-gradient(135deg, #C0C0C0 60%, #F5F5F5 100%)', label: '2' }, // Silver
  { color: 'linear-gradient(135deg, #CD7F32 60%, #FFDAB9 100%)', label: '3' }, // Bronze
];

const TeamLeaderboard24h: React.FC = () => {
  const [rows, setRows] = useState<TeamLeaderboardRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'Points', direction: 'desc' });
  const [showFlagged, setShowFlagged] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Convert local time to Central Time for backend consistency
    const now = new Date();
    const end = toCentralTime(now);
    const start = toCentralTime(new Date(now.getTime() - 24 * 60 * 60 * 1000)); // 24 hours ago
    
    const start_time = toMySQLDateTime(start);
    const end_time = toMySQLDateTime(end);
    setLoading(true);
    setError(null);
    fetch(`/api/team-leaderboard?start_time=${encodeURIComponent(start_time)}&end_time=${encodeURIComponent(end_time)}&showbot=${showFlagged ? 'TRUE' : 'FALSE'}`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch leaderboard');
        return res.json();
      })
      .then(data => {
        setRows(data || []);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setRows([]);
        setLoading(false);
      });
  }, [showFlagged]);

  // Sorting logic
  const sortedRows = [...rows].sort((a, b) => {
    const { key, direction } = sortConfig;
    const aVal = Number(a[key]);
    const bVal = Number(b[key]);
    if (isNaN(aVal) && isNaN(bVal)) return 0;
    if (isNaN(aVal)) return 1;
    if (isNaN(bVal)) return -1;
    if (direction === 'asc') return aVal - bVal;
    return bVal - aVal;
  });

  const handleSort = (key: SortKey) => {
    setSortConfig(prev =>
      prev.key === key
        ? { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' }
        : { key, direction: 'desc' }
    );
  };

  const getSortIcon = (key: SortKey) => {
    if (sortConfig.key !== key) return '↕️';
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  return (
    <div className="event-details">
      <div style={{ marginBottom: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h3 style={{ margin: 0 }}>Team Leaderboard (Last 24 Hours)</h3>
        <label style={{ display: 'flex', alignItems: 'center', fontSize: 'inherit' }}>
          <input
            type="checkbox"
            checked={showFlagged}
            onChange={e => setShowFlagged(e.target.checked)}
            style={{ marginRight: 8 }}
          />
          Show flagged racers
        </label>
      </div>
      {loading ? (
        <div className="loading-message">Loading leaderboard...</div>
      ) : error ? (
        <div className="error-message">{error}</div>
      ) : (
        <table className="display-names-table">
          <thead>
            <tr>
              <th style={{ width: 60, textAlign: 'center' }}>Rank</th>
              <th>Team Tag</th>
              {sortableColumns.map(col => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key as SortKey)}
                  className="sortable-header"
                  style={{ cursor: 'pointer', userSelect: 'none', textAlign: col.key === 'Points' ? 'center' : 'left' }}
                >
                  {col.label} {getSortIcon(col.key as SortKey)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedRows.map((row, idx) => (
              <tr key={row.TeamTag}>
                <td style={{ textAlign: 'center', fontWeight: 600 }}>
                  {idx < 3 ? (
                    <span style={medalStyle(medals[idx].color)} title={
                      idx === 0 ? 'Gold Medal' : idx === 1 ? 'Silver Medal' : 'Bronze Medal'
                    }>
                      {medals[idx].label}
                    </span>
                  ) : (
                    idx + 1
                  )}
                </td>
                <td>
                  <button
                    className="username-link"
                    style={{ color: '#1976d2', textDecoration: 'underline', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
                    onClick={() => navigate(`/roster?tag=${row.TeamTag}`)}
                    tabIndex={0}
                    aria-label={`Go to ${row.TeamTag} in Teams Roster`}
                  >
                    {row.TeamTag}
                  </button>
                </td>
                <td>{formatNumber(row.Races)}</td>
                <td>{formatPercent(row.Accuracy)}</td>
                <td>{formatWPM(row.WPM)}</td>
                <td style={{ textAlign: 'center', fontWeight: 600 }}>{formatNumber(row.Points)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {!loading && !rows.length && !error && (
        <div className="event-placeholder">
          <p>No team data found for the last 24 hours.</p>
        </div>
      )}
    </div>
  );
};

export default TeamLeaderboard24h; 