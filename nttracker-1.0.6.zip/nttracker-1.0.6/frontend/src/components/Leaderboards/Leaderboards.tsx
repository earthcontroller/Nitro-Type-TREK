import { useState, useEffect } from 'react';
import TeamLeaderboard24h from './TeamLeaderboard24h';
import TeamLeaderboard7d from './TeamLeaderboard7d';
import TeamLeaderboardDaily from './TeamLeaderboardDaily';
import TeamLeaderboardWeekly from './TeamLeaderboardWeekly';
import TeamLeaderboardMonthly from './TeamLeaderboardMonthly';
import TeamLeaderboardCustom from './TeamLeaderboardCustom';
import TeamLeaderboard60m from './TeamLeaderboard60m';
import IndividualLeaderboard24h from './IndividualLeaderboard24h';
import IndividualLeaderboard7d from './IndividualLeaderboard7d';
import IndividualLeaderboardDaily from './IndividualLeaderboardDaily';
import IndividualLeaderboardWeekly from './IndividualLeaderboardWeekly';
import IndividualLeaderboardMonthly from './IndividualLeaderboardMonthly';
import IndividualLeaderboardCustom from './IndividualLeaderboardCustom';
import IndividualLeaderboard60m from './IndividualLeaderboards60m';

const groupTabs = [
  { key: 'teams', label: 'Team Leaderboards' },
  { key: 'individuals', label: 'Individual Leaderboards' },
];

const leaderboardTabs = [
  { key: '24hour', label: '24 Hour' },
  { key: '60minute', label: '60 Minute' },
  { key: '7day', label: '7 Day' },
  { key: 'daily', label: 'Daily' },
  { key: 'weekly', label: 'Weekly' },
  { key: 'monthly', label: 'Monthly' },
  { key: 'custom', label: 'Custom' },
];

export default function Leaderboards() {
  const [groupBy, setGroupBy] = useState<'teams' | 'individuals'>(() => {
    return (localStorage.getItem('leaderboardGroupBy') as 'teams' | 'individuals') || 'teams';
  });
  const [activeTab, setActiveTab] = useState(() => {
    return localStorage.getItem('leaderboardActiveTab') || '24hour';
  });

  useEffect(() => {
    localStorage.setItem('leaderboardGroupBy', groupBy);
  }, [groupBy]);
  useEffect(() => {
    localStorage.setItem('leaderboardActiveTab', activeTab);
  }, [activeTab]);

  return (
    <div>
      {/* Second-level tab bar: Teams / Individuals (match TeamsSecondaryTabs) */}
      <div className="tabs" style={{ marginBottom: 16 }}>
        {groupTabs.map(tab => (
          <button
            key={tab.key}
            className={`tab${groupBy === tab.key ? ' active' : ''}`}
            onClick={() => setGroupBy(tab.key as 'teams' | 'individuals')}
          >
            {tab.label}
          </button>
        ))}
      </div>
      {/* Third-level tab bar: Leaderboard types */}
      <div style={{ display: 'flex', background: '#222', borderRadius: 8, padding: 4, marginBottom: 16 }}>
        {leaderboardTabs.map(tab => (
          <button
            key={tab.key}
            className={activeTab === tab.key ? 'active' : ''}
            style={{
              background: activeTab === tab.key ? '#1976d2' : 'transparent',
              color: activeTab === tab.key ? '#fff' : '#1976d2',
              fontWeight: 600,
              fontSize: 16,
              cursor: 'pointer',
              padding: '8px 24px',
              border: 'none',
              borderRadius: 6,
              outline: 'none',
              transition: 'background 0.2s, color 0.2s',
              marginRight: 6,
            }}
            onClick={() => setActiveTab(tab.key)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      
      {/* Leaderboard table */}
      <div style={{ background: '#181c24', borderRadius: 8, padding: 24, minHeight: 300, boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
        {groupBy === 'teams' && activeTab === '24hour' ? (
          <TeamLeaderboard24h />
        ) : groupBy === 'teams' && activeTab === '7day' ? (
          <TeamLeaderboard7d />
        ) : groupBy === 'teams' && activeTab === 'daily' ? (
          <TeamLeaderboardDaily />
        ) : groupBy === 'teams' && activeTab === 'weekly' ? (
          <TeamLeaderboardWeekly />
        ) : groupBy === 'teams' && activeTab === 'monthly' ? (
          <TeamLeaderboardMonthly />
        ) : groupBy === 'teams' && activeTab === 'custom' ? (
          <TeamLeaderboardCustom />
        ) : groupBy === 'teams' && activeTab === '60minute' ? (
          <TeamLeaderboard60m />
        ) : groupBy === 'individuals' && activeTab === '24hour' ? (
          <IndividualLeaderboard24h />
        ) : groupBy === 'individuals' && activeTab === '7day' ? (
          <IndividualLeaderboard7d />
        ) : groupBy === 'individuals' && activeTab === 'daily' ? (
          <IndividualLeaderboardDaily />
        ) : groupBy === 'individuals' && activeTab === 'weekly' ? (
          <IndividualLeaderboardWeekly />
        ) : groupBy === 'individuals' && activeTab === 'monthly' ? (
          <IndividualLeaderboardMonthly />
        ) : groupBy === 'individuals' && activeTab === 'custom' ? (
          <IndividualLeaderboardCustom />
        ) : groupBy === 'individuals' && activeTab === '60minute' ? (
          <IndividualLeaderboard60m />
        ) : null}
      </div>
    </div>
  );
}
