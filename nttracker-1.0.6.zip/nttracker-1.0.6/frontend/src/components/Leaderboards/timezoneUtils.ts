// Utility functions for timezone conversion in leaderboard components

/**
 * Converts a local Date to Central Time
 * @param date - The local date to convert
 * @returns Date object representing the same moment in Central Time
 */
export function toCentralTime(date: Date): Date {
  // Create a date in Central Time by using the 'America/Chicago' timezone
  // This automatically handles daylight saving time transitions
  const centralTimeString = date.toLocaleString('en-US', {
    timeZone: 'America/Chicago',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
  
  // Parse the Central Time string back to a Date object
  // Format: MM/DD/YYYY, HH:MM:SS
  const [datePart, timePart] = centralTimeString.split(', ');
  const [month, day, year] = datePart.split('/');
  const [hour, minute, second] = timePart.split(':');
  
  const centralTime = new Date(
    parseInt(year),
    parseInt(month) - 1, // Month is 0-indexed
    parseInt(day),
    parseInt(hour),
    parseInt(minute),
    parseInt(second)
  );
  return centralTime;
}

/**
 * Converts a Date to MySQL datetime format (YYYY-MM-DD HH:mm:ss)
 * @param date - The date to format
 * @returns String in MySQL datetime format
 */
export function toMySQLDateTime(date: Date): string {
  return date.getFullYear() + '-' +
    String(date.getMonth() + 1).padStart(2, '0') + '-' +
    String(date.getDate()).padStart(2, '0') + ' ' +
    String(date.getHours()).padStart(2, '0') + ':' +
    String(date.getMinutes()).padStart(2, '0') + ':' +
    String(date.getSeconds()).padStart(2, '0');
}

/**
 * Converts a Date to MySQL date format (YYYY-MM-DD)
 * @param date - The date to format
 * @returns String in MySQL date format
 */
export function toMySQLDate(date: Date): string {
  return date.getFullYear() + '-' +
    String(date.getMonth() + 1).padStart(2, '0') + '-' +
    String(date.getDate()).padStart(2, '0');
} 