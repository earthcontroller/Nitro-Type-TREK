import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function getLast7SundaysIncludingThisWeek() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dayOfWeek = today.getDay();
  const thisSunday = new Date(today);
  thisSunday.setDate(today.getDate() - dayOfWeek);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(thisSunday);
    d.setDate(thisSunday.getDate() - i * 7);
    return d;
  });
}

function getYYYYMMDDFromDate(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatPercent(val: any) {
  const num = Number(val);
  if (val === null || val === undefined || isNaN(num)) return '-';
  return (num * 100).toFixed(2) + '%';
}

function formatNumber(val: any) {
  const num = Number(val);
  if (val === null || val === undefined || isNaN(num)) return '-';
  return Math.round(num).toLocaleString();
}

function formatWPM(val: any) {
  const num = Number(val);
  if (val === null || val === undefined || isNaN(num)) return '-';
  return num.toFixed(1);
}

const sortableColumns = [
  { key: 'Races', label: 'Races' },
  { key: 'Accuracy', label: 'Accuracy' },
  { key: 'WPM', label: 'WPM' },
  { key: 'Points', label: 'Points' },
];

type SortKey = 'Races' | 'Accuracy' | 'WPM' | 'Points';

type SortConfig = {
  key: SortKey;
  direction: 'asc' | 'desc';
};

const medalStyle = (color: string) => ({
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 32,
  height: 32,
  borderRadius: '50%',
  background: color,
  color: '#fff',
  fontWeight: 700,
  fontSize: 18,
  boxShadow: '0 2px 6px rgba(0,0,0,0.15)',
  margin: '0 auto',
  textShadow: '0 1px 3px rgba(0,0,0,0.6), 0 0 2px #fff',
});

const medals = [
  { color: 'linear-gradient(135deg, #FFD700 60%, #FFFACD 100%)', label: '1' }, // Gold
  { color: 'linear-gradient(135deg, #C0C0C0 60%, #F5F5F5 100%)', label: '2' }, // Silver
  { color: 'linear-gradient(135deg, #CD7F32 60%, #FFDAB9 100%)', label: '3' }, // Bronze
];

interface IndividualLeaderboardRow {
  UserID: number;
  Username: string;
  CurrentDisplayName: string;
  TeamTag?: string;
  Races: number;
  Accuracy: number;
  WPM: number;
  Points: number;
  bot: number;
}

const PAGE_SIZE = 50;

const IndividualLeaderboardWeekly: React.FC = () => {
  const last7Sundays = getLast7SundaysIncludingThisWeek();
  const [selectedWeek, setSelectedWeek] = useState(() => getYYYYMMDDFromDate(last7Sundays[0]));
  const [rows, setRows] = useState<IndividualLeaderboardRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'Points', direction: 'desc' });
  const [page, setPage] = useState(1);
  const [showFlagged, setShowFlagged] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!selectedWeek) return;
    const start_time = selectedWeek + ' 00:00:00';
    const endDate = new Date(selectedWeek);
    endDate.setDate(endDate.getDate() + 6);
    const end_time = getYYYYMMDDFromDate(endDate) + ' 23:59:59';
    setLoading(true);
    setError(null);
    fetch(`/api/individual-leaderboard?start_time=${encodeURIComponent(start_time)}&end_time=${encodeURIComponent(end_time)}`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch leaderboard');
        return res.json();
      })
      .then(data => {
        setRows(data || []);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setRows([]);
        setLoading(false);
      });
  }, [selectedWeek]);

  // Sorting logic
  const sortedRows = [...rows].sort((a, b) => {
    const { key, direction } = sortConfig;
    const aVal = Number(a[key]);
    const bVal = Number(b[key]);
    if (isNaN(aVal) && isNaN(bVal)) return 0;
    if (isNaN(aVal)) return 1;
    if (isNaN(bVal)) return -1;
    if (direction === 'asc') return aVal - bVal;
    return bVal - aVal;
  });

  // Filter rows
  const filteredRows = showFlagged ? sortedRows : sortedRows.filter(row => row.bot != 1);
  const totalPages = Math.ceil(filteredRows.length / PAGE_SIZE) || 1;
  const pagedRows = filteredRows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const handleSort = (key: SortKey) => {
    setSortConfig(prev =>
      prev.key === key
        ? { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' }
        : { key, direction: 'desc' }
    );
  };

  const getSortIcon = (key: SortKey) => {
    if (sortConfig.key !== key) return '↕️';
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  useEffect(() => { setPage(1); }, [rows]);
  const handlePrev = () => setPage(p => Math.max(1, p - 1));
  const handleNext = () => setPage(p => Math.min(totalPages, p + 1));

  const getWeekRange = (sundayStr: string) => {
    const sunday = new Date(sundayStr);
    const end = new Date(sunday);
    end.setDate(sunday.getDate() + 6);
    return `${sunday.toLocaleDateString()} - ${end.toLocaleDateString()}`;
  };

  return (
    <div className="event-details">
      <div style={{ marginBottom: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h3 style={{ margin: 0 }}>Individual Leaderboard (Weekly)</h3>
        <label style={{ display: 'flex', alignItems: 'center', fontSize: 'inherit' }}>
          <input
            type="checkbox"
            checked={showFlagged}
            onChange={e => setShowFlagged(e.target.checked)}
            style={{ marginRight: 8 }}
          />
          Show flagged racers
        </label>
      </div>
      <div style={{ marginBottom: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
        <h3 style={{ margin: 0 }}>Individual Leaderboard: {getWeekRange(selectedWeek)}</h3>
        <select value={selectedWeek} onChange={e => setSelectedWeek(e.target.value)}>
          {last7Sundays.map((d) => {
            const ymd = getYYYYMMDDFromDate(d);
            return (
              <option key={ymd} value={ymd}>{getWeekRange(ymd)}</option>
            );
          })}
        </select>
      </div>
      {loading ? (
        <div className="loading-message">Loading leaderboard...</div>
      ) : error ? (
        <div className="error-message">{error}</div>
      ) : (
        <>
        <table className="display-names-table">
          <thead>
            <tr>
              <th style={{ width: 60, textAlign: 'center' }}>Rank</th>
              <th>Display Name</th>
              <th>Username</th>
              <th>Team</th>
              {sortableColumns.map(col => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key as SortKey)}
                  className="sortable-header"
                  style={{ cursor: 'pointer', userSelect: 'none', textAlign: col.key === 'Points' ? 'center' : 'left' }}
                >
                  {col.label} {getSortIcon(col.key as SortKey)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pagedRows.map((row, idx) => (
              <tr key={row.UserID}>
                <td style={{ textAlign: 'center', fontWeight: 600 }}>
                  {((page - 1) * PAGE_SIZE + idx) < 3 ? (
                    <span style={medalStyle(medals[(page - 1) * PAGE_SIZE + idx].color)} title={
                      ((page - 1) * PAGE_SIZE + idx) === 0 ? 'Gold Medal' : ((page - 1) * PAGE_SIZE + idx) === 1 ? 'Silver Medal' : 'Bronze Medal'
                    }>
                      {medals[(page - 1) * PAGE_SIZE + idx].label}
                    </span>
                  ) : (
                    (page - 1) * PAGE_SIZE + idx + 1
                  )}
                </td>
                <td>
                  <a
                    href={`https://www.nitrotype.com/racer/${row.Username}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    tabIndex={0}
                    aria-label={`View ${row.Username} on Nitrotype`}
                  >
                    {row.CurrentDisplayName}{row.bot == 1 && <span title="Bot" style={{ marginLeft: 4 }}>🤖</span>}
                  </a>
                </td>
                <td>
                  <button
                    className="username-link"
                    onClick={() => navigate(`/racers?username=${row.Username}&subtab=batch`)}
                    tabIndex={0}
                    aria-label={`Go to ${row.Username} in Racers Batch Inspector`}
                  >
                    {row.Username}
                  </button>
                </td>
                <td>{row.TeamTag || '-'}</td>
                <td>{formatNumber(row.Races)}</td>
                <td>{formatPercent(row.Accuracy)}</td>
                <td>{formatWPM(row.WPM)}</td>
                <td style={{ textAlign: 'center', fontWeight: 600 }}>{formatNumber(row.Points)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 16, marginTop: 16 }}>
          <button
            onClick={handlePrev}
            disabled={page === 1}
            style={{
              background: page === 1 ? '#333' : '#1976d2',
              color: '#fff',
              border: 'none',
              borderRadius: 4,
              padding: '6px 18px',
              fontWeight: 600,
              fontSize: 16,
              cursor: page === 1 ? 'not-allowed' : 'pointer',
              opacity: page === 1 ? 0.6 : 1,
              transition: 'background 0.2s, color 0.2s',
            }}
          >
            Previous
          </button>
          <span style={{ color: '#fff', fontWeight: 500 }}>
            Page {page} of {totalPages}
          </span>
          <button
            onClick={handleNext}
            disabled={page === totalPages}
            style={{
              background: page === totalPages ? '#333' : '#1976d2',
              color: '#fff',
              border: 'none',
              borderRadius: 4,
              padding: '6px 18px',
              fontWeight: 600,
              fontSize: 16,
              cursor: page === totalPages ? 'not-allowed' : 'pointer',
              opacity: page === totalPages ? 0.6 : 1,
              transition: 'background 0.2s, color 0.2s',
            }}
          >
            Next
          </button>
        </div>
        </>
      )}
      {!loading && !rows.length && !error && (
        <div className="event-placeholder">
          <p>No individual data found for this week.</p>
        </div>
      )}
    </div>
  );
};

export default IndividualLeaderboardWeekly; 