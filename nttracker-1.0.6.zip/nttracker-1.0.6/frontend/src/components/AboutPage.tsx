import React from 'react';

const AboutPage: React.FC = () => (
  <div style={{ maxWidth: 700, margin: '40px auto', padding: 32, background: 'rgba(30,34,60,0.95)', borderRadius: 18, boxShadow: '0 4px 24px #0002', color: '#fff', textAlign: 'center' }}>
    <h1 style={{ fontSize: '2.5rem', marginBottom: 12, letterSpacing: 1 }}>
      <span role="img" aria-label="star">✨</span> StarTrack <span style={{ fontSize: '1.2rem', color: '#ffd700' }}>by Starlight</span> <span role="img" aria-label="star">✨</span>
    </h1>
    <p style={{ fontSize: '1.2rem', marginBottom: 24, color: '#ffd700', fontWeight: 500 }}>
      The ultimate NitroType event & stats tracker for teams and racers!
    </p>
    <div style={{ textAlign: 'left', margin: '0 auto', maxWidth: 600 }}>
      <ul style={{ fontSize: '1.1rem', lineHeight: 1.7, marginBottom: 24 }}>
        <li>
          <b>Schedule & track</b> real-time team competitions and cross-team events.<br/>
          <span style={{ color: '#90caf9' }}>Create events with 1-10 teams, optionally divided into 1-9 squads.</span>
        </li>
        <li>
          <b>View individual racer stats</b> by 10-min batches over time:<br/>
          <span style={{ color: '#90caf9' }}>Race count, WPM, and Accuracy, all visualized for easy analysis.</span>
        </li>
        <li>
          <b>Cross-team leaderboards</b> for both teams and individuals:<br/>
          <span style={{ color: '#90caf9' }}>See how you stack up against all tracked teams and racers!</span>
        </li>
      </ul>
      <div style={{ background: '#222a', borderRadius: 10, padding: 18, marginBottom: 18, color: '#fff' }}>
        <b>Questions or feature requests?</b><br/>
        Contact <span style={{ color: '#ffd700', fontWeight: 600 }}>Starlight✨</span> on Discord:<br/>
        <a href="https://discord.gg/HymxRvpp55" target="_blank" rel="noopener noreferrer" style={{ color: '#90caf9', fontWeight: 600, fontSize: '1.1em', textDecoration: 'underline' }}>
          discord.gg/HymxRvpp55
        </a>
      </div>
      <div style={{ marginTop: 24, fontSize: '1.1rem', color: '#ffd700' }}>
        <span role="img" aria-label="star">⭐</span> Built for the NitroType community by Starlight <span role="img" aria-label="star">⭐</span>
      </div>
    </div>
  </div>
);

export default AboutPage; 