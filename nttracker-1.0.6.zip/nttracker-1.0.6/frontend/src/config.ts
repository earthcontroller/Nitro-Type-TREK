// Load environment variables from .env file
const BACKEND_URL = `http://localhost:${import.meta.env.VITE_BACKEND_PORT || '5001'}`;

export const config = {
  backendUrl: BACKEND_URL,
}; 