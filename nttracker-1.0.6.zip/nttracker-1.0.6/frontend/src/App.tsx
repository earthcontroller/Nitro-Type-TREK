import React, { useState, useEffect } from 'react'
import { Routes, Route, useLocation, useNavigate, useSearchParams, Navigate } from 'react-router-dom'
import './App.css'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  registerables,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
// @ts-ignore: Imprting PNG for logo
import logo from './StarTrack-2.png'; // Use a placeholder if needed
import RosterTable from './components/Teams/Roster';
import BatchInspector from './components/Racers/BatchInspector';
import EventsTable from './components/Teams/Events';
import { DisplayName } from './components/Shared/Interfaces';
import { Event } from './components/Teams/Events';
import EventViewer from './components/Teams/EventViewer';
import StandaloneEventViewer from './components/Teams/StandaloneEventViewer';
import ActivityViewer from './components/Teams/Activity';
import { TeamContext } from './components/Shared/TeamContext';
import TrackersTabs from './components/Teams/Trackers';
import { SquadsPage, AdminEventsSection } from './components/Teams/Admin';
import Leaderboards from './components/Leaderboards/Leaderboards';
import UserManagement from './components/Admin/UserManagement';
import AboutPage from './components/AboutPage';
import StandaloneWarnListTable from './components/Teams/StandaloneWarnListTable';

// Register the chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartDataLabels,
  ...registerables
);

// Create a context for navigation
const AppNavigationContext = React.createContext<{
  setTopLevelTab: (tab: 'teams' | 'racers' | 'leaderboards' | 'about' | 'admin') => void;
  setRacersTabSelected: (tab: string) => void;
  setRacersTabSubtab: (tab: 'batch' | 'daily' | 'weekly') => void;
}>({
  setTopLevelTab: () => {},
  setRacersTabSelected: () => {},
  setRacersTabSubtab: () => {},
});


function TopNavBar({ activeTab, setActiveTab, user, onLoginClick, onLogout }: {
  activeTab: 'teams' | 'racers' | 'leaderboards' | 'about' | 'admin';
  setActiveTab: (tab: 'teams' | 'racers' | 'leaderboards' | 'about' | 'admin') => void;
  user: { logged_in: boolean; username?: string; role?: string };
  onLoginClick: () => void;
  onLogout: () => void;
}) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const selectedTag = searchParams.get('tag');

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      background: 'transparent',
      padding: '0.5rem 0rem',
      borderBottom: '2px solid #1565c0',
      minHeight: 60,
      position: 'relative'
    }}>
      <img src={logo} alt="StarTrack Logo" style={{ height: 60, marginRight: 24 }} />
      <div style={{ display: 'flex', gap: 16, flex: 1 }}>
        <button
          className={`topnav-tab${activeTab === 'leaderboards' ? ' active' : ''}`}
          style={{
            background: activeTab === 'leaderboards' ? '#1976d2' : 'transparent',
            color: activeTab === 'leaderboards' ? '#fff' : '#1976d2',
            fontWeight: 600,
            fontSize: 18,
            cursor: 'pointer',
            padding: '8px 20px',
            border: 'none',
            borderRadius: 8,
            outline: 'none',
            transition: 'background 0.2s, color 0.2s'
          }}
          onClick={() => {
            setActiveTab('leaderboards');
            navigate('/leaderboards' + (selectedTag ? `?tag=${selectedTag}` : ''));
          }}
        >
          Leaderboards
        </button>
        <button
          className={`topnav-tab${activeTab === 'teams' ? ' active' : ''}`}
          style={{
            background: activeTab === 'teams' ? '#1976d2' : 'transparent',
            color: activeTab === 'teams' ? '#fff' : '#1976d2',
            fontWeight: 600,
            fontSize: 18,
            cursor: 'pointer',
            padding: '8px 20px',
            border: 'none',
            borderRadius: 8,
            outline: 'none',
            transition: 'background 0.2s, color 0.2s'
          }}
          onClick={() => {
            setActiveTab('teams');
            let tag = selectedTag;
            if (!tag) {
              tag = localStorage.getItem('selectedTag') || '';
              if (tag) {
                navigate('/roster?tag=' + tag);
                return;
              }
            }
            navigate('/roster' + (tag ? `?tag=${tag}` : ''));
          }}
        >
          Teams
        </button>
        <button
          className={`topnav-tab${activeTab === 'racers' ? ' active' : ''}`}
          style={{
            background: activeTab === 'racers' ? '#1976d2' : 'transparent',
            color: activeTab === 'racers' ? '#fff' : '#1976d2',
            fontWeight: 600,
            fontSize: 18,
            cursor: 'pointer',
            padding: '8px 20px',
            border: 'none',
            borderRadius: 8,
            outline: 'none',
            transition: 'background 0.2s, color 0.2s'
          }}
          onClick={() => {
            setActiveTab('racers');
            navigate('/racers' + (selectedTag ? `?tag=${selectedTag}` : ''));
          }}
        >
          Racers
        </button>
        <button
          className={`topnav-tab${activeTab === 'about' ? ' active' : ''}`}
          style={{
            background: activeTab === 'about' ? '#1976d2' : 'transparent',
            color: activeTab === 'about' ? '#fff' : '#1976d2',
            fontWeight: 600,
            fontSize: 18,
            cursor: 'pointer',
            padding: '8px 20px',
            border: 'none',
            borderRadius: 8,
            outline: 'none',
            transition: 'background 0.2s, color 0.2s'
          }}
          onClick={() => {
            setActiveTab('about');
            navigate('/about');
          }}
        >
          About
        </button>
        {user.logged_in && user.role === 'admin' && (
          <button
            className={`topnav-tab${activeTab === 'admin' ? ' active' : ''}`}
            style={{
              background: activeTab === 'admin' ? '#1976d2' : 'transparent',
              color: activeTab === 'admin' ? '#fff' : '#1976d2',
              fontWeight: 600,
              fontSize: 18,
              cursor: 'pointer',
              padding: '8px 20px',
              border: 'none',
              borderRadius: 8,
              outline: 'none',
              transition: 'background 0.2s, color 0.2s'
            }}
            onClick={() => {
              setActiveTab('admin');
              navigate('/admin');
            }}
          >
            Admin
          </button>
        )}
      </div>
      <div style={{ position: 'absolute', right: 0, top: 0, height: '100%', display: 'flex', alignItems: 'center' }}>
        {!user.logged_in ? (
          <button onClick={onLoginClick} style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 8, padding: '8px 20px', fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>
            Login
          </button>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ color: '#1976d2', fontWeight: 600 }}>{user.username}</span>
            <button onClick={onLogout} style={{ background: '#eee', color: '#1976d2', border: 'none', borderRadius: 8, padding: '6px 16px', fontWeight: 600, fontSize: 15, cursor: 'pointer' }}>
              Logout
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// Create a separate SecondaryTabs component for the teams section
function TeamsSecondaryTabs({ activeTab, onTabChange }: { activeTab: string, onTabChange: (tab: string) => void }) {
  return (
    <div className="tabs">
      <button className={`tab ${activeTab === 'roster' ? 'active' : ''}`} onClick={() => onTabChange('roster')}>Roster</button>
      <button className={`tab ${activeTab === 'events' ? 'active' : ''}`} onClick={() => onTabChange('events')}>Events</button>
      <button className={`tab ${activeTab === 'eventviewer' ? 'active' : ''}`} onClick={() => onTabChange('eventviewer')}>Event Viewer</button>
      <button className={`tab ${activeTab === 'activity' ? 'active' : ''}`} onClick={() => onTabChange('activity')}>Activity</button>
      <button className={`tab ${activeTab === 'trackers' ? 'active' : ''}`} onClick={() => onTabChange('trackers')}>Trackers</button>
      <button className={`tab ${activeTab === 'admin' ? 'active' : ''}`} onClick={() => onTabChange('admin')}>Admin</button>
    </div>
  );
}

function TeamInfoCard({ tag }: { tag: string }) {
  const [info, setInfo] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!tag) return;
    setLoading(true);
    setError(null);
    fetch(`/api/team-info?tag=${encodeURIComponent(tag)}`)
      .then(res => res.json())
      .then(data => {
        if (data.error) throw new Error(data.error);
        setInfo(data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setInfo(null);
        setLoading(false);
      });
  }, [tag]);

  if (!tag) return null;
  if (loading) return <div className="team-info-card" style={{marginBottom: 16}}>Loading team info...</div>;
  if (error) return <div className="team-info-card error" style={{marginBottom: 16, color: 'red'}}>{error}</div>;
  if (!info) return null;

  // Use tagColor for tag and name, ensure it starts with '#'
  let tagColor = info.tagColor || '#1976d2';
  if (tagColor && !tagColor.startsWith('#')) tagColor = `#${tagColor}`;

  return (
    <div className="team-info-card" style={{
      background: 'var(--bg-secondary, #f5f7fa)',
      border: '1px solid var(--border-color, #cfd8dc)',
      borderRadius: 10,
      padding: '18px 24px',
      marginBottom: 24,
      display: 'flex',
      flexDirection: 'column',
      fontSize: '1.05em',
      boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 8 }}>
        <span style={{ fontWeight: 700, fontSize: '1.2em', color: tagColor }}>{info.Tag}</span>
        <span style={{ fontWeight: 600, fontSize: '1.2em', color: tagColor }}>{info.name}</span>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 24, alignItems: 'center' }}>
        <span><strong>Created:</strong> {info.createdStamp || 'N/A'}</span>
        <span><strong>Captain:</strong> {info.captain || 'N/A'}</span>
        <span><strong>Username:</strong> {info.username || 'N/A'}</span>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 24, alignItems: 'center', width: '100%', marginTop: 8 }}>
        <span><strong>Lifetime Races:</strong> {info.min_races ?? 'N/A'}</span>
        <span><strong>Min WPM:</strong> {info.min_speed ?? 'N/A'}</span>
        <span><strong>Weekly Races Requirement:</strong> {(!info.WeeklyRequirements || info.WeeklyRequirements === '0') ? 'N/A' : info.WeeklyRequirements}</span>
        <span><strong>Special Requirements:</strong> {info.otherRequirements || 'N/A'}</span>
      </div>
    </div>
  );
}

function LoginModal({ open, onClose, onLogin, error }: { open: boolean; onClose: () => void; onLogin: (username: string, password: string) => void; error: string }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  useEffect(() => {
    if (open) {
      setUsername('');
      setPassword('');
    }
  }, [open]);
  if (!open) return null;
  return (
    <div className="modal-overlay" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: '#000a', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div className="modal-content" style={{ background: '#222', padding: 32, borderRadius: 12, minWidth: 320, boxShadow: '0 4px 24px #0008', color: '#fff', position: 'relative' }}>
        <button onClick={onClose} style={{ position: 'absolute', top: 12, right: 12, background: 'none', border: 'none', color: '#fff', fontSize: 22, cursor: 'pointer' }}>&times;</button>
        <h2 style={{ marginBottom: 18, color: '#90caf9' }}>Admin Login</h2>
        <form onSubmit={e => { e.preventDefault(); onLogin(username, password); }}>
          <div style={{ marginBottom: 16 }}>
            <input type="text" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} style={{ width: '100%', padding: 10, borderRadius: 6, border: '1px solid #444', fontSize: 16 }} autoFocus />
          </div>
          <div style={{ marginBottom: 16 }}>
            <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} style={{ width: '100%', padding: 10, borderRadius: 6, border: '1px solid #444', fontSize: 16 }} />
          </div>
          {error && <div style={{ color: '#e53935', marginBottom: 12 }}>{error}</div>}
          <button type="submit" style={{ width: '100%', background: '#1976d2', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 0', fontWeight: 600, fontSize: 17, cursor: 'pointer' }}>Login</button>
        </form>
      </div>
    </div>
  );
}

function WeeklyRequirementsTab({ selectedTag, user }: { selectedTag: string; user: { logged_in: boolean; username?: string; role?: string } }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [requirements, setRequirements] = useState<number | null>(null);
  const [inputValue, setInputValue] = useState('');
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);

  const canEdit = user?.role === 'admin' || user?.role === 'teamadmin';

  useEffect(() => {
    if (!selectedTag) return;
    setLoading(true);
    setError(null);
    setSuccess(null);
    fetch(`/api/team-info?tag=${encodeURIComponent(selectedTag)}`)
      .then(res => res.json())
      .then(data => {
        if (data.error) throw new Error(data.error);
        setRequirements(data.WeeklyRequirements ?? null);
        setInputValue(data.WeeklyRequirements !== null && data.WeeklyRequirements !== undefined ? String(data.WeeklyRequirements) : '');
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, [selectedTag]);

  const handleSave = () => {
    setSaving(true);
    setError(null);
    setSuccess(null);
    let reqValue: number | null = null;
    if (inputValue.trim() !== '') {
      reqValue = Number(inputValue);
      if (isNaN(reqValue) || reqValue < 0) {
        setError('Please enter a valid non-negative number.');
        setSaving(false);
        return;
      }
    }
    fetch('/api/update-weekly-requirements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tag: selectedTag, requirements: reqValue }),
    })
      .then(res => res.json())
      .then(data => {
        if (data.error) throw new Error(data.error);
        setSuccess('Weekly race requirement updated!');
        setRequirements(reqValue);
        setSaving(false);
      })
      .catch(err => {
        setError(err.message);
        setSaving(false);
      });
  };

  return (
    <div className="admin-requirements-section">
      <h2>Weekly Requirements</h2>
      {loading && <div>Loading...</div>}
      {error && <div style={{ color: 'red' }}>{error}</div>}
      {!loading && !error && (
        <>
          <div style={{ fontSize: 18, margin: '16px 0' }}>
            <strong>Current weekly race requirement:</strong> {requirements !== null ? requirements : 'Not Set'}
          </div>
          {canEdit ? (
            <>
              <div style={{ margin: '16px 0', display: 'flex', alignItems: 'center', gap: 12 }}>
                <input
                  type="number"
                  min={0}
                  value={inputValue}
                  onChange={e => setInputValue(e.target.value)}
                  placeholder="Enter new requirement or leave blank to unset"
                  style={{ padding: 8, borderRadius: 4, border: '1px solid #ccc', width: 180 }}
                  disabled={saving}
                />
                <button
                  onClick={handleSave}
                  disabled={saving}
                  style={{ padding: '8px 18px', background: '#1976d2', color: '#fff', border: 'none', borderRadius: 4, fontWeight: 600 }}
                >
                  {saving ? 'Saving...' : 'Save'}
                </button>
              </div>
              {success && <div style={{ color: 'green', marginTop: 8 }}>{success}</div>}
            </>
          ) : (
            <div style={{ color: 'red', marginTop: '1rem' }}>Insufficient permissions</div>
          )}
        </>
      )}
    </div>
  );
}

function App(): JSX.Element {
  const [displayNames, setDisplayNames] = useState<DisplayName[]>([]);
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const selectedTag = searchParams.get('tag') || '';
  const [tags, setTags] = useState<string[]>([]);
  const location = useLocation();
  
  // Determine topNavTab based on current path
  const [topNavTab, setTopNavTab] = useState<'teams' | 'racers' | 'leaderboards' | 'about' | 'admin'>(() => {
    const path = location.pathname;
    if (path.startsWith('/racers')) return 'racers';
    if (path.startsWith('/leaderboards')) return 'leaderboards';
    if (path.startsWith('/about')) return 'about';
    if (path === '/admin') return 'admin';
    if (path.startsWith('/teams')) return 'teams';
    return 'teams';
  });

  // Update topNavTab when path changes
  useEffect(() => {
    const path = location.pathname;
    if (path.startsWith('/racers')) setTopNavTab('racers');
    else if (path.startsWith('/leaderboards')) setTopNavTab('leaderboards');
    else if (path.startsWith('/about')) setTopNavTab('about');
    else if (path === '/admin') setTopNavTab('admin');
    else if (path.startsWith('/teams')) setTopNavTab('teams');
    else setTopNavTab('teams');
  }, [location.pathname]);

  const [activeTab, setActiveTab] = useState<'roster' | 'events' | 'eventviewer' | 'activity' | 'trackers' | 'admin'>(() => {
    const savedTab = localStorage.getItem('activeTab');
    return (savedTab as any) || 'roster';
  });
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);
  const [adminTab, setAdminTab] = useState<'events' | 'squads' | 'requirements'>('events');
  const [racersTabSelected, setRacersTabSelected] = useState('');
  const [racersTabSubtab, setRacersTabSubtab] = useState<'batch' | 'daily' | 'weekly'>('batch');
  const [user, setUser] = useState({ logged_in: false, username: '', role: '' });
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [teamTagLocked, setTeamTagLocked] = useState(false);

  // Save selectedTag to localStorage whenever it changes
  useEffect(() => {
    if (selectedTag) {
      localStorage.setItem('selectedTag', selectedTag);
    } else {
      localStorage.removeItem('selectedTag');
    }
  }, [selectedTag]);

  useEffect(() => {
    localStorage.setItem('topLevelTab', topNavTab);
  }, [topNavTab]);
  useEffect(() => {
    localStorage.setItem('activeTab', activeTab);
  }, [activeTab]);

  useEffect(() => {
    // Fetch team tags
    fetch('/api/team-tags')
      .then(response => response.json())
      .then(data => setTags(data))
      .catch(error => console.error('Error fetching tags:', error));
  }, []);

  useEffect(() => {
    // Fetch display names when selectedTag changes
    if (selectedTag) {
      const url = `/api/current-display-names?tag=${encodeURIComponent(selectedTag)}`;
      fetch(url)
        .then(response => response.json())
        .then(data => setDisplayNames(data))
        .catch(error => console.error('Error fetching display names:', error));
    } else {
      setDisplayNames([]);
    }
  }, [selectedTag]);

  // Fetch events when selectedTag changes
  useEffect(() => {
    if (selectedTag) {
      fetch(`/api/team-events?tag=${encodeURIComponent(selectedTag)}`)
        .then(response => response.json())
        .then(data => {
          setEvents(data || []);
          // If event param is present in URL, use it
          const eventParam = searchParams.get('event');
          if (eventParam && data.some((e: any) => e.EventID === Number(eventParam))) {
            setSelectedEventId(Number(eventParam));
          } else if (data && data.length > 0) {
            // Try to restore from localStorage
            const storedId = localStorage.getItem('selectedEventId');
            const storedIdNum = storedId ? Number(storedId) : null;
            const found = storedIdNum && data.some((e: any) => e.EventID === storedIdNum);
            if (found) {
              setSelectedEventId(storedIdNum);
            } else {
              // Otherwise, set to most recent
              const mostRecent = [...data].sort((a, b) => {
                const aTime = new Date(a.StartTime).getTime();
                const bTime = new Date(b.StartTime).getTime();
                if (aTime !== bTime) return bTime - aTime;
                return b.EventID - a.EventID;
              })[0];
              setSelectedEventId(mostRecent.EventID);
            }
          } else {
            setSelectedEventId(null);
          }
        })
        .catch(() => {
          setEvents([]);
          setSelectedEventId(null);
        });
    } else {
      setEvents([]);
      setSelectedEventId(null);
    }
  }, [selectedTag, searchParams.get('event')]);

  // When selectedEventId changes, update the URL query param
  useEffect(() => {
    if (location.pathname === '/eventviewer') {
      if (selectedEventId) {
        setSearchParams(prev => {
          const newParams = new URLSearchParams(prev);
          newParams.set('event', String(selectedEventId));
          if (selectedTag) newParams.set('tag', selectedTag);
          return newParams;
        });
      } else {
        setSearchParams(prev => {
          const newParams = new URLSearchParams(prev);
          newParams.delete('event');
          if (selectedTag) newParams.set('tag', selectedTag);
          return newParams;
        });
      }
    }
  }, [selectedEventId, location.pathname, selectedTag, setSearchParams]);

  // Persist selectedEventId in localStorage whenever it changes
  useEffect(() => {
    if (selectedEventId !== null && selectedEventId !== undefined) {
      localStorage.setItem('selectedEventId', String(selectedEventId));
    }
  }, [selectedEventId]);

  // Fetch user info on app load/refresh
  useEffect(() => {
    fetch('/api/me').then(res => res.json()).then(data => setUser(data)).catch(() => setUser({ logged_in: false, username: '', role: '' }));
  }, []);

  useEffect(() => {
    // Only enforce tag lock when on /teams/admin
    if (
      user.logged_in &&
      user.role === 'teamadmin' &&
      location.pathname === '/teams/admin'
    ) {
      fetch('/api/my-team-tag')
        .then(res => res.json())
        .then(data => {
          if (data.teamTag) {
            setSearchParams({ tag: data.teamTag });
            setTeamTagLocked(true);
          }
        });
    } else if (location.pathname === '/teams/admin') {
      setTeamTagLocked(false);
    }
  }, [user, location.pathname]);

  const handleEventClick = (eventId: number) => {
    setSelectedEventId(eventId);
    setActiveTab('eventviewer');
    // Update URL to include event param
    navigate(`/eventviewer?tag=${selectedTag}&event=${eventId}`);
  };

  const handleLoginClick = () => {
    setLoginModalOpen(true);
    setLoginError('');
  };

  const handleLogin = (username: string, password: string) => {
    fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setUser({ logged_in: true, username: data.username, role: data.role });
          setLoginModalOpen(false);
          setLoginError('');
        } else {
          setLoginError(data.error || 'Login failed');
        }
      })
      .catch(() => setLoginError('Login failed'));
  };

  const handleLogout = () => {
    fetch('/api/logout', { method: 'POST' })
      .then(() => setUser({ logged_in: false, username: '', role: '' }));
  };

  // --- Embed route override ---
  if (location.pathname.startsWith('/embed/event') || location.pathname.startsWith('/embed/warnlist')) {
    // Only render the embed component, no nav, no context providers
    if (location.pathname.startsWith('/embed/event')) {
      return <StandaloneEventViewer />;
    } else if (location.pathname.startsWith('/embed/warnlist')) {
      return <StandaloneWarnListTable />;
    }
  }

  return (
    <TeamContext.Provider value={selectedTag}>
      <AppNavigationContext.Provider value={{ setTopLevelTab: setTopNavTab, setRacersTabSelected, setRacersTabSubtab }}>
        <div className="app">
          <TopNavBar activeTab={topNavTab} setActiveTab={tab => {
            setTopNavTab(tab);
            if (tab === 'teams') {
              navigate('/roster' + (selectedTag ? `?tag=${selectedTag}` : ''));
            }
            if (tab === 'racers') {
              navigate('/racers' + (selectedTag ? `?tag=${selectedTag}` : ''));
            }
          }} user={user} onLoginClick={handleLoginClick} onLogout={handleLogout} />
          <LoginModal open={loginModalOpen} onClose={() => setLoginModalOpen(false)} onLogin={handleLogin} error={loginError} />
          <Routes>
            {/* Teams section routes */}
            <Route path="/" element={
              <Navigate to="/leaderboards" replace />
            } />
            <Route path="/roster" element={
              <>
                <div className="tag-selector">
                  <select
                    value={selectedTag}
                    onChange={e => {
                      const newTag = e.target.value;
                      setSearchParams(newTag ? { tag: newTag } : {});
                      navigate('/roster' + (newTag ? `?tag=${newTag}` : ''));
                    }}
                    className="tag-dropdown"
                  >
                    <option value="">Select a team</option>
                    {tags.map(tag => (
                      <option key={tag} value={tag}>{tag}</option>
                    ))}
                  </select>
                </div>
                <TeamsSecondaryTabs activeTab="roster" onTabChange={tab => {
                  if (tab === 'admin') navigate(`/teams/admin${selectedTag ? `?tag=${selectedTag}` : ''}`);
                  else navigate(`/${tab}${selectedTag ? `?tag=${selectedTag}` : ''}`);
                }} />
                {selectedTag && <TeamInfoCard tag={selectedTag} />}
                <RosterTable displayNames={displayNames} />
              </>
            } />
            <Route path="/events" element={
              <>
                <div className="tag-selector">
                  <select
                    value={selectedTag}
                    onChange={e => {
                      setSearchParams(e.target.value ? { tag: e.target.value } : {});
                    }}
                    className="tag-dropdown"
                  >
                    <option value="">Select a team</option>
                    {tags.map(tag => (
                      <option key={tag} value={tag}>{tag}</option>
                    ))}
                  </select>
                </div>
                <TeamsSecondaryTabs activeTab="events" onTabChange={tab => {
                  if (tab === 'admin') navigate(`/teams/admin${selectedTag ? `?tag=${selectedTag}` : ''}`);
                  else navigate(`/${tab}${selectedTag ? `?tag=${selectedTag}` : ''}`);
                }} />
                <EventsTable onEventClick={handleEventClick} selectedTag={selectedTag} events={events} />
              </>
            } />
            <Route path="/eventviewer" element={
              <>
                <div className="tag-selector">
                  <select
                    value={selectedTag}
                    onChange={e => {
                      setSearchParams(e.target.value ? { tag: e.target.value } : {});
                    }}
                    className="tag-dropdown"
                  >
                    <option value="">Select a team</option>
                    {tags.map(tag => (
                      <option key={tag} value={tag}>{tag}</option>
                    ))}
                  </select>
                </div>
                <TeamsSecondaryTabs activeTab="eventviewer" onTabChange={tab => {
                  if (tab === 'admin') navigate(`/teams/admin${selectedTag ? `?tag=${selectedTag}` : ''}`);
                  else navigate(`/${tab}${selectedTag ? `?tag=${selectedTag}` : ''}`);
                }} />
                <EventViewer
                  events={events}
                  selectedEventId={selectedEventId}
                  setSelectedEventId={setSelectedEventId}
                  selectedTag={selectedTag}
                />
              </>
            } />
            <Route path="/activity" element={
              <>
                <div className="tag-selector">
                  <select
                    value={selectedTag}
                    onChange={e => {
                      setSearchParams(e.target.value ? { tag: e.target.value } : {});
                    }}
                    className="tag-dropdown"
                  >
                    <option value="">Select a team</option>
                    {tags.map(tag => (
                      <option key={tag} value={tag}>{tag}</option>
                    ))}
                  </select>
                </div>
                <TeamsSecondaryTabs activeTab="activity" onTabChange={tab => {
                  if (tab === 'admin') navigate(`/teams/admin${selectedTag ? `?tag=${selectedTag}` : ''}`);
                  else navigate(`/${tab}${selectedTag ? `?tag=${selectedTag}` : ''}`);
                }} />
                <ActivityViewer />
              </>
            } />
            <Route path="/admin" element={
              user.logged_in && user.role === 'admin' ? <UserManagement /> : <div style={{textAlign:'center',marginTop:40,color:'#e53935'}}>Admin access required.</div>
            } />
            <Route path="/teams/admin" element={
              user.logged_in && (user.role === 'admin' || user.role === 'teamadmin') ? (
                <>
                  <div className="tag-selector">
                    <select
                      value={selectedTag}
                      onChange={e => {
                        setSearchParams(e.target.value ? { tag: e.target.value } : {});
                      }}
                      className="tag-dropdown"
                      disabled={teamTagLocked}
                    >
                      <option value="">Select a team</option>
                      {tags.map(tag => (
                        <option key={tag} value={tag}>{tag}</option>
                      ))}
                    </select>
                  </div>
                  <TeamsSecondaryTabs activeTab="admin" onTabChange={tab => navigate(`/${tab}${selectedTag ? `?tag=${selectedTag}` : ''}`)} />
                  <div className="admin-section">
                    <div className="admin-tabs-bar">
                      <button
                        className={`admin-tab-btn${adminTab === 'events' ? ' active' : ''}`}
                        onClick={() => setAdminTab('events')}
                      >
                        Events
                      </button>
                      <button
                        className={`admin-tab-btn${adminTab === 'squads' ? ' active' : ''}`}
                        onClick={() => setAdminTab('squads')}
                      >
                        Squads
                      </button>
                      <button
                        className={`admin-tab-btn${adminTab === 'requirements' ? ' active' : ''}`}
                        onClick={() => setAdminTab('requirements')}
                      >
                        Weekly Requirements
                      </button>
                    </div>
                    {adminTab === 'events' && (
                      <AdminEventsSection selectedTag={selectedTag} events={events} setEvents={setEvents} />
                    )}
                    {adminTab === 'squads' && (
                      <div className="admin-squads-section">
                        <SquadsPage 
                          displayNames={displayNames} 
                          selectedTag={selectedTag || ''}
                          setDisplayNames={setDisplayNames}
                        />
                      </div>
                    )}
                    {adminTab === 'requirements' && (
                      <WeeklyRequirementsTab selectedTag={selectedTag} user={user} />
                    )}
                  </div>
                </>
              ) : (
                <div style={{textAlign:'center',marginTop:40,color:'#e53935'}}>Login now required to add/modify/delete Events and manage Squads. Contact Starlight for account.</div>
              )
            } />

            {/* Racers section routes */}
            <Route path="/racers" element={
              <BatchInspector 
                selectedFromNav={racersTabSelected} 
                setSelectedFromNav={setRacersTabSelected} 
                subtabFromNav={racersTabSubtab} 
                setSubtabFromNav={setRacersTabSubtab} 
              />
            } />
            <Route path="/racers/:username" element={
              <BatchInspector 
                selectedFromNav={racersTabSelected} 
                setSelectedFromNav={setRacersTabSelected} 
                subtabFromNav={racersTabSubtab} 
                setSubtabFromNav={setRacersTabSubtab} 
              />
            } />
            <Route path="/racers/:username/:subtab" element={
              <BatchInspector 
                selectedFromNav={racersTabSelected} 
                setSelectedFromNav={setRacersTabSelected} 
                subtabFromNav={racersTabSubtab} 
                setSubtabFromNav={setRacersTabSubtab} 
              />
            } />

            {/* Trackers section routes */}
            <Route path="/trackers" element={
              <>
                <div className="tag-selector">
                  <select
                    value={selectedTag}
                    onChange={e => {
                      setSearchParams(e.target.value ? { tag: e.target.value } : {});
                    }}
                    className="tag-dropdown"
                  >
                    <option value="">Select a team</option>
                    {tags.map(tag => (
                      <option key={tag} value={tag}>{tag}</option>
                    ))}
                  </select>
                </div>
                <TeamsSecondaryTabs activeTab="trackers" onTabChange={tab => {
                  if (tab === 'admin') navigate(`/teams/admin${selectedTag ? `?tag=${selectedTag}` : ''}`);
                  else navigate(`/${tab}${selectedTag ? `?tag=${selectedTag}` : ''}`);
                }} />
                <TrackersTabs />
              </>
            } />

            {/* Leaderboards section routes */}
            <Route path="/leaderboards" element={<Leaderboards />} />

            {/* About section routes */}
            <Route path="/about" element={<AboutPage />} />

            {/* Standalone EventViewer route for embed links */}
            <Route path="/embed/event" element={<StandaloneEventViewer />} />
            
            {/* Standalone WarnListTable route for embed links */}
            <Route path="/embed/warnlist" element={<StandaloneWarnListTable />} />
          </Routes>
        </div>
      </AppNavigationContext.Provider>
    </TeamContext.Provider>
  );
}

export default App; 