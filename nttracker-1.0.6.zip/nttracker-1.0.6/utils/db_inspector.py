from backend.utils.db import get_db_connection

def inspect_database():
    """
    Inspects the database schema and tables.
    """
    conn = get_db_connection()
    if conn and conn.is_connected():
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        
        print("\n=== Database Tables ===")
        for table in tables:
            table_name = table[0]
            print(f"\nTable: {table_name}")
            
            # Get table structure
            cursor.execute(f"DESCRIBE {table_name}")
            columns = cursor.fetchall()
            
            print("Columns:")
            for column in columns:
                print(f"  - {column[0]}: {column[1]} ({column[2]})")
            
            # Get row count
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            print(f"  Row count: {count}")
            
            # Show sample data (first 3 rows)
            cursor.execute(f"SELECT * FROM {table_name} LIMIT 3")
            sample_data = cursor.fetchall()
            if sample_data:
                print("  Sample data:")
                for row in sample_data:
                    print(f"    {row}")
        
        cursor.close()
        conn.close()
        print("\nDatabase inspection complete.")
    else:
        print("Failed to connect to the database")

if __name__ == "__main__":
    inspect_database() 