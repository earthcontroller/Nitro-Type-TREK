# NT Tracker

A web application for tracking and managing NitroType team events and participants.

## Features

- Team roster management
- Squad organization and drag-and-drop assignment
- Event creation, editing, and tracking
- Leaderboards and participant stats
- Admin tools for team and event management
- Export to CSV/Excel
- Real-time updates

---

## Technology Stack

- **Backend:** Python 3.11+ (Flask 3, MySQL, Flask-CORS, Docker)
- **Frontend:** React 18, TypeScript, Vite, MUI, Chart.js
- **Database:** MySQL
- **Deployment:** Docker, Docker Compose

---

## Setup

### 1. Clone the repository
```bash
git clone https://github.com/yourusername/nttracker.git
cd nttracker
```

### 2. Environment Variables
- Copy your `.env` file(s) to `backend/.env` and/or project root as needed.
- **Do not commit secrets to git!**

### 3. Backend Setup (with venv)
```bash
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

### 4. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
- The frontend will run on [http://localhost:3000](http://localhost:3000)
- The backend will run on [http://localhost:5001](http://localhost:5001)

---

## Docker Compose (Recommended for Full Stack)

### Development
```bash
docker-compose -f docker-compose.dev.yml up --build
```

### Production
- See `docker-compose.yml` for pulling and running pre-built images.

---

## Project Structure
```
nttracker/
  backend/         # Flask API, database models, requirements.txt
  frontend/        # React app (Vite, TypeScript, MUI)
  .env             # (not committed) environment variables
  docker-compose.yml
  docker-compose.dev.yml
  README.md
  API_DOCUMENTATION.md
```

---

## API Documentation
See [API_DOCUMENTATION.md](API_DOCUMENTATION.md) for full backend API details, endpoints, and usage examples.

---

## Development Notes
- Make sure to keep your `.env` and secrets out of version control.
- For database migrations, use your preferred tool or manual SQL as needed.
- For questions or issues, open an issue on GitHub.

---

## License
MIT (or your chosen license) 