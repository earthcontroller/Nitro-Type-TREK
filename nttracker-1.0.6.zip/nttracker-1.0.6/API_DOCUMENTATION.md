# NTTracker Backend API Documentation

## Table of Contents
1. [Overview](#overview)
2. [Authentication](#authentication)
3. [API Endpoints](#api-endpoints)
4. [Data Models](#data-models)
5. [Error Handling](#error-handling)
6. [Architectural Analysis](#architectural-analysis)
7. [Improvement Recommendations](#improvement-recommendations)
8. [Migration Roadmap](#migration-roadmap)
9. [Security Considerations](#security-considerations)
10. [Performance Optimization](#performance-optimization)

---

## Overview

**Base URL**: `http://localhost:5001` (Development) / `https://your-domain.com` (Production)

**Technology Stack**:
- Flask 2.0.1 (Web Framework)
- MySQL (Database)
- Docker (Containerization)
- Session-based Authentication
- Role-based Access Control (admin, teamadmin)

**Current Architecture**: Monolithic Flask application with 1992 lines in main app.py

---

## Authentication

### Session-Based Authentication
All endpoints require session-based authentication except where noted. Users have roles: `admin`, `teamadmin`.

### Authentication Endpoints

#### POST `/api/login`
Authenticate user and create session

**Request Body**:
```json
{
  "username": "string",
  "password": "string"
}
```

**Response**:
```json
{
  "success": true,
  "username": "string",
  "role": "admin|teamadmin"
}
```

#### POST `/api/logout`
Clear user session

**Response**:
```json
{
  "success": true
}
```

#### GET `/api/me`
Get current user information

**Response**:
```json
{
  "logged_in": true,
  "username": "string",
  "role": "admin|teamadmin"
}
```

---

## API Endpoints

### User Management (Admin Only)

#### GET `/api/users`
List all users

**Response**: Array of user objects

#### POST `/api/users`
Create new user

**Request Body**:
```json
{
  "username": "string",
  "password": "string",
  "role": "admin|teamadmin",
  "userID": "string"
}
```

#### PUT `/api/users/{user_id}`
Update user

**Request Body**: Partial user object

#### DELETE `/api/users/{user_id}`
Delete user

### Team Management

#### GET `/api/team-tags`
Get all team tags

**Response**: Array of team tag strings

#### GET `/api/current-display-names`
Get team roster with display names

**Query Parameters**:
- `tag` (optional): Filter by team tag

**Response**: Array of member objects with display names, stats, etc.

#### GET `/api/team-info`
Get team information

**Query Parameters**:
- `tag`: Team tag (required)

**Response**:
```json
{
  "Tag": "string",
  "name": "string",
  "tagColor": "string",
  "createdStamp": "string",
  "captain": "string",
  "username": "string",
  "min_races": number,
  "min_speed": number,
  "WeeklyRequirements": number,
  "otherRequirements": "string"
}
```

### Team Statistics & Activity

#### GET `/api/team-stats`
Get 24-hour team statistics

**Query Parameters**:
- `tag`: Team tag (required)

**Response**:
```json
{
  "races": number,
  "avg_wpm": number,
  "accuracy": number,
  "active_members": number,
  "top_racer": "string",
  "top_racer_7d": "string"
}
```

#### GET `/api/activity`
Get team activity for last 24 hours

**Query Parameters**:
- `tag`: Team tag (required)

**Response**: Array of member activity objects

#### GET `/api/hourly-races`
Get hourly race breakdown

**Query Parameters**:
- `tag`: Team tag (required)

**Response**: Array of hourly race data

#### GET `/api/daily-races`
Get daily race totals for last 7 days

**Query Parameters**:
- `tag`: Team tag (required)

**Response**: Array of daily race data

#### GET `/api/weekly-races`
Get weekly race totals for last 8 weeks

**Query Parameters**:
- `tag`: Team tag (required)

**Response**: Array of weekly race data

### Events Management

#### GET `/api/team-events`
Get team events

**Query Parameters**:
- `tag` (optional): Filter by team tag

**Response**: Array of event objects

#### GET `/api/event-participants/{event_id}`
Get event participants

**Response**:
```json
{
  "participants": [
    {
      "Username": "string",
      "CurrentDisplayName": "string",
      "EventID": number,
      "Squad": "string",
      "SquadName": "string",
      "TeamTag": "string",
      "TotalRaces": number,
      "WPM": number,
      "Accuracy": number,
      "Points": number
    }
  ]
}
```

#### GET `/api/event-participants/{event_id}/export`
Export event participants as CSV

**Response**: CSV file download

#### GET `/api/event-participants/{event_id}/export-excel`
Export event participants as Excel

**Response**: Excel file download

#### GET `/api/event-team-summary/{event_id}`
Get event team summary

**Response**: Array of team performance objects

#### GET `/api/event-squad-summary/{event_id}`
Get event squad summary

**Response**: Array of squad performance objects

#### GET `/api/daily-participants`
Get daily participants

**Query Parameters**:
- `tag`: Team tag (required)
- `date`: Date in YYYY-MM-DD format (required)

**Response**:
```json
{
  "participants": [
    {
      "CurrentDisplayName": "string",
      "UserID": number,
      "Username": "string",
      "TeamTag": "string",
      "Squad": "string",
      "SquadName": "string",
      "TotalRaces": number,
      "Accuracy": number,
      "WPM": number,
      "Points": number
    }
  ]
}
```

#### GET `/api/weekly-participants`
Get weekly participants

**Query Parameters**:
- `tag`: Team tag (required)
- `week`: Week start date in YYYY-MM-DD format (required)

**Response**: Same structure as daily participants

### Leaderboards

#### GET `/api/team-leaderboard`
Get team leaderboard

**Query Parameters**:
- `start_time`: Start time (required)
- `end_time`: End time (required)
- `showbot`: Show bots (optional, default: FALSE)

**Response**: Array of team performance objects

#### GET `/api/individual-leaderboard`
Get individual leaderboard

**Query Parameters**:
- `start_time`: Start time (required)
- `end_time`: End time (required)

**Response**: Array of individual performance objects

### Racer Management

#### GET `/api/all-usernames`
Get all usernames

**Response**:
```json
{
  "usernames": ["string"]
}
```

#### GET `/api/racer-info`
Get racer information

**Query Parameters**:
- `username`: Username (required)

**Response**: Racer profile object

#### GET `/api/racer-batches`
Get racer batch data

**Query Parameters**:
- `username`: Username (required)

**Response**:
```json
{
  "batches": [
    {
      "batchEndTime": "string",
      "CurrentDisplayName": "string",
      "teamTag": "string",
      "sum": number,
      "WPM": number,
      "Accuracy": number,
      "racesPlayedBatch": number
    }
  ]
}
```

### Warn List

#### GET `/api/warn-list`
Get warn list for team

**Query Parameters**:
- `tag`: Team tag (required)

**Response**:
```json
{
  "members": [
    {
      "UserID": number,
      "CurrentDisplayName": "string",
      "Username": "string",
      "TeamTag": "string",
      "joinStamp": "string",
      "weeklyRaceHistory": [number]
    }
  ],
  "weeklyRequirements": number
}
```

#### POST `/api/update-weekly-requirements`
Update weekly requirements (Admin/TeamAdmin)

**Request Body**:
```json
{
  "tag": "string",
  "requirements": number
}
```

### Squad Management

#### POST `/api/update-member-squad`
Update member squad assignment

**Request Body**:
```json
{
  "username": "string",
  "squad": "string"
}
```

#### POST `/api/update-custom-squad-name`
Update custom squad name

**Request Body**:
```json
{
  "tag": "string",
  "squad": "string",
  "customName": "string"
}
```

#### POST `/api/insert-squad-record`
Insert squad record

**Request Body**:
```json
{
  "tag": "string",
  "squad": "string"
}
```

### Bot Management

#### GET `/api/bot-flagged-users`
Get bot-flagged users

**Response**: Array of bot-flagged user objects

#### POST `/api/set-bot-flag`
Set bot flag for user

**Request Body**:
```json
{
  "username": "string",
  "flag": number
}
```

#### GET `/api/search-users`
Search users

**Query Parameters**:
- `query`: Search query (required)

**Response**: Array of matching user objects

### Admin Endpoints

#### GET `/api/admin/ping`
Admin access test (Admin only)

**Response**:
```json
{
  "message": "Admin access granted!"
}
```

#### POST `/api/admin/events`
Create new event (Admin only)

**Request Body**: Event object

#### PUT `/api/admin/events/{event_id}`
Update event (Admin only)

**Request Body**: Partial event object

#### DELETE `/api/admin/events/{event_id}`
Delete event (Admin only)

---

## Data Models

### User Object
```json
{
  "id": number,
  "username": "string",
  "role": "admin|teamadmin",
  "userID": "string",
  "created_at": "datetime",
  "last_login": "datetime"
}
```

### Team Member Object
```json
{
  "CurrentDisplayName": "string",
  "Username": "string",
  "Tag": "string",
  "squad": "string",
  "SquadName": "string",
  "Joined": "string",
  "TeamRaces": number,
  "LifetimeRaces": number,
  "AvgWPM": number,
  "TopWPM": number,
  "bot": number
}
```

### Event Object
```json
{
  "EventID": number,
  "Title": "string",
  "Description": "string",
  "TeamTag": "string",
  "StartTime": "string",
  "EndTime": "string",
  "DefaultSort": "string",
  "MinRaces": number,
  "QualifyingRaces": number,
  "RaceIncrement": number,
  "PayoutIncrement": number,
  "Cap": number,
  "AccBonus96": number,
  "AccBonus98": number,
  "Status": "Pending|Active|Concluded"
}
```

---

## Error Handling

### Standard Error Response Format
```json
{
  "error": "Error message description",
  "error_code": "OPTIONAL_ERROR_CODE",
  "status": "error"
}
```

### Common HTTP Status Codes
- `200`: Success
- `400`: Bad Request (validation errors)
- `401`: Unauthorized (authentication required)
- `403`: Forbidden (insufficient permissions)
- `404`: Not Found
- `500`: Internal Server Error

---

## Architectural Analysis

### Current State
**Strengths**:
- ✅ Clear separation of concerns (auth, main app)
- ✅ Proper database abstraction layer
- ✅ Role-based access control
- ✅ Session-based authentication
- ✅ Docker containerization
- ✅ CORS configuration

**Concerns**:
- ⚠️ Single large file (1992 lines in app.py)
- ⚠️ Mixed responsibilities in main app
- ⚠️ No input validation framework
- ⚠️ Limited error handling standardization
- ⚠️ No API versioning
- ⚠️ No caching strategy
- ⚠️ No rate limiting

### Current File Structure
```
backend/
├── app.py (1992 lines - main application)
├── auth.py (224 lines - authentication)
├── utils/
│   └── db.py (111 lines - database utilities)
├── requirements.txt
├── Dockerfile
└── config.py
```

---

## Improvement Recommendations

### 1. Modular Architecture

**Recommended Structure**:
```
backend/
├── app/
│   ├── __init__.py
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   ├── teams.py
│   │   ├── events.py
│   │   ├── leaderboards.py
│   │   ├── racers.py
│   │   └── admin.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── team.py
│   │   └── event.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── auth_service.py
│   │   ├── team_service.py
│   │   └── export_service.py
│   └── utils/
│       ├── __init__.py
│       ├── db.py
│       ├── validators.py
│       └── decorators.py
├── config.py
├── requirements.txt
└── run.py
```

### 2. Input Validation & Error Handling

**Add Flask-Marshmallow**:
```python
from marshmallow import Schema, fields, validate

class TeamQuerySchema(Schema):
    tag = fields.Str(required=True, validate=validate.Length(min=1, max=10))
    date = fields.Date(required=False)

# Standardized error responses
def api_error(message, status_code=400, error_code=None):
    return jsonify({
        'error': message,
        'error_code': error_code,
        'status': 'error'
    }), status_code
```

### 3. Database Layer Improvements

**Add SQLAlchemy ORM**:
```python
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Add connection pooling
from sqlalchemy.pool import QueuePool
```

### 4. API Versioning
```
/api/v1/teams
/api/v1/events
/api/v2/teams  # Future version
```

### 5. Caching Strategy
```python
# Add Redis for caching
from flask_caching import Cache

cache = Cache(config={
    'CACHE_TYPE': 'redis',
    'CACHE_REDIS_URL': 'redis://localhost:6379/0'
})

@cache.memoize(timeout=300)
def get_team_stats(tag):
    # Cache team stats for 5 minutes
    pass
```

### 6. Rate Limiting
```python
# Add Flask-Limiter
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)
```

### 7. Logging & Monitoring
```python
# Add structured logging
import structlog

logger = structlog.get_logger()

# Add health check endpoint
@app.route('/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    })
```

### 8. Testing Framework
```
tests/
├── __init__.py
├── conftest.py
├── test_auth.py
├── test_teams.py
├── test_events.py
└── test_integration.py
```

---

## Migration Roadmap

### Phase 1: Refactoring (2-3 weeks)
**Goals**:
- Split `app.py` into route modules
- Add input validation
- Standardize error handling
- Add comprehensive logging

**Tasks**:
1. Create modular directory structure
2. Move routes to separate files
3. Implement input validation with Marshmallow
4. Standardize error responses
5. Add request/response logging

### Phase 2: Infrastructure (1-2 weeks)
**Goals**:
- Add caching layer
- Implement rate limiting
- Add health checks
- Set up monitoring

**Tasks**:
1. Integrate Redis for caching
2. Add rate limiting with Flask-Limiter
3. Create health check endpoints
4. Set up basic monitoring
5. Add connection pooling

### Phase 3: Advanced Features (2-3 weeks)
**Goals**:
- Add API versioning
- Implement database migrations
- Add comprehensive testing
- Performance optimization

**Tasks**:
1. Implement API versioning strategy
2. Add Alembic for database migrations
3. Create comprehensive test suite
4. Optimize database queries
5. Add performance monitoring

---

## Technology Stack Recommendations

### Current Stack (Good foundation)
- Flask 2.0.1 (Web framework)
- MySQL (Database)
- Docker (Containerization)
- bcrypt (Password hashing)

### Recommended Additions
- **Flask-Marshmallow** (Validation)
- **Flask-Limiter** (Rate limiting)
- **Redis** (Caching)
- **SQLAlchemy** (ORM)
- **Alembic** (Database migrations)
- **Pytest** (Testing)
- **Prometheus** (Monitoring)
- **structlog** (Structured logging)

### Updated requirements.txt
```
flask==2.0.1
flask-cors==3.0.10
python-dotenv==0.19.0
mysql-connector-python==8.0.26
openpyxl==3.1.2
bcrypt
flask-marshmallow==0.14.0
marshmallow-sqlalchemy==0.26.1
flask-limiter==2.4.0
flask-caching==1.10.1
redis==4.0.2
sqlalchemy==1.4.23
alembic==1.7.1
pytest==6.2.5
pytest-flask==1.2.0
structlog==21.1.0
```

---

## Security Considerations

### Current Security Measures
- ✅ Session-based authentication
- ✅ Role-based access control
- ✅ Password hashing with bcrypt
- ✅ Parameterized SQL queries
- ✅ CORS configuration

### Recommended Security Improvements

1. **Input Sanitization**
   - Add comprehensive input validation
   - Sanitize all user inputs
   - Validate file uploads

2. **SQL Injection Prevention**
   - Continue using parameterized queries
   - Add input validation
   - Use ORM for additional protection

3. **Rate Limiting**
   - Implement per-endpoint rate limits
   - Add global rate limiting
   - Monitor for abuse patterns

4. **CORS Configuration**
   - Configure properly for production
   - Restrict to specific domains
   - Handle preflight requests

5. **HTTPS Enforcement**
   - Force HTTPS in production
   - Add HSTS headers
   - Secure cookie configuration

6. **Session Security**
   - Add session timeout
   - Implement secure session storage
   - Add session invalidation

7. **Error Handling**
   - Don't expose internal errors
   - Log security events
   - Implement proper error responses

---

## Performance Optimization

### Database Optimization
1. **Indexing Strategy**
   - Review and optimize indexes
   - Add composite indexes for common queries
   - Monitor slow query performance

2. **Query Optimization**
   - Analyze slow queries
   - Optimize JOIN operations
   - Use database views for complex queries

3. **Connection Pooling**
   - Implement connection pooling
   - Monitor connection usage
   - Optimize connection parameters

### Caching Strategy
1. **Application Caching**
   - Cache frequently accessed data
   - Implement cache invalidation
   - Use Redis for distributed caching

2. **Database Caching**
   - Enable MySQL query cache
   - Use Redis for session storage
   - Implement result caching

### API Optimization
1. **Response Optimization**
   - Implement pagination
   - Add response compression
   - Optimize JSON serialization

2. **Request Optimization**
   - Implement request batching
   - Add request validation
   - Optimize payload sizes

### Monitoring & Metrics
1. **Performance Monitoring**
   - Monitor response times
   - Track database performance
   - Monitor resource usage

2. **Error Tracking**
   - Implement error logging
   - Track error rates
   - Monitor system health

---

## Implementation Priority

### High Priority (Immediate)
1. Input validation and sanitization
2. Error handling standardization
3. Security hardening
4. Basic monitoring

### Medium Priority (Next 2-3 months)
1. Modular architecture refactoring
2. Caching implementation
3. Rate limiting
4. Testing framework

### Low Priority (Long term)
1. API versioning
2. Advanced monitoring
3. Performance optimization
4. Microservices migration

---

## Conclusion

The current NTTracker backend provides a solid foundation with good separation of concerns and proper authentication. The main areas for improvement are:

1. **Code Organization**: Split the monolithic app.py into modular components
2. **Input Validation**: Add comprehensive validation and sanitization
3. **Error Handling**: Standardize error responses and logging
4. **Security**: Implement additional security measures
5. **Performance**: Add caching and optimization strategies

The recommended migration approach is incremental, starting with high-impact, low-risk improvements and gradually moving toward more advanced architectural changes.

This documentation provides a comprehensive roadmap for improving the backend architecture while maintaining the current functionality and user experience. 